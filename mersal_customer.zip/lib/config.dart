/// Public values only. The publishable key is designed to live in the app.
/// Never put a service_role key here.
class AppConfig {
  static const supabaseUrl = 'https://cdovwraosimjhktnkenc.supabase.co';
  static const supabaseKey = 'sb_publishable_BToPU4Q76axfAjnrBQnnlw_zuN6VqcB';

  /// Delivery center (Jarabulus) - used as the default map position.
  static const centerLat = 36.817404;
  static const centerLon = 38.010814;

  /// Salt used to derive the device-account password.
  /// Weak by design for v1 (anyone who extracts it AND knows a device ID could
  /// impersonate it). To be replaced by a server-issued session later.
  static const deviceSalt = 'mersal-jarabulus-v1-9f3a';

  static const imagesBucket = 'custom-order-images';
}
