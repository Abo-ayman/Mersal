import 'package:flutter/material.dart';

import 'theme.dart';

class _Step {
  final String label;
  final IconData icon;
  const _Step(this.label, this.icon);
}

const _steps = <_Step>[
  _Step('تم قبول طلبك من السائق', Icons.thumb_up_alt_outlined),
  _Step('السائق في طريقه للمتجر لتجهيز طلبك', Icons.storefront_outlined),
  _Step('استلم طلبك وهو في طريقه إليك', Icons.delivery_dining),
  _Step('وصل طلبك إلى الباب', Icons.door_front_door_outlined),
  _Step('تم التسليم', Icons.inventory_2_outlined),
];

/// Vertical progress for an accepted order. Small dashes flow toward the step
/// that is currently in progress, and a ring spins around its icon.
class DeliveryTracker extends StatefulWidget {
  final String status;
  const DeliveryTracker({super.key, required this.status});

  @override
  State<DeliveryTracker> createState() => _DeliveryTrackerState();
}

class _DeliveryTrackerState extends State<DeliveryTracker>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  /// (steps completed, step in progress or -1)
  (int, int) _progress() {
    switch (widget.status) {
      case 'processing':
      case 'ready':
        return (1, 1);
      case 'on_the_way':
        return (2, 2);
      case 'arrived':
        return (4, -1);
      case 'delivered':
        return (5, -1);
      default:
        return (0, -1);
    }
  }

  @override
  Widget build(BuildContext context) {
    final (done, current) = _progress();
    final delivered = widget.status == 'delivered';
    return AnimatedBuilder(
      animation: _c,
      builder: (context, _) {
        return Column(
          children: [
            for (var i = 0; i < _steps.length; i++) ...[
              if (i > 0)
                Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: Padding(
                    padding: const EdgeInsetsDirectional.only(start: 21),
                    child: _Dashes(
                      t: _c.value,
                      flowing: current == i,
                      filled: i < done,
                    ),
                  ),
                ),
              _row(i, i < done, i == current, delivered && i == _steps.length - 1),
            ],
          ],
        );
      },
    );
  }

  Widget _row(int i, bool isDone, bool isCurrent, bool finalGreen) {
    final color = finalGreen
        ? Colors.green
        : isDone
            ? Brand.accent
            : isCurrent
                ? Brand.primary
                : Colors.grey.shade300;
    return Row(
      children: [
        SizedBox(
          width: 44,
          height: 44,
          child: Stack(
            alignment: Alignment.center,
            children: [
              if (isCurrent)
                const SizedBox(
                  width: 44,
                  height: 44,
                  child: CircularProgressIndicator(strokeWidth: 3, color: Brand.accent),
                ),
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(color: color, shape: BoxShape.circle),
                child: Icon(
                  isDone ? Icons.check : _steps[i].icon,
                  size: 20,
                  color: (isDone || isCurrent) ? Colors.white : Colors.grey.shade600,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            _steps[i].label,
            style: TextStyle(
              fontWeight: (isDone || isCurrent) ? FontWeight.w800 : FontWeight.w500,
              color: (isDone || isCurrent) ? Brand.ink : Colors.grey.shade600,
            ),
          ),
        ),
      ],
    );
  }
}

class _Dashes extends StatelessWidget {
  final double t;
  final bool flowing;
  final bool filled;
  const _Dashes({required this.t, required this.flowing, required this.filled});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: const Size(2, 30),
      painter: _DashPainter(
        flowing ? t : 0,
        flowing ? Brand.accent : (filled ? Brand.accent : Colors.grey.shade300),
      ),
    );
  }
}

class _DashPainter extends CustomPainter {
  final double t;
  final Color color;
  _DashPainter(this.t, this.color);

  @override
  void paint(Canvas canvas, Size size) {
    const dash = 5.0, gap = 5.0, period = dash + gap;
    final paint = Paint()
      ..color = color
      ..strokeWidth = 2.5
      ..strokeCap = StrokeCap.round;
    var y = -period + t * period; // moves downward, toward the next step
    while (y < size.height) {
      final y1 = y.clamp(0.0, size.height);
      final y2 = (y + dash).clamp(0.0, size.height);
      if (y2 > y1) canvas.drawLine(Offset(1, y1), Offset(1, y2), paint);
      y += period;
    }
  }

  @override
  bool shouldRepaint(covariant _DashPainter old) => old.t != t || old.color != color;
}
