import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../screens/suspended_screen.dart';
import 'app_update.dart' show navigatorKey;

Route<void>? _suspendedRoute;

/// Blocks the app while the admin has suspended this account. Network errors do not block.
/// Returns true when the app is blocked.
Future<bool> checkAccountStatus() async {
  try {
    final rows = await Supabase.instance.client.rpc('my_account_status') as List;
    final info = rows.isEmpty ? null : rows.first as Map<String, dynamic>;
    final nav = navigatorKey.currentState;
    if (nav == null) return false;
    if (info == null || info['suspended'] != true) {
      if (_suspendedRoute != null) {
        nav.removeRoute(_suspendedRoute!);
        _suspendedRoute = null;
      }
      return false;
    }
    if (_suspendedRoute == null) {
      _suspendedRoute = MaterialPageRoute<void>(
        builder: (_) => SuspendedScreen(reason: info['reason'] as String?),
      );
      nav.push(_suspendedRoute!);
    }
    return true;
  } catch (_) {
    return _suspendedRoute != null;
  }
}
