import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'theme.dart';

/// The MERSAL mark: purple rounded square, white location pin, turquoise parcel.
class MersalMark extends StatelessWidget {
  final double size;
  const MersalMark({super.key, this.size = 96});

  @override
  Widget build(BuildContext context) =>
      CustomPaint(size: Size.square(size), painter: _MarkPainter());
}

class _MarkPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 512, size.height / 512);

    final bg = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Brand.primaryLight, Brand.primary],
      ).createShader(const Rect.fromLTWH(0, 0, 512, 512));
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            const Rect.fromLTWH(0, 0, 512, 512), const Radius.circular(112)),
        bg);

    final pin = Path()
      ..moveTo(256, 424)
      ..cubicTo(256, 424, 138, 314, 138, 232)
      ..arcToPoint(const Offset(374, 232),
          radius: const Radius.circular(118), clockwise: true)
      ..cubicTo(374, 314, 256, 424, 256, 424)
      ..close();
    canvas.drawPath(pin, Paint()..color = Colors.white);

    Path poly(List<Offset> p) => Path()..addPolygon(p, true);
    canvas.drawPath(
        poly(const [Offset(256, 170), Offset(316, 203), Offset(256, 236), Offset(196, 203)]),
        Paint()..color = const Color(0xFF2DD4BF));
    canvas.drawPath(
        poly(const [Offset(196, 203), Offset(256, 236), Offset(256, 304), Offset(196, 271)]),
        Paint()..color = const Color(0xFF0D9488));
    canvas.drawPath(
        poly(const [Offset(316, 203), Offset(256, 236), Offset(256, 304), Offset(316, 271)]),
        Paint()..color = const Color(0xFF0A7A70));
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// Mark + the word "مرسال" (Cairo).
class MersalLogo extends StatelessWidget {
  final double markSize;
  final bool horizontal;
  const MersalLogo({super.key, this.markSize = 96, this.horizontal = false});

  @override
  Widget build(BuildContext context) {
    final text = Text(
      'مرسال',
      style: GoogleFonts.cairo(
        fontSize: markSize * (horizontal ? 0.62 : 0.5),
        fontWeight: FontWeight.w900,
        color: Brand.primary,
        height: 1.1,
      ),
    );
    final mark = MersalMark(size: markSize);
    return horizontal
        ? Row(mainAxisSize: MainAxisSize.min, children: [mark, const SizedBox(width: 8), text])
        : Column(mainAxisSize: MainAxisSize.min, children: [mark, const SizedBox(height: 8), text]);
  }
}
