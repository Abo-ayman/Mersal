import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../screens/update_required_screen.dart';

/// Which row of app_updates this build reads: 'customer' or 'driver'.
const appKind = 'customer';

final navigatorKey = GlobalKey<NavigatorState>();

Route<void>? _blockRoute;

/// Blocks the app with the update screen while the admin requires an update.
/// Returns true when the app is blocked. If the server cannot be reached, the app is not blocked.
Future<bool> checkAppUpdate() async {
  try {
    final rows = await Supabase.instance.client
        .rpc('app_update_info', params: {'p_app': appKind}) as List;
    final info = rows.isEmpty ? null : rows.first as Map<String, dynamic>;
    final nav = navigatorKey.currentState;
    if (nav == null) return false;
    if (_blockRoute != null) {
      nav.removeRoute(_blockRoute!);
      _blockRoute = null;
    }
    if (info == null || info['enabled'] != true) return false;
    _blockRoute = MaterialPageRoute<void>(
      builder: (_) => UpdateRequiredScreen(
          url: info['url'] as String, message: info['message'] as String),
    );
    nav.push(_blockRoute!);
    return true;
  } catch (_) {
    return _blockRoute != null;
  }
}

/// Checks again every time the app comes back to the foreground.
class AppUpdateWatcher with WidgetsBindingObserver {
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) checkAppUpdate();
  }
}
