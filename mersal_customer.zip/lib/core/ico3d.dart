import 'package:flutter/material.dart';

/// 3D icon drawn in the app's own style (assets/icons3d/<name>.png).
class Ico3D extends StatelessWidget {
  final String name;
  final double size;
  const Ico3D(this.name, {super.key, this.size = 48});

  @override
  Widget build(BuildContext context) => Image.asset(
        'assets/icons3d/$name.png',
        width: size,
        height: size,
        fit: BoxFit.contain,
        filterQuality: FilterQuality.medium,
      );
}
