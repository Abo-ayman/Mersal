import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Brand {
  static const primary = Color(0xFF0E7C66); // deep green: trust
  static const accent = Color(0xFFFF8A1F); // orange: speed
  static const ink = Color(0xFF14222B);
  static const bg = Color(0xFFF6F8F7);
}

ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: Brand.primary,
    primary: Brand.primary,
    secondary: Brand.accent,
    surface: Colors.white,
  );
  final base = ThemeData(useMaterial3: true, colorScheme: scheme);
  return base.copyWith(
    scaffoldBackgroundColor: Brand.bg,
    textTheme: GoogleFonts.cairoTextTheme(base.textTheme)
        .apply(bodyColor: Brand.ink, displayColor: Brand.ink),
    appBarTheme: AppBarTheme(
      backgroundColor: Brand.bg,
      foregroundColor: Brand.ink,
      elevation: 0,
      centerTitle: true,
      titleTextStyle: GoogleFonts.cairo(
          fontSize: 18, fontWeight: FontWeight.w700, color: Brand.ink),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        minimumSize: const Size.fromHeight(52),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        textStyle: GoogleFonts.cairo(fontSize: 16, fontWeight: FontWeight.w700),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
    ),
  );
}
