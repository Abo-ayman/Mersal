import 'dart:convert';
import 'dart:math';

import 'package:android_id/android_id.dart';
import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';

/// Signs the user in with an account derived from a device ID, with no sign-up form.
/// Android: the device ID. Web: a random ID kept in the browser (lost if the browser data is cleared).
class DeviceIdentity {
  static SupabaseClient get _db => Supabase.instance.client;

  static Future<String> _deviceId() async {
    if (!kIsWeb) {
      final id = await const AndroidId().getId();
      if (id == null || id.isEmpty) {
        throw Exception('تعذر قراءة معرف الجهاز');
      }
      return id;
    }
    final prefs = await SharedPreferences.getInstance();
    var id = prefs.getString('web_device_id');
    if (id == null) {
      final rnd = Random.secure();
      final random = List.generate(12, (_) => rnd.nextInt(16).toRadixString(16)).join();
      id = 'web${DateTime.now().millisecondsSinceEpoch}$random';
      await prefs.setString('web_device_id', id);
    }
    return id;
  }

  static Future<void> ensureSignedIn() async {
    if (_db.auth.currentSession != null) return;

    final id = await _deviceId();
    // Supabase rejects fake domains (no MX records), so a real domain is used.
    // No email is ever sent (Confirm email is off). Recognised by the DB trigger.
    final email = 'mrsl.${id.toLowerCase()}@gmail.com';
    final password =
        sha256.convert(utf8.encode('$id|${AppConfig.deviceSalt}')).toString();

    try {
      await _db.auth.signInWithPassword(email: email, password: password);
    } on AuthException {
      // No account yet for this device: create it.
      final res = await _db.auth.signUp(email: email, password: password);
      if (res.session == null) {
        throw Exception(
            'تعذر إنشاء الحساب. تأكد من تعطيل Confirm email في إعدادات Supabase.');
      }
    }
  }
}
