import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';

/// Startup work that used to run inside main() BEFORE runApp().
/// Any hang or exception there left the app on the native splash forever.
/// Now runApp() runs immediately and this is called from the first screen,
/// with timeouts, so a problem shows an error + retry button instead.
class AppInit {
  static bool _supabaseReady = false;

  static Future<void> supabase() async {
    if (_supabaseReady) return;
    try {
      Supabase.instance.client; // already initialised (e.g. on retry)
      _supabaseReady = true;
      return;
    } catch (_) {}
    await Supabase.initialize(
      url: AppConfig.supabaseUrl,
      anonKey: AppConfig.supabaseKey,
    ).timeout(const Duration(seconds: 20));
    _supabaseReady = true;
  }
}
