import 'package:flutter/foundation.dart';

/// One product in the cart with its quantity.
class CartLine {
  final Map<String, dynamic> product; // id, name, price, image_url
  int qty;
  CartLine(this.product, this.qty);

  String get id => '${product['id']}';
  num get price => product['price'] as num;
  num get total => price * qty;
}

/// The shopping cart. It holds products of ONE store (an order is picked up from a single point).
class Cart extends ChangeNotifier {
  Cart._();
  static final Cart instance = Cart._();

  static const maxQty = 20;

  Map<String, dynamic>? _store; // id, name, latitude, longitude, currency_symbol, is_open
  final Map<String, CartLine> _lines = {};

  Map<String, dynamic>? get store => _store;
  String? get storeId => _store == null ? null : '${_store!['id']}';
  List<CartLine> get lines => _lines.values.toList();
  bool get isEmpty => _lines.isEmpty;
  int get count => _lines.values.fold(0, (a, l) => a + l.qty);
  num get subtotal => _lines.values.fold<num>(0, (a, l) => a + l.total);

  /// True when [store] can be added without emptying the cart first.
  bool accepts(Map<String, dynamic> store) => _lines.isEmpty || storeId == '${store['id']}';

  void add(Map<String, dynamic> store, Map<String, dynamic> product, int qty) {
    if (!accepts(store)) clear();
    _store = store;
    final id = '${product['id']}';
    final line = _lines[id];
    if (line == null) {
      _lines[id] = CartLine(product, qty.clamp(1, maxQty));
    } else {
      line.qty = (line.qty + qty).clamp(1, maxQty);
    }
    notifyListeners();
  }

  void setQty(String productId, int qty) {
    final line = _lines[productId];
    if (line == null) return;
    if (qty <= 0) {
      remove(productId);
      return;
    }
    line.qty = qty.clamp(1, maxQty);
    notifyListeners();
  }

  void remove(String productId) {
    _lines.remove(productId);
    if (_lines.isEmpty) _store = null;
    notifyListeners();
  }

  void clear() {
    _lines.clear();
    _store = null;
    notifyListeners();
  }

  /// The lines as the server expects them.
  List<Map<String, dynamic>> toItems() =>
      [for (final l in _lines.values) {'product_id': l.id, 'qty': l.qty}];
}
