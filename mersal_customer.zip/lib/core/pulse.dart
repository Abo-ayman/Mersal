import 'package:flutter/material.dart';

import 'theme.dart';

/// Soft glow that pulses while [active] (an update the user has not opened yet).
/// Keeps the same padding when inactive so the layout never jumps.
class PulseGlow extends StatefulWidget {
  final bool active;
  final double radius;
  final Widget child;
  const PulseGlow({super.key, required this.active, required this.child, this.radius = 16});

  @override
  State<PulseGlow> createState() => _PulseGlowState();
}

class _PulseGlowState extends State<PulseGlow> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1100));

  @override
  void initState() {
    super.initState();
    _sync();
  }

  @override
  void didUpdateWidget(covariant PulseGlow oldWidget) {
    super.didUpdateWidget(oldWidget);
    _sync();
  }

  void _sync() {
    if (widget.active) {
      if (!_c.isAnimating) _c.repeat(reverse: true);
    } else {
      _c.stop();
      _c.value = 0;
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      child: widget.child,
      builder: (context, child) {
        final t = widget.active ? Curves.easeInOut.transform(_c.value) : 0.0;
        return Container(
          padding: const EdgeInsets.all(3),
          decoration: BoxDecoration(
            color: Color.lerp(Colors.transparent, Brand.accent.withValues(alpha: 0.40), t),
            borderRadius: BorderRadius.circular(widget.radius + 3),
          ),
          child: child,
        );
      },
    );
  }
}
