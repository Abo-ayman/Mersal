import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'core/app_update.dart';
import 'core/push.dart';
import 'core/theme.dart';
import 'screens/startup_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  WidgetsBinding.instance.addObserver(AppUpdateWatcher());
  ErrorWidget.builder = (details) => Material(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Text('حدث خطأ في الواجهة:\n${details.exceptionAsString()}',
                textAlign: TextAlign.center),
          ),
        ),
      );
  runApp(const MersalApp());
}

class MersalApp extends StatelessWidget {
  const MersalApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'مرسال',
      debugShowCheckedModeBanner: false,
      scaffoldMessengerKey: messengerKey,
      theme: buildTheme(),
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      navigatorKey: navigatorKey,
      home: const StartupScreen(),
    );
  }
}
