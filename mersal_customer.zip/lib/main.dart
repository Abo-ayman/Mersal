import 'dart:ui';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'core/push.dart';
import 'core/theme.dart';
import 'screens/bootstrap_screen.dart';

/// IMPORTANT: nothing slow or risky may run before runApp(). If it hangs or
/// throws, the app stays on the native splash screen forever.
/// Supabase / Firebase start-up now happens inside BootstrapScreen.
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  PlatformDispatcher.instance.onError = (error, stack) {
    debugPrint('Unhandled error: $error\n$stack');
    return true; // never let a stray async error kill the app
  };
  runApp(const MersalApp());
}

class MersalApp extends StatelessWidget {
  const MersalApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'مرسال',
      debugShowCheckedModeBanner: false,
      scaffoldMessengerKey: messengerKey,
      theme: buildTheme(),
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const BootstrapScreen(),
    );
  }
}
