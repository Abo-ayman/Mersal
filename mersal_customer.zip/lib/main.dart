import 'package:flutter/material.dart';
import 'icon3d.dart';

void main() => runApp(const MirsalApp());

const Color mirsalGreen = Color(0xFF087A4B);
const Color mirsalBright = Color(0xFF00BF78);
const Color mirsalMint = Color(0xFFE4F4EC);
const Color mirsalInk = Color(0xFF1E2823);
const Color mirsalMuted = Color(0xFF7A8580);
const Color mirsalBackground = Color(0xFFF7F9F7);

class MirsalApp extends StatelessWidget {
  const MirsalApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'مرسال',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: mirsalBackground,
        colorScheme: ColorScheme.fromSeed(seedColor: mirsalGreen),
        fontFamily: 'SomarRounded',
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: mirsalInk,
          elevation: 0,
          centerTitle: false,
        ),
      ),
      home: const MirsalShell(),
    );
  }
}

class ServiceCategory {
  final String title;
  final IconData icon;
  final String asset;
  const ServiceCategory(this.title, this.icon, this.asset);
}

const serviceCategories = <ServiceCategory>[
  ServiceCategory('مرسال', Icons.delivery_dining_rounded, 'delivery.png'),
  ServiceCategory('مطاعم', Icons.restaurant_rounded, 'restaurants.png'),
  ServiceCategory('أجرة', Icons.local_taxi_rounded, 'scooter_3d.png'),
  ServiceCategory('مقاضي', Icons.shopping_basket_rounded, 'stores.png'),
  ServiceCategory('صيدليات', Icons.medical_services_rounded, 'pharmacy.png'),
];

class Shop {
  final String name;
  final String category;
  final String eta;
  final String delivery;
  final double rating;
  final IconData icon;
  final Color color;
  const Shop(this.name, this.category, this.eta, this.delivery, this.rating, this.icon, this.color);
}

const demoShops = <Shop>[
  Shop('مطعم التنور', 'مشاوي وسندويش', '25–35 دقيقة', 'رسوم التوصيل تُحدد لاحقاً', 4.7, Icons.restaurant, Color(0xFFF6D7B8)),
  Shop('مطبخ البيت', 'وجبات منزلية', '30–45 دقيقة', 'رسوم التوصيل تُحدد لاحقاً', 4.8, Icons.soup_kitchen, Color(0xFFE4DDF8)),
  Shop('ماركت الحارة', 'مواد غذائية ومقاضي', '20–30 دقيقة', 'رسوم التوصيل تُحدد لاحقاً', 4.5, Icons.shopping_basket, Color(0xFFD8EEDB)),
  Shop('صيدلية الشفاء', 'صيدلية ومنتجات عناية', 'حسب التوفر', 'رسوم التوصيل تُحدد لاحقاً', 4.6, Icons.local_pharmacy, Color(0xFFD8ECF7)),
];

class Product {
  final String name;
  final String description;
  final double price;
  final IconData icon;
  const Product(this.name, this.description, this.price, this.icon);
}

const demoProducts = <Product>[
  Product('وجبة مشاوي مشكلة', 'مشاوي مشكلة مع خبز ومقبلات', 85000, Icons.outdoor_grill),
  Product('شاورما دجاج', 'سندويش شاورما دجاج مع المخلل', 35000, Icons.lunch_dining),
  Product('بطاطا مقلية', 'حصة بطاطا مقلية', 18000, Icons.fastfood),
  Product('مشروب غازي', 'عبوة مشروب بارد', 10000, Icons.local_drink),
];

class CartLine {
  final Product product;
  int quantity;
  CartLine(this.product, this.quantity);
}

class MirsalShell extends StatefulWidget {
  const MirsalShell({super.key});
  @override
  State<MirsalShell> createState() => _MirsalShellState();
}

class _MirsalShellState extends State<MirsalShell> {
  int selectedCategory = 0;
  int selectedTab = 0;
  final List<CartLine> cart = [];
  String city = 'جرابلس';
  String address = 'حدد عنوان التوصيل';

  int get cartCount => cart.fold(0, (sum, line) => sum + line.quantity);
  double get cartTotal => cart.fold(0, (sum, line) => sum + line.product.price * line.quantity);

  String get searchHint => switch (selectedCategory) {
    1 => 'ما الذي تشتهيه اليوم؟',
    2 => 'حدد نقطة الانطلاق والوجهة',
    3 => 'ابحث عن منتج أو ماركت',
    4 => 'ابحث عن صيدلية أو منتج',
    _ => 'كيف نقدر نساعدك اليوم؟',
  };

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SafeArea(
          bottom: false,
          child: IndexedStack(
            index: selectedTab,
            children: [
              _homePage(),
              OrdersPage(cartCount: cartCount, cartTotal: cartTotal, onCheckout: _checkout),
              _cartPage(),
              const NotificationsPage(),
              const ProfilePage(),
            ],
          ),
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: selectedTab,
          backgroundColor: Colors.white,
          indicatorColor: mirsalMint,
          onDestinationSelected: (i) => setState(() => selectedTab = i),
          destinations: const [
            NavigationDestination(icon: I3(Icons.home_rounded), label: 'الرئيسية'),
            NavigationDestination(icon: I3(Icons.receipt_long_rounded), label: 'الطلبات'),
            NavigationDestination(icon: I3(Icons.shopping_bag_outlined), label: 'السلة'),
            NavigationDestination(icon: I3(Icons.notifications_none_rounded), label: 'التنبيهات'),
            NavigationDestination(icon: I3(Icons.person_outline_rounded), label: 'صفحتي'),
          ],
        ),
      ),
    );
  }

  Widget _homePage() {
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(child: _addressHeader()),
        SliverToBoxAdapter(child: _categoryStrip()),
        SliverToBoxAdapter(child: _searchField()),
        SliverToBoxAdapter(child: _promoBanner()),
        SliverToBoxAdapter(child: _quickServices()),
        SliverToBoxAdapter(child: _sectionHeader(selectedCategory == 2 ? 'اطلب سيارة أجرة' : 'متاجر قريبة منك')),
        if (selectedCategory == 2)
          SliverToBoxAdapter(child: TaxiPanel(onRequest: _requestTaxi))
        else
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, index) => ShopTile(
                shop: demoShops[index],
                onTap: () => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => ShopDetailsPage(
                    shop: demoShops[index],
                    onAdd: _addProduct,
                  ),
                )),
              ),
              childCount: demoShops.length,
            ),
          ),
        const SliverToBoxAdapter(child: SizedBox(height: 24)),
      ],
    );
  }

  Widget _addressHeader() => Container(
    padding: const EdgeInsets.fromLTRB(18, 14, 18, 12),
    decoration: const BoxDecoration(
      gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
        colors: [Color(0xFFDDF3EB), Colors.white]),
    ),
    child: Row(children: [
      const I3(Icons.location_on_outlined, size: 27),
      const SizedBox(width: 8),
      Expanded(child: InkWell(
        onTap: _chooseAddress,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(city, style: const TextStyle(fontSize: 12, color: mirsalMuted)),
          Text(address, maxLines: 1, overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: mirsalInk)),
        ]),
      )),
      IconButton(onPressed: _chooseAddress, icon: const I3(Icons.keyboard_arrow_down_rounded)),
    ]),
  );

  Widget _categoryStrip() => Container(
    color: Colors.white,
    height: 104,
    padding: const EdgeInsets.symmetric(vertical: 8),
    child: ListView.separated(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      scrollDirection: Axis.horizontal,
      itemCount: serviceCategories.length,
      separatorBuilder: (_, __) => const SizedBox(width: 12),
      itemBuilder: (context, index) {
        final c = serviceCategories[index];
        final active = selectedCategory == index;
        return InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => setState(() => selectedCategory = index),
          child: SizedBox(width: 76, child: Column(children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              width: 62, height: 60,
              decoration: BoxDecoration(
                color: active ? mirsalGreen : const Color(0xFFE7F3ED),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: active ? mirsalBright : const Color(0xFFDDEAE2), width: active ? 2 : 1),
              ),
              child: Padding(padding: const EdgeInsets.all(7), child: Image.asset('assets/icons/${c.asset}', fit: BoxFit.contain)),
            ),
            const SizedBox(height: 5),
            Text(c.title, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 12, fontWeight: active ? FontWeight.w900 : FontWeight.w600,
                color: active ? mirsalGreen : mirsalInk)),
          ])),
        );
      },
    ),
  );

  Widget _searchField() => Container(
    color: Colors.white,
    padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
    child: TextField(
      textAlign: TextAlign.right,
      decoration: InputDecoration(
        hintText: searchHint,
        hintStyle: const TextStyle(color: mirsalMuted, fontSize: 14),
        prefixIcon: const I3(Icons.search),
        filled: true, fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 14),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: Color(0xFFE4EAE6))),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: Color(0xFFE4EAE6))),
      ),
    ),
  );

  Widget _promoBanner() => Padding(
    padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
    child: Container(
      height: 158,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft,
          colors: [Color(0xFF064B35), Color(0xFF159568)]),
      ),
      child: Stack(children: [
        Positioned(left: -10, bottom: -26,
          child: Opacity(opacity: .22, child: I3(selectedCategory == 2 ? Icons.local_taxi_rounded : Icons.shopping_bag_rounded, size: 150))),
        Padding(padding: const EdgeInsets.all(18), child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(selectedCategory == 2 ? 'مشوارك صار أسهل' : 'مرسال… طلبك لعندك',
              style: const TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w900)),
            const SizedBox(height: 7),
            Text(selectedCategory == 2 ? 'مشاوير داخل ${city}' : 'اطلب من متاجر ومطاعم مدينتك',
              style: const TextStyle(color: Colors.white, fontSize: 14)),
            const SizedBox(height: 12),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: mirsalGreen),
              onPressed: selectedCategory == 2 ? _requestTaxi : () => setState(() => selectedTab = 0),
              child: Text(selectedCategory == 2 ? 'اطلب أجرة' : 'اكتشف المتاجر'),
            ),
          ],
        )),
      ]),
    ),
  );

  Widget _quickServices() {
    final items = selectedCategory == 2
      ? const [(Icons.my_location, 'موقع الانطلاق'), (Icons.flag, 'الوجهة'), (Icons.route, 'تقدير الرحلة')]
      : const [(Icons.inventory_2_outlined, 'أطلب أي شيء'), (Icons.send_rounded, 'أرسل أي شيء'), (Icons.storefront, 'المتاجر')];
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
      child: Row(children: items.map((a) => Expanded(
        child: InkWell(
          onTap: selectedCategory == 2 ? _requestTaxi : () => _showInfo('سيتم بناء نموذج «${a.$2}» لاحقاً'),
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 5),
            padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 5),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0xFFE5EBE7))),
            child: Column(children: [
              I3(a.$1, size: 27),
              const SizedBox(height: 7),
              Text(a.$2, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800)),
            ]),
          ),
        ),
      )).toList()),
    );
  }

  Widget _sectionHeader(String title) => Padding(
    padding: const EdgeInsets.fromLTRB(18, 12, 18, 8),
    child: Row(children: [
      const I3(Icons.near_me_rounded),
      const SizedBox(width: 7),
      Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: mirsalGreen)),
    ]),
  );

  Widget _cartPage() => CartPage(
    lines: cart,
    total: cartTotal,
    onChange: (line, delta) => setState(() {
      line.quantity += delta;
      if (line.quantity <= 0) cart.remove(line);
    }),
    onCheckout: _checkout,
  );

  void _addProduct(Product product) {
    setState(() {
      final found = cart.where((line) => line.product.name == product.name).firstOrNull;
      if (found != null) { found.quantity++; } else { cart.add(CartLine(product, 1)); }
    });
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('أُضيف ${product.name} إلى السلة')));
  }

  void _chooseAddress() async {
    final chosen = await showModalBottomSheet<String>(
      context: context, showDragHandle: true, isScrollControlled: true,
      builder: (_) => AddressPicker(initialCity: city, initialAddress: address),
    );
    if (chosen != null) {
      final parts = chosen.split('|');
      setState(() { city = parts[0]; address = parts.length > 1 ? parts[1] : 'حدد عنوان التوصيل'; });
    }
  }

  void _requestTaxi() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => TaxiRequestPage(city: city)));
  }

  void _checkout() {
    if (cart.isEmpty) {
      _showInfo('السلة فارغة. افتح أحد المتاجر وأضف المنتجات أولاً.');
      return;
    }
    Navigator.push(context, MaterialPageRoute(builder: (_) => CheckoutPage(
      lines: cart, total: cartTotal, city: city, address: address,
      onConfirm: (name, phone, notes) {
        setState(() { cart.clear(); selectedTab = 1; });
        Navigator.popUntil(context, (route) => route.isFirst);
        setState(() => selectedTab = 1);
        _showInfo('تم إنشاء طلب تجريبي. المرحلة التالية: ربط الخادم والإشعارات.');
      },
    )));
  }

  void _showInfo(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
}

class ShopTile extends StatelessWidget {
  final Shop shop;
  final VoidCallback onTap;
  const ShopTile({super.key, required this.shop, required this.onTap});

  @override
  Widget build(BuildContext context) => Card(
    color: Colors.white, margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
    elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18),
      side: const BorderSide(color: Color(0xFFE7ECE8))),
    child: InkWell(
      borderRadius: BorderRadius.circular(18), onTap: onTap,
      child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [
        Container(width: 76, height: 76, decoration: BoxDecoration(color: shop.color, borderRadius: BorderRadius.circular(16)),
          child: I3(shop.icon, size: 38)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(shop.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          Text(shop.category, style: const TextStyle(color: mirsalMuted, fontSize: 12)),
          const SizedBox(height: 7),
          Row(children: [
            const I3(Icons.star_rounded, size: 16),
            Text(' ${shop.rating}  •  ', style: const TextStyle(fontSize: 11)),
            Flexible(child: Text(shop.eta, style: const TextStyle(fontSize: 11, color: mirsalMuted))),
          ]),
        ])),
        const I3(Icons.chevron_left_rounded),
      ])),
    ),
  );
}

class ShopDetailsPage extends StatelessWidget {
  final Shop shop;
  final void Function(Product) onAdd;
  const ShopDetailsPage({super.key, required this.shop, required this.onAdd});

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: Text(shop.name)),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Container(height: 150, decoration: BoxDecoration(color: shop.color, borderRadius: BorderRadius.circular(24)),
          child: I3(shop.icon, size: 76)),
        const SizedBox(height: 14),
        Text(shop.category, style: const TextStyle(color: mirsalMuted)),
        const SizedBox(height: 18),
        const Text('القائمة', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        for (final product in demoProducts) ProductTile(product: product, onAdd: () => onAdd(product)),
        const SizedBox(height: 20),
      ]),
    ),
  );
}

class ProductTile extends StatelessWidget {
  final Product product;
  final VoidCallback onAdd;
  const ProductTile({super.key, required this.product, required this.onAdd});

  @override
  Widget build(BuildContext context) => Card(
    color: Colors.white, elevation: 0, margin: const EdgeInsets.symmetric(vertical: 5),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16),
      side: const BorderSide(color: Color(0xFFE8ECE9))),
    child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [
      Container(width: 60, height: 60, decoration: BoxDecoration(color: mirsalMint, borderRadius: BorderRadius.circular(14)),
        child: I3(product.icon, size: 30)),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(product.name, style: const TextStyle(fontWeight: FontWeight.w900)),
        const SizedBox(height: 4),
        Text(product.description, style: const TextStyle(fontSize: 11, color: mirsalMuted)),
        const SizedBox(height: 6),
        Text('${formatMoney(product.price)} ل.س', style: const TextStyle(color: mirsalGreen, fontWeight: FontWeight.w900)),
      ])),
      IconButton.filledTonal(onPressed: onAdd, icon: const I3(Icons.add_rounded)),
    ])),
  );
}

class CartPage extends StatelessWidget {
  final List<CartLine> lines;
  final double total;
  final void Function(CartLine, int) onChange;
  final VoidCallback onCheckout;
  const CartPage({super.key, required this.lines, required this.total, required this.onChange, required this.onCheckout});

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('سلة المشتريات')),
      body: lines.isEmpty
        ? const EmptyState(icon: Icons.shopping_bag_outlined, title: 'سلتك فارغة', subtitle: 'تصفح المتاجر وأضف ما تحتاجه')
        : Column(children: [
            Expanded(child: ListView(padding: const EdgeInsets.all(16), children: [
              for (final line in lines) Card(
                color: Colors.white, elevation: 0,
                child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(line.product.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                    Text('${formatMoney(line.product.price)} ل.س', style: const TextStyle(color: mirsalGreen)),
                  ])),
                  IconButton(onPressed: () => onChange(line, -1), icon: const I3(Icons.remove_circle_outline)),
                  Text('${line.quantity}', style: const TextStyle(fontWeight: FontWeight.w900)),
                  IconButton(onPressed: () => onChange(line, 1), icon: const I3(Icons.add_circle_outline)),
                ])),
              ),
            ])),
            _TotalBar(total: total, buttonLabel: 'متابعة إتمام الطلب', onTap: onCheckout),
          ]),
    ),
  );
}

class CheckoutPage extends StatefulWidget {
  final List<CartLine> lines;
  final double total;
  final String city;
  final String address;
  final void Function(String, String, String) onConfirm;
  const CheckoutPage({super.key, required this.lines, required this.total, required this.city,
    required this.address, required this.onConfirm});

  @override
  State<CheckoutPage> createState() => _CheckoutPageState();
}

class _CheckoutPageState extends State<CheckoutPage> {
  final nameController = TextEditingController();
  final phoneController = TextEditingController();
  final notesController = TextEditingController();

  @override
  void dispose() { nameController.dispose(); phoneController.dispose(); notesController.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('تأكيد الطلب')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        const Text('بيانات التوصيل', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
        const SizedBox(height: 14),
        _input(nameController, 'الاسم الكامل', Icons.person_outline),
        const SizedBox(height: 10),
        _input(phoneController, 'رقم الهاتف', Icons.phone_outlined, type: TextInputType.phone),
        const SizedBox(height: 10),
        _input(notesController, 'ملاحظات للسائق (اختياري)', Icons.notes_outlined, maxLines: 3),
        const SizedBox(height: 16),
        ListTile(
          tileColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          leading: const I3(Icons.location_on_outlined),
          title: Text(widget.city), subtitle: Text(widget.address),
        ),
        const SizedBox(height: 12),
        const ListTile(
          tileColor: Colors.white, leading: I3(Icons.payments_outlined),
          title: Text('الدفع نقداً عند الاستلام'), subtitle: Text('لا يوجد دفع إلكتروني في هذه النسخة'),
        ),
        const SizedBox(height: 18),
        Text('الإجمالي المبدئي: ${formatMoney(widget.total)} ل.س',
          style: const TextStyle(fontSize: 18, color: mirsalGreen, fontWeight: FontWeight.w900)),
        const SizedBox(height: 20),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: mirsalGreen, padding: const EdgeInsets.all(16)),
          onPressed: () {
            if (nameController.text.trim().isEmpty || phoneController.text.trim().isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أدخل الاسم ورقم الهاتف')));
              return;
            }
            widget.onConfirm(nameController.text.trim(), phoneController.text.trim(), notesController.text.trim());
          },
          child: const Text('تأكيد الطلب'),
        ),
      ]),
    ),
  );

  Widget _input(TextEditingController c, String hint, IconData icon, {TextInputType? type, int maxLines = 1}) =>
    TextField(controller: c, keyboardType: type, maxLines: maxLines, textAlign: TextAlign.right,
      decoration: InputDecoration(hintText: hint, prefixIcon: I3(icon), filled: true, fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)));
}

class OrdersPage extends StatelessWidget {
  final int cartCount;
  final double cartTotal;
  final VoidCallback onCheckout;
  const OrdersPage({super.key, required this.cartCount, required this.cartTotal, required this.onCheckout});

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(appBar: AppBar(title: const Text('طلباتي')),
      body: const EmptyState(icon: Icons.receipt_long_outlined, title: 'لا توجد طلبات بعد',
        subtitle: 'ستظهر طلباتك وحالاتها هنا بعد ربط الخادم'),
    ),
  );
}

class NotificationsPage extends StatelessWidget {
  const NotificationsPage({super.key});
  @override
  Widget build(BuildContext context) => const Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(appBar: null,
      body: EmptyState(icon: Icons.notifications_none_rounded, title: 'لا توجد تنبيهات',
        subtitle: 'سنظهر هنا تحديثات الطلبات والرحلات'),
    ),
  );
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(appBar: AppBar(title: const Text('صفحتي')),
      body: ListView(padding: const EdgeInsets.all(16), children: const [
        CircleAvatar(radius: 38, backgroundColor: mirsalMint, child: I3(Icons.person, size: 42)),
        SizedBox(height: 18),
        Center(child: Text('مرحباً بك في مرسال', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900))),
        SizedBox(height: 18),
        _ProfileRow(icon: Icons.person_outline, title: 'البيانات الشخصية'),
        _ProfileRow(icon: Icons.location_on_outlined, title: 'عناويني'),
        _ProfileRow(icon: Icons.help_outline, title: 'المساعدة والدعم'),
        _ProfileRow(icon: Icons.info_outline, title: 'حول مرسال'),
      ]),
    ),
  );
}

class _ProfileRow extends StatelessWidget {
  final IconData icon;
  final String title;
  const _ProfileRow({required this.icon, required this.title});
  @override
  Widget build(BuildContext context) => Card(
    color: Colors.white, elevation: 0, child: ListTile(leading: I3(icon),
      title: Text(title), trailing: const I3(Icons.chevron_left_rounded)));
}

class TaxiRequestPage extends StatefulWidget {
  final String city;
  const TaxiRequestPage({super.key, required this.city});
  @override
  State<TaxiRequestPage> createState() => _TaxiRequestPageState();
}

class _TaxiRequestPageState extends State<TaxiRequestPage> {
  final pickupController = TextEditingController();
  final destinationController = TextEditingController();
  String vehicle = 'اقتصادية';
  @override
  void dispose() { pickupController.dispose(); destinationController.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('طلب سيارة أجرة')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Container(height: 210, decoration: BoxDecoration(
          color: const Color(0xFFE1F0E8), borderRadius: BorderRadius.circular(22)),
          child: const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            I3(Icons.map_outlined, size: 65),
            SizedBox(height: 8),
            Text('ستظهر الخريطة هنا بعد ربط مزود الخرائط', style: TextStyle(color: mirsalGreen, fontWeight: FontWeight.w700)),
          ]),
        ),
        const SizedBox(height: 18),
        Text('المدينة: ${widget.city}', style: const TextStyle(fontWeight: FontWeight.w900)),
        const SizedBox(height: 12),
        TextField(controller: pickupController, textAlign: TextAlign.right,
          decoration: const InputDecoration(labelText: 'نقطة الانطلاق', prefixIcon: I3(Icons.my_location), filled: true, fillColor: Colors.white)),
        const SizedBox(height: 12),
        TextField(controller: destinationController, textAlign: TextAlign.right,
          decoration: const InputDecoration(labelText: 'الوجهة', prefixIcon: I3(Icons.flag_outlined), filled: true, fillColor: Colors.white)),
        const SizedBox(height: 14),
        const Text('نوع السيارة', style: TextStyle(fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        Wrap(spacing: 8, children: ['اقتصادية', 'عائلية'].map((v) => ChoiceChip(
          label: Text(v), selected: vehicle == v, onSelected: (_) => setState(() => vehicle = v),
        )).toList()),
        const SizedBox(height: 16),
        const ListTile(
          tileColor: Colors.white, leading: I3(Icons.payments_outlined),
          title: Text('الدفع نقداً للسائق'), subtitle: Text('أجرة الرحلة ستحدد بعد إعداد التسعير'),
        ),
        const SizedBox(height: 18),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: mirsalGreen, padding: const EdgeInsets.all(16)),
          onPressed: () {
            if (pickupController.text.trim().isEmpty || destinationController.text.trim().isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أدخل نقطة الانطلاق والوجهة')));
              return;
            }
            showDialog(context: context, builder: (_) => AlertDialog(
              title: const Text('طلب تجريبي'),
              content: Text('من ${pickupController.text} إلى ${destinationController.text}\\nالسيارة: $vehicle\\nهذه واجهة تجريبية؛ لم يُرسل طلب فعلي.'),
              actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('حسناً'))],
            ));
          },
          child: const Text('متابعة طلب الأجرة'),
        ),
      ]),
    ),
  );
}

class TaxiPanel extends StatelessWidget {
  final VoidCallback onRequest;
  const TaxiPanel({super.key, required this.onRequest});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(16),
    child: Container(padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFE4EAE6))),
      child: Column(children: [
        const I3(Icons.local_taxi_rounded, size: 54),
        const SizedBox(height: 8),
        const Text('رحلتك داخل المدينة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 6),
        const Text('أدخل نقطة الانطلاق والوجهة لمتابعة طلب سيارة أجرة.',
          textAlign: TextAlign.center, style: TextStyle(color: mirsalMuted)),
        const SizedBox(height: 14),
        SizedBox(width: double.infinity, child: FilledButton(
          style: FilledButton.styleFrom(backgroundColor: mirsalGreen),
          onPressed: onRequest, child: const Text('تحديد الرحلة'))),
      ]),
    ),
  );
}

class AddressPicker extends StatefulWidget {
  final String initialCity;
  final String initialAddress;
  const AddressPicker({super.key, required this.initialCity, required this.initialAddress});
  @override
  State<AddressPicker> createState() => _AddressPickerState();
}

class _AddressPickerState extends State<AddressPicker> {
  late String city = widget.initialCity;
  final addressController = TextEditingController();
  @override
  void initState() { super.initState(); addressController.text = widget.initialAddress == 'حدد عنوان التوصيل' ? '' : widget.initialAddress; }
  @override
  void dispose() { addressController.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Padding(padding: EdgeInsets.fromLTRB(18, 8, 18, 24 + MediaQuery.of(context).viewInsets.bottom),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('عنوان التوصيل', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: city, decoration: const InputDecoration(labelText: 'المدينة'),
          items: const ['جرابلس', 'اعزاز', 'الباب', 'عفرين', 'إدلب', 'حلب'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
          onChanged: (v) { if (v != null) setState(() => city = v); },
        ),
        const SizedBox(height: 12),
        TextField(controller: addressController, textAlign: TextAlign.right,
          decoration: const InputDecoration(labelText: 'وصف العنوان أو أقرب معلم', prefixIcon: I3(Icons.location_on_outlined))),
        const SizedBox(height: 18),
        SizedBox(width: double.infinity, child: FilledButton(
          style: FilledButton.styleFrom(backgroundColor: mirsalGreen),
          onPressed: () => Navigator.pop(context, '$city|${addressController.text.trim().isEmpty ? 'حدد عنوان التوصيل' : addressController.text.trim()}'),
          child: const Text('حفظ العنوان'))),
      ]),
    ),
  );
}

class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const EmptyState({super.key, required this.icon, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Center(
    child: Padding(padding: const EdgeInsets.all(28), child: Column(
      mainAxisAlignment: MainAxisAlignment.center, children: [
        I3(icon, size: 64),
        const SizedBox(height: 16),
        Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: mirsalMuted)),
      ],
    )),
  );
}

class _TotalBar extends StatelessWidget {
  final double total;
  final String buttonLabel;
  final VoidCallback onTap;
  const _TotalBar({required this.total, required this.buttonLabel, required this.onTap});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
    decoration: const BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: Color(0xFFE7ECE8)))),
    child: Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('المجموع المبدئي', style: TextStyle(color: mirsalMuted, fontSize: 12)),
        Text('${formatMoney(total)} ل.س', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: mirsalGreen)),
      ])),
      FilledButton(style: FilledButton.styleFrom(backgroundColor: mirsalGreen, padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14)),
        onPressed: onTap, child: Text(buttonLabel)),
    ]),
  );
}

String formatMoney(double value) {
  final rounded = value.round().toString();
  final buffer = StringBuffer();
  for (var i = 0; i < rounded.length; i++) {
    buffer.write(rounded[i]);
    final remaining = rounded.length - i - 1;
    if (remaining > 0 && remaining % 3 == 0) buffer.write(',');
  }
  return buffer.toString();
}
