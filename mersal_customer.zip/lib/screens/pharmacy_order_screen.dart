import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:latlong2/latlong.dart';

import '../core/theme.dart';
import '../data/order_repository.dart';
import '../data/route_total.dart';
import '../data/routing_service.dart';
import 'fee_card.dart';
import 'location_picker.dart';
import 'my_orders_screen.dart';

/// Pharmacy: send photos of the medicine, choose a pharmacy (or any), and a delivery point.
class PharmacyOrderScreen extends StatefulWidget {
  const PharmacyOrderScreen({super.key});

  @override
  State<PharmacyOrderScreen> createState() => _PharmacyOrderScreenState();
}

class _PharmacyOrderScreenState extends State<PharmacyOrderScreen> {
  final _repo = OrderRepository();
  final _routing = OsrmRoutingService();
  final _desc = TextEditingController();
  final _pharmacyName = TextEditingController();
  final _phone = TextEditingController();
  final _notes = TextEditingController();
  final List<XFile> _photos = [];
  bool _anyPharmacy = true;
  LatLng? _pharmacy;
  LatLng? _location;
  int? _distanceM;
  Map<String, dynamic>? _fee;
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _repo.getProfile().then((p) {
      final phone = p['phone'] as String?;
      if (mounted && phone != null && _phone.text.isEmpty) _phone.text = phone;
    }).catchError((_) {});
  }

  Future<void> _addPhotos() async {
    final picked = await ImagePicker().pickMultiImage(maxWidth: 1400, imageQuality: 82);
    if (picked.isEmpty) return;
    setState(() {
      _photos.addAll(picked.take(5 - _photos.length));
      if (_photos.length > 5) _photos.removeRange(5, _photos.length);
    });
  }

  Future<void> _pickPharmacy() async {
    final res = await Navigator.of(context).push<LatLng>(
        MaterialPageRoute(builder: (_) => LocationPicker(initial: _pharmacy)));
    if (res == null) return;
    setState(() => _pharmacy = res);
    if (_location != null) _calcFor(_location!);
  }

  Future<void> _pickLocation() async {
    final res = await Navigator.of(context).push<LatLng>(
        MaterialPageRoute(builder: (_) => LocationPicker(initial: _location)));
    if (res == null) return;
    setState(() => _location = res);
    _calcFor(res);
  }

  /// Distance of the whole trip: market -> pharmacy point (when chosen) -> customer.
  Future<void> _calcFor(LatLng res) async {
    setState(() {
      _distanceM = null;
      _fee = null;
      _busy = true;
      _error = null;
    });
    try {
      final city = await _repo.resolveCity(res.latitude, res.longitude);
      if (city == null) throw Exception('outside');
      if (!_anyPharmacy && _pharmacy == null) {
        if (mounted) setState(() => _busy = false);
        return;
      }
      final m = await tripDistanceM(
        centerLat: (city['center_lat'] as num).toDouble(),
        centerLon: (city['center_lon'] as num).toDouble(),
        store: _anyPharmacy ? null : _pharmacy,
        customer: res,
      );
      if (m == null) throw Exception('route');
      final fee = await _repo.feePreview(res.latitude, res.longitude, m);
      if (!mounted) return;
      setState(() {
        _distanceM = m;
        _fee = fee;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _location = null;
        _error = e.toString().contains('outside')
            ? 'موقعك خارج مناطق خدمتنا (جرابلس ومسكنة).'
            : 'تعذر حساب أجرة التوصيل. اختر الموقع مرة أخرى.';
      });
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _submit() async {
    if (_photos.isEmpty) {
      setState(() => _error = 'أضف صورة واحدة على الأقل للدواء أو الوصفة');
      return;
    }
    if (!_anyPharmacy && _pharmacy == null) {
      setState(() => _error = 'حدد موقع الصيدلية على الخريطة أو اختر «أي صيدلية»');
      return;
    }
    if (_location == null || _distanceM == null) {
      setState(() => _error = 'حدد موقع التوصيل وانتظر حساب الأجرة');
      return;
    }
    if (_phone.text.trim().length < 7) {
      setState(() => _error = 'اكتب رقم هاتف صحيح للتواصل');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final urls = <String>[];
      for (final f in _photos) {
        final bytes = await f.readAsBytes();
        final name = f.name.toLowerCase();
        final ext = name.endsWith('.png') ? 'png' : 'jpeg';
        urls.add(await _repo.uploadImage(bytes, ext));
      }
      await _repo.createPharmacyOrder(
        images: urls,
        description: _desc.text.trim(),
        pickupName: _anyPharmacy
            ? 'أي صيدلية'
            : (_pharmacyName.text.trim().isEmpty ? 'صيدلية محددة' : _pharmacyName.text.trim()),
        pickupLat: _anyPharmacy ? null : _pharmacy?.latitude,
        pickupLon: _anyPharmacy ? null : _pharmacy?.longitude,
        lat: _location!.latitude,
        lon: _location!.longitude,
        address: 'حسب الموقع المحدد على الخريطة',
        phone: _phone.text.trim(),
        notes: _notes.text.trim().isEmpty ? null : _notes.text.trim(),
        routeDistanceM: _distanceM!,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم إرسال طلب الدواء. سنرسل لك السعر عند قبول السائق.')));
      Navigator.of(context)
          .pushReplacement(MaterialPageRoute(builder: (_) => const MyOrdersScreen()));
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    const pharmacyColor = Color(0xFF0E9F6E);
    return Scaffold(
      appBar: AppBar(title: const Text('صيدليات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: pharmacyColor.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Text(
                'أرسل صورة الدواء أو الوصفة، وسيصلك السائق بالطلب. الصور تظهر للسائق في المحادثة مباشرة بعد قبوله.'),
          ),
          const SizedBox(height: 14),
          const Text('صور الدواء أو الوصفة *', style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          SizedBox(
            height: 96,
            child: ListView(scrollDirection: Axis.horizontal, children: [
              for (var i = 0; i < _photos.length; i++)
                Padding(
                  padding: const EdgeInsetsDirectional.only(end: 8),
                  child: Stack(children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.file(File(_photos[i].path), width: 96, height: 96, fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                              width: 96, height: 96, color: Colors.black12,
                              child: const Icon(Icons.image_outlined))),
                    ),
                    PositionedDirectional(
                      top: 2,
                      end: 2,
                      child: InkWell(
                        onTap: () => setState(() => _photos.removeAt(i)),
                        child: const CircleAvatar(
                            radius: 11, backgroundColor: Colors.black54,
                            child: Icon(Icons.close, size: 14, color: Colors.white)),
                      ),
                    ),
                  ]),
                ),
              if (_photos.length < 5)
                InkWell(
                  onTap: _addPhotos,
                  borderRadius: BorderRadius.circular(12),
                  child: Container(
                    width: 96,
                    height: 96,
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Brand.line)),
                    child: const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.add_a_photo_outlined, color: pharmacyColor),
                      SizedBox(height: 4),
                      Text('أضف صورة', style: TextStyle(fontSize: 12)),
                    ]),
                  ),
                ),
            ]),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: _desc,
            maxLines: 2,
            decoration: const InputDecoration(
                labelText: 'اسم الدواء أو ملاحظة (اختياري)',
                hintText: 'مثال: بنادول 500 ملغ، علبتان'),
          ),
          const SizedBox(height: 14),
          const Text('من أين نجلب الدواء؟', style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          SegmentedButton<bool>(
            segments: const [
              ButtonSegment(value: true, label: Text('أي صيدلية')),
              ButtonSegment(value: false, label: Text('صيدلية محددة')),
            ],
            selected: {_anyPharmacy},
            onSelectionChanged: (s) {
              setState(() => _anyPharmacy = s.first);
              if (_location != null) _calcFor(_location!);
            },
          ),
          if (!_anyPharmacy) ...[
            const SizedBox(height: 10),
            TextField(
                controller: _pharmacyName,
                decoration: const InputDecoration(labelText: 'اسم الصيدلية (اختياري)')),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _pickPharmacy,
              icon: const Icon(Icons.local_pharmacy_outlined),
              label: Text(_pharmacy == null ? 'حدد موقع الصيدلية على الخريطة' : 'تم تحديد موقع الصيدلية ✓'),
            ),
          ],
          const SizedBox(height: 14),
          OutlinedButton.icon(
            onPressed: _busy ? null : _pickLocation,
            icon: const Icon(Icons.place_outlined),
            label: Text(_location == null ? 'حدد موقع التوصيل *' : 'تم تحديد موقع التوصيل ✓'),
          ),
          if (_fee != null) ...[
            const SizedBox(height: 10),
            FeeCard(fee: _fee!),
          ],
          const SizedBox(height: 10),
          TextField(
            controller: _phone,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(labelText: 'رقم الهاتف *'),
          ),
          const SizedBox(height: 10),
          TextField(
              controller: _notes,
              maxLines: 2,
              decoration: const InputDecoration(labelText: 'ملاحظات إضافية')),
          if (_error != null) ...[
            const SizedBox(height: 10),
            Text(_error!, style: const TextStyle(color: Colors.red)),
          ],
          const SizedBox(height: 16),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: pharmacyColor),
            onPressed: _busy ? null : _submit,
            child: _busy
                ? const SizedBox(
                    height: 22,
                    width: 22,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Text('إرسال طلب الدواء'),
          ),
          const SizedBox(height: 8),
          const Text('تدفع نقداً عند التسليم، ثم يُضاف سعر الدواء بعد أن يشتريه السائق.',
              textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
        ],
      ),
    );
  }
}
