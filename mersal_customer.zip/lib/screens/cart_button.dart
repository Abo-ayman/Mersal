import 'package:flutter/material.dart';

import '../core/cart.dart';
import 'cart_screen.dart';

/// Cart icon with the number of items, for app bars.
class CartButton extends StatelessWidget {
  const CartButton({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Cart.instance,
      builder: (context, _) {
        final n = Cart.instance.count;
        return IconButton(
          tooltip: 'السلة',
          onPressed: () =>
              Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CartScreen())),
          icon: Badge(
            isLabelVisible: n > 0,
            label: Text('$n'),
            child: const Icon(Icons.shopping_cart_outlined),
          ),
        );
      },
    );
  }
}
