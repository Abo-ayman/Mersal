import 'package:flutter/material.dart';

import 'live_map.dart';

/// Full-screen live map: the driver's position and the customer's delivery location.
class LiveTrackingScreen extends StatelessWidget {
  final String orderId;
  final String status;
  final double? customerLat;
  final double? customerLon;
  const LiveTrackingScreen({
    super.key,
    required this.orderId,
    required this.status,
    this.customerLat,
    this.customerLon,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('التتبع الحي')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: LiveDriverMap(
            orderId: orderId,
            status: status,
            customerLat: customerLat,
            customerLon: customerLon,
            fullScreen: true,
          ),
        ),
      ),
    );
  }
}
