import 'package:flutter/material.dart';

import '../core/logo.dart';
import '../data/order_repository.dart';
import 'home_screen.dart';

/// Asks the customer for the number we use to confirm orders (WhatsApp or Syrian). No code is sent.
class PhoneScreen extends StatefulWidget {
  const PhoneScreen({super.key});

  @override
  State<PhoneScreen> createState() => _PhoneScreenState();
}

class _PhoneScreenState extends State<PhoneScreen> {
  final _ctrl = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final phone = _ctrl.text.trim();
    if (phone.replaceAll(RegExp(r'[^0-9]'), '').length < 9) {
      setState(() => _error = 'اكتب رقمك كاملاً');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await OrderRepository().setPhone(phone);
      if (!mounted) return;
      Navigator.of(context)
          .pushReplacement(MaterialPageRoute(builder: (_) => const HomeScreen()));
    } catch (e) {
      final invalid = '$e'.contains('invalid_phone');
      setState(() => _error = invalid
          ? 'الرقم غير صحيح. اكتبه بالشكل 09XXXXXXXX أو بصيغة دولية مثل +963…'
          : 'تعذر الحفظ، حاول مرة أخرى');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.all(24), children: [
          const SizedBox(height: 24),
          const Center(child: MersalLogo(markSize: 80)),
          const SizedBox(height: 28),
          const Text('رقم للتواصل معك',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          const Text(
            'سنتواصل معك على هذا الرقم لتأكيد طلباتك. يمكن أن يكون رقم واتساب أو رقماً سورياً.',
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          TextField(
            controller: _ctrl,
            keyboardType: TextInputType.phone,
            textDirection: TextDirection.ltr,
            decoration: InputDecoration(
              labelText: 'رقم الهاتف',
              hintText: '09XXXXXXXX أو +963…',
              errorText: _error,
            ),
          ),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: _busy ? null : _save,
            child: _busy
                ? const SizedBox(
                    height: 22,
                    width: 22,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Text('حفظ ومتابعة'),
          ),
        ]),
      ),
    );
  }
}
