import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/theme.dart';

/// "رحلاتي": every trip on the customer's orders, with its route on the map.
class TripsScreen extends StatefulWidget {
  const TripsScreen({super.key});

  @override
  State<TripsScreen> createState() => _TripsScreenState();
}

class _TripsScreenState extends State<TripsScreen> {
  late final Future<List<Map<String, dynamic>>> _trips = _load();

  Future<List<Map<String, dynamic>>> _load() async {
    final rows = await Supabase.instance.client.rpc('my_trips') as List;
    return rows.map((r) => Map<String, dynamic>.from(r as Map)).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('رحلاتي')),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _trips,
        builder: (_, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) return const Center(child: Text('تعذر تحميل الرحلات'));
          final trips = snap.data ?? const <Map<String, dynamic>>[];
          if (trips.isEmpty) return const Center(child: Text('لا توجد رحلات بعد'));
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: trips.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (_, i) => _TripTile(trip: trips[i]),
          );
        },
      ),
    );
  }
}

class _TripTile extends StatelessWidget {
  final Map<String, dynamic> trip;
  const _TripTile({required this.trip});

  String _when(String? iso) {
    if (iso == null) return '';
    final d = DateTime.parse(iso).toLocal();
    String two(int n) => n.toString().padLeft(2, '0');
    return '${d.day}/${d.month}/${d.year}  ${two(d.hour)}:${two(d.minute)}';
  }

  @override
  Widget build(BuildContext context) {
    final km = ((trip['distance_m'] ?? 0) as num) / 1000;
    final mins = (((trip['duration_s'] ?? 0) as num) / 60).round();
    final cur = (trip['currency_symbol'] ?? '') as String;
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: const Icon(Icons.route_rounded, color: Brand.primary),
        title: Text('طلب #${trip['order_number']}',
            style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(
            '${_when(trip['started_at'] as String?)}\n${km.toStringAsFixed(1)} كم · $mins دقيقة'),
        isThreeLine: true,
        trailing: Text('${trip['total'] ?? ''} $cur',
            style: const TextStyle(fontWeight: FontWeight.w800)),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => TripRouteScreen(
                tripId: trip['trip_id'] as String, title: 'طلب #${trip['order_number']}'))),
      ),
    );
  }
}

/// The route of one trip on the map.
class TripRouteScreen extends StatelessWidget {
  final String tripId;
  final String title;
  const TripRouteScreen({super.key, required this.tripId, required this.title});

  Future<List<LatLng>> _route() async {
    final rows =
        await Supabase.instance.client.rpc('trip_route', params: {'p_trip': tripId}) as List;
    return rows.map((r) {
      final m = r as Map;
      return LatLng((m['latitude'] as num).toDouble(), (m['longitude'] as num).toDouble());
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: FutureBuilder<List<LatLng>>(
        future: _route(),
        builder: (_, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          final pts = snap.data ?? const <LatLng>[];
          if (snap.hasError || pts.isEmpty) {
            return const Center(child: Text('لا يوجد مسار مسجّل لهذه الرحلة'));
          }
          return FlutterMap(
            options: MapOptions(
              initialCameraFit:
                  CameraFit.coordinates(coordinates: pts, padding: const EdgeInsets.all(48)),
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.mersal.customer',
              ),
              PolylineLayer(
                polylines: [Polyline(points: pts, strokeWidth: 5, color: Brand.primary)],
              ),
              MarkerLayer(markers: [
                Marker(
                    point: pts.first,
                    width: 30,
                    height: 30,
                    child: const Icon(Icons.trip_origin, color: Colors.green)),
                Marker(
                    point: pts.last,
                    width: 30,
                    height: 30,
                    child: const Icon(Icons.flag, color: Colors.red)),
              ]),
            ],
          );
        },
      ),
    );
  }
}
