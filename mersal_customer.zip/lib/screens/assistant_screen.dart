import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';

import '../assistant/local_assistant.dart';
import '../data/order_repository.dart';
import '../data/routing_service.dart';
import 'fee_card.dart';
import 'location_picker.dart';
import 'my_orders_screen.dart';

class _Msg {
  final bool fromUser;
  final String text;
  const _Msg(this.fromUser, this.text);
}

/// Personal assistant running entirely on the phone (rules in LocalAssistant).
/// The location, the fee and the final send are done by the app and the server;
/// the customer presses the send button or writes «إرسال».
class AssistantScreen extends StatefulWidget {
  const AssistantScreen({super.key});

  @override
  State<AssistantScreen> createState() => _AssistantScreenState();
}

class _AssistantScreenState extends State<AssistantScreen> {
  final _repo = OrderRepository();
  final _routing = OsrmRoutingService();
  final _input = TextEditingController();
  final _phone = TextEditingController();
  final _scroll = ScrollController();

  final List<_Msg> _msgs = [const _Msg(false, LocalAssistant.welcome)];
  AssistantProposal? _proposal;
  LatLng? _location;
  int? _distanceM;
  Map<String, dynamic>? _fee;
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _repo.getProfile().then((p) {
      final phone = p['phone'] as String?;
      if (mounted && phone != null && _phone.text.isEmpty) _phone.text = phone;
    }).catchError((_) {});
  }

  @override
  void dispose() {
    _input.dispose();
    _phone.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _scrollDown() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  void _clearOrder() {
    _proposal = null;
    _location = null;
    _distanceM = null;
    _fee = null;
    _error = null;
  }

  void _say(String text) {
    setState(() => _msgs.add(_Msg(false, text)));
    _scrollDown();
  }

  void _onSend() {
    final text = _input.text.trim();
    if (text.isEmpty || _busy) return;
    _input.clear();
    final turn = LocalAssistant.handle(text, hasProposal: _proposal != null);
    setState(() {
      _msgs.add(_Msg(true, text));
      if (turn.command == AssistantCommand.edit || turn.command == AssistantCommand.cancel) {
        _clearOrder();
      }
      if (turn.reply.isNotEmpty) _msgs.add(_Msg(false, turn.reply));
      final p = turn.proposal;
      if (p != null) {
        _clearOrder();
        _proposal = p;
        final desc = p.description.isEmpty ? '' : ' — ${p.description}';
        _msgs.add(_Msg(false, 'طلبك: ${p.item} × ${p.quantity}$desc'));
      }
    });
    if (turn.command == AssistantCommand.send) _sendOrder();
    _scrollDown();
  }

  void _sendOrder() {
    if (_proposal == null) {
      _say('ليس لديك طلب جاهز. اكتب ما تريد طلبه.');
      return;
    }
    if (_location == null || _fee == null) {
      _say('حدّد موقع التوصيل أولاً بالزر أعلاه، ثم اكتب «إرسال».');
      return;
    }
    _submit();
  }

  Future<void> _pickLocation() async {
    final loc = await Navigator.of(context).push<LatLng>(
        MaterialPageRoute(builder: (_) => LocationPicker(initial: _location)));
    if (loc == null) return;
    setState(() {
      _location = loc;
      _distanceM = null;
      _fee = null;
      _busy = true;
      _error = null;
    });
    try {
      final city = await _repo.resolveCity(loc.latitude, loc.longitude);
      if (city == null) throw Exception('outside');
      final m = await _routing.drivingDistanceMeters(
        fromLat: (city['center_lat'] as num).toDouble(),
        fromLon: (city['center_lon'] as num).toDouble(),
        toLat: loc.latitude,
        toLon: loc.longitude,
      );
      if (m == null) throw Exception('route');
      final fee = await _repo.feePreview(loc.latitude, loc.longitude, m);
      if (!mounted) return;
      setState(() {
        _distanceM = m;
        _fee = fee;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _location = null;
        _error = e.toString().contains('outside')
            ? 'موقعك خارج مناطق خدمتنا (جرابلس ومسكنة).'
            : 'تعذر حساب أجرة التوصيل. اختر الموقع مرة أخرى.';
      });
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _submit() async {
    final p = _proposal;
    final loc = _location;
    final dist = _distanceM;
    if (p == null || loc == null || dist == null) return;
    final phone = _phone.text.trim();
    if (phone.length < 7) {
      setState(() => _error = 'اكتب رقم هاتف صحيح للتواصل');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await _repo.createCustomOrder(
        itemName: p.item,
        description: p.description.isEmpty ? null : p.description,
        quantity: p.quantity,
        address: 'حسب الموقع المحدد على الخريطة',
        lat: loc.latitude,
        lon: loc.longitude,
        phone: phone,
        notes: null,
        routeDistanceM: dist,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم إرسال طلبك. سنرسل لك السعر للموافقة عليه.')));
      Navigator.of(context)
          .pushReplacement(MaterialPageRoute(builder: (_) => const MyOrdersScreen()));
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _bubble(_Msg m) {
    final mine = m.fromUser;
    return Align(
      alignment: mine ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
        decoration: BoxDecoration(
          color: mine ? const Color(0xFF0C7A4C) : Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: mine ? null : Border.all(color: const Color(0xFFDCEEE4)),
        ),
        child: Text(m.text,
            style: TextStyle(color: mine ? Colors.white : const Color(0xFF14291F), height: 1.4)),
      ),
    );
  }

  Widget _proposalCard() {
    final p = _proposal!;
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF0C7A4C).withValues(alpha: 0.4)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('${p.item}  ×${p.quantity}',
            style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
        if (p.description.isNotEmpty && p.description != p.item)
          Text(p.description, style: const TextStyle(color: Colors.black54)),
        const SizedBox(height: 10),
        if (_location == null)
          FilledButton.icon(
            onPressed: _busy ? null : _pickLocation,
            icon: const Icon(Icons.place_outlined),
            label: const Text('حدد موقع التوصيل'),
          )
        else
          Row(children: [
            const Icon(Icons.check_circle, color: Color(0xFF14A36B), size: 18),
            const SizedBox(width: 6),
            const Expanded(child: Text('تم تحديد الموقع')),
            TextButton(onPressed: _busy ? null : _pickLocation, child: const Text('تغيير')),
          ]),
        if (_fee != null) ...[
          const SizedBox(height: 8),
          FeeCard(fee: _fee!),
          const SizedBox(height: 8),
          TextField(
            controller: _phone,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(labelText: 'رقم الهاتف *'),
          ),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(
              child: OutlinedButton(
                onPressed: _busy ? null : () => _say('حسناً، اكتب التفاصيل الجديدة للطلب وسأحدّثه.'),
                child: const Text('تعديل الطلب'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: FilledButton(
                onPressed: _busy ? null : _sendOrder,
                child: const Text('إرسال الطلب'),
              ),
            ),
          ]),
        ],
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المساعد الشخصي')),
      body: Column(children: [
        Expanded(
          child: ListView.builder(
            controller: _scroll,
            padding: const EdgeInsets.all(14),
            itemCount: _msgs.length,
            itemBuilder: (_, i) => _bubble(_msgs[i]),
          ),
        ),
        if (_proposal != null) _proposalCard(),
        if (_busy)
          const Padding(
              padding: EdgeInsets.symmetric(vertical: 6),
              child: LinearProgressIndicator(minHeight: 2)),
        if (_error != null)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Align(
                alignment: AlignmentDirectional.centerStart,
                child: Text(_error!, style: const TextStyle(color: Colors.red))),
          ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 6, 12, 10),
            child: Row(children: [
              Expanded(
                child: TextField(
                  controller: _input,
                  minLines: 1,
                  maxLines: 4,
                  enabled: !_busy,
                  textInputAction: TextInputAction.send,
                  onSubmitted: (_) => _onSend(),
                  decoration: const InputDecoration(hintText: 'اكتب طلبك هنا…'),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(
                onPressed: _busy ? null : _onSend,
                icon: const Icon(Icons.send_rounded),
              ),
            ]),
          ),
        ),
      ]),
    );
  }
}
