import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'chat_screen.dart';

/// Chat button for an order. Shows a red badge with the number of messages from the
/// other party that have not been read yet; updates live while the order screen is open.
class ChatButton extends StatefulWidget {
  final String orderId;
  final String label;
  final String chatTitle;
  final bool filled;
  const ChatButton({
    super.key,
    required this.orderId,
    required this.label,
    required this.chatTitle,
    this.filled = false,
  });

  @override
  State<ChatButton> createState() => _ChatButtonState();
}

class _ChatButtonState extends State<ChatButton> {
  final _db = Supabase.instance.client;
  DateTime? _readAt;

  late final Stream<List<Map<String, dynamic>>> _stream = _db
      .from('order_messages')
      .stream(primaryKey: ['id']).eq('order_id', widget.orderId);

  @override
  void initState() {
    super.initState();
    _loadReadAt();
  }

  Future<void> _loadReadAt() async {
    try {
      final me = _db.auth.currentUser?.id;
      if (me == null) return;
      final row = await _db
          .from('order_chat_read')
          .select('read_at')
          .eq('user_id', me)
          .eq('order_id', widget.orderId)
          .maybeSingle();
      if (!mounted) return;
      setState(() => _readAt = row == null ? null : DateTime.parse(row['read_at'] as String));
    } catch (_) {}
  }

  Future<void> _open() async {
    await Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => ChatScreen(orderId: widget.orderId, title: widget.chatTitle)));
    await _loadReadAt();
  }

  @override
  Widget build(BuildContext context) {
    final me = _db.auth.currentUser?.id;
    return StreamBuilder<List<Map<String, dynamic>>>(
      stream: _stream,
      builder: (context, snap) {
        final msgs = snap.data ?? const <Map<String, dynamic>>[];
        final unread = msgs.where((m) {
          if (m['sender_id'] == me) return false;
          final at = DateTime.tryParse('${m['created_at']}');
          return at != null && (_readAt == null || at.isAfter(_readAt!));
        }).length;

        final icon = Icon(unread > 0 ? Icons.mark_chat_unread : Icons.chat_bubble_outline);
        final label = Text(widget.label);
        final button = widget.filled
            ? FilledButton.icon(onPressed: _open, icon: icon, label: label)
            : OutlinedButton.icon(
                style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(48)),
                onPressed: _open,
                icon: icon,
                label: label,
              );
        return Badge(
          isLabelVisible: unread > 0,
          label: Text('$unread'),
          backgroundColor: Colors.red,
          alignment: AlignmentDirectional.topStart,
          offset: const Offset(6, -4),
          child: SizedBox(width: double.infinity, child: button),
        );
      },
    );
  }
}
