import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

String _complaintError(Object e) {
  final m = e.toString();
  if (m.contains('complaint_too_short')) return 'اكتب تفاصيل الشكوى (5 أحرف على الأقل)';
  if (m.contains('phone_required')) return 'اكتب رقم هاتف صحيح للتواصل معك';
  if (m.contains('order_not_accepted')) return 'لا يمكن تقديم شكوى قبل قبول الطلب';
  if (m.contains('order_not_found')) return 'الطلب غير موجود';
  return 'تعذر إرسال الشكوى، حاول مرة أخرى';
}

/// Button + status of the customer's complaints for one order.
class ComplaintSection extends StatefulWidget {
  final String orderId;
  final String orderNumber;
  const ComplaintSection({super.key, required this.orderId, required this.orderNumber});

  @override
  State<ComplaintSection> createState() => _ComplaintSectionState();
}

class _ComplaintSectionState extends State<ComplaintSection> {
  final _db = Supabase.instance.client;
  List<Map<String, dynamic>> _mine = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final me = _db.auth.currentUser?.id;
      if (me == null) return;
      final rows = await _db
          .from('complaints')
          .select('id, status, admin_note, created_at')
          .eq('order_id', widget.orderId)
          .eq('customer_id', me)
          .order('created_at', ascending: false);
      if (mounted) setState(() => _mine = List<Map<String, dynamic>>.from(rows));
    } catch (_) {}
  }

  Future<void> _open() async {
    final sent = await Navigator.of(context).push<bool>(MaterialPageRoute(
        builder: (_) => ComplaintScreen(orderId: widget.orderId, orderNumber: widget.orderNumber)));
    if (sent == true) _load();
  }

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      for (final c in _mine)
        Padding(
          padding: const EdgeInsets.only(bottom: 6),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: (c['status'] == 'open' ? Colors.orange : Colors.green).withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(c['status'] == 'open'
                ? 'شكواك قيد المراجعة من الإدارة'
                : 'تمت معالجة شكواك${(c['admin_note'] ?? '').toString().isEmpty ? '' : ': ${c['admin_note']}'}'),
          ),
        ),
      OutlinedButton.icon(
        style: OutlinedButton.styleFrom(
            minimumSize: const Size.fromHeight(48), foregroundColor: Colors.red.shade700),
        onPressed: _open,
        icon: const Icon(Icons.report_gmailerrorred_outlined),
        label: const Text('تقديم شكوى'),
      ),
    ]);
  }
}

class ComplaintScreen extends StatefulWidget {
  final String orderId;
  final String orderNumber;
  const ComplaintScreen({super.key, required this.orderId, required this.orderNumber});

  @override
  State<ComplaintScreen> createState() => _ComplaintScreenState();
}

class _ComplaintScreenState extends State<ComplaintScreen> {
  final _db = Supabase.instance.client;
  final _body = TextEditingController();
  final _phone = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _prefillPhone();
  }

  Future<void> _prefillPhone() async {
    try {
      final me = _db.auth.currentUser?.id;
      if (me == null) return;
      final p = await _db.from('profiles').select('phone').eq('id', me).maybeSingle();
      final phone = p?['phone'] as String?;
      if (mounted && phone != null && _phone.text.isEmpty) _phone.text = phone;
    } catch (_) {}
  }

  Future<void> _send() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await _db.rpc('submit_complaint', params: {
        'p_order': widget.orderId,
        'p_body': _body.text.trim(),
        'p_phone': _phone.text.trim(),
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('وصلت شكواك إلى الإدارة وسنتواصل معك قريباً')));
      Navigator.pop(context, true);
    } catch (e) {
      setState(() => _error = _complaintError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تقديم شكوى')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('الطلب #${widget.orderNumber}',
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                const SizedBox(height: 4),
                Row(children: [
                  Expanded(
                    child: Text('معرّف الطلب: ${widget.orderId}',
                        textDirection: TextDirection.ltr,
                        style: const TextStyle(fontSize: 11, color: Colors.black54)),
                  ),
                  IconButton(
                    tooltip: 'نسخ',
                    onPressed: () async {
                      await Clipboard.setData(ClipboardData(text: widget.orderId));
                      if (context.mounted) {
                        ScaffoldMessenger.of(context)
                            .showSnackBar(const SnackBar(content: Text('تم نسخ معرّف الطلب')));
                      }
                    },
                    icon: const Icon(Icons.copy, size: 18),
                  ),
                ]),
                const Text('يُرفق معرّف الطلب تلقائياً مع شكواك.',
                    style: TextStyle(fontSize: 12, color: Colors.black54)),
              ]),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _body,
            maxLines: 6,
            maxLength: 2000,
            decoration: const InputDecoration(
                labelText: 'اكتب شكواك *', hintText: 'اشرح ما حدث بالتفصيل'),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _phone,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(
                labelText: 'رقم الهاتف للتواصل معك *', hintText: '05xxxxxxxx'),
          ),
          if (_error != null) ...[
            const SizedBox(height: 12),
            Text(_error!, style: const TextStyle(color: Colors.red)),
          ],
          const SizedBox(height: 16),
          FilledButton(
            onPressed: _busy ? null : _send,
            child: _busy
                ? const SizedBox(
                    height: 22,
                    width: 22,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Text('إرسال الشكوى'),
          ),
        ],
      ),
    );
  }
}
