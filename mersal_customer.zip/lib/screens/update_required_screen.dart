import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/logo.dart';

/// Blocks the app until the user installs the required version. The back button does nothing.
class UpdateRequiredScreen extends StatelessWidget {
  final String url;
  final String message;
  const UpdateRequiredScreen({super.key, required this.url, required this.message});

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const MersalLogo(markSize: 96),
              const SizedBox(height: 28),
              Text(message,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
              const SizedBox(height: 24),
              FilledButton(
                onPressed: () => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication),
                child: const Text('تحديث'),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}
