import 'dart:async';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';
import '../core/logo.dart';
import '../core/app_update.dart';
import '../core/push.dart';
import 'bootstrap_screen.dart';

/// First screen. It draws immediately (the logo is never blocked by network or Firebase),
/// then initialises the services step by step. If a step is slow or fails, the screen says
/// which step and offers a retry instead of waiting forever.
class StartupScreen extends StatefulWidget {
  const StartupScreen({super.key});

  @override
  State<StartupScreen> createState() => _StartupScreenState();
}

class _StartupScreenState extends State<StartupScreen> {
  static bool _supabaseReady = false;
  String _step = 'تشغيل التطبيق…';
  String? _error;

  @override
  void initState() {
    super.initState();
    _run();
  }

  Future<void> _run() async {
    setState(() {
      _error = null;
      _step = 'الاتصال بالخدمة…';
    });
    try {
      if (!_supabaseReady) {
        await Supabase.initialize(url: AppConfig.supabaseUrl, anonKey: AppConfig.supabaseKey)
            .timeout(const Duration(seconds: 20));
        _supabaseReady = true;
      }
      setState(() => _step = 'تجهيز الإشعارات…');
      Push.init(); // never awaited: notifications must not block the app
      if (await checkAppUpdate()) return;
      if (!mounted) return;
      Navigator.of(context)
          .pushReplacement(MaterialPageRoute(builder: (_) => const BootstrapScreen()));
    } on TimeoutException {
      if (mounted) setState(() => _error = 'انتهت مهلة الاتصال أثناء: $_step\nتأكد من الإنترنت ثم أعد المحاولة.');
    } catch (e) {
      if (mounted) setState(() => _error = 'تعذر بدء التطبيق أثناء: $_step\n$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const MersalLogo(markSize: 110),
              const SizedBox(height: 24),
              if (_error == null) ...[
                const CircularProgressIndicator(),
                const SizedBox(height: 12),
                Text(_step, style: const TextStyle(color: Colors.black54)),
              ] else ...[
                Text(_error!, textAlign: TextAlign.center),
                const SizedBox(height: 16),
                FilledButton(onPressed: _run, child: const Text('إعادة المحاولة')),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
