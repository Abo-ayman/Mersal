import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/theme.dart';

/// Verifies the customer's Syrian mobile number with an SMS code (Firebase Phone Auth).
/// The server then stores the verified number on the customer's profile.
class PhoneVerifyScreen extends StatefulWidget {
  const PhoneVerifyScreen({super.key});

  @override
  State<PhoneVerifyScreen> createState() => _PhoneVerifyScreenState();
}

class _PhoneVerifyScreenState extends State<PhoneVerifyScreen> {
  final _phone = TextEditingController();
  final _code = TextEditingController();
  String? _verificationId;
  bool _busy = false;
  String? _error;

  /// Accepts 9xxxxxxxx (Syrian mobile) and returns +963 format, or null.
  String? get _e164 {
    var d = _phone.text.replaceAll(RegExp(r'[^0-9]'), '');
    if (d.startsWith('00963')) d = d.substring(5);
    if (d.startsWith('963')) d = d.substring(3);
    if (d.startsWith('0')) d = d.substring(1);
    return RegExp(r'^9\d{8}$').hasMatch(d) ? '+963$d' : null;
  }

  Future<void> _sendCode() async {
    final phone = _e164;
    if (phone == null) {
      setState(() => _error = 'اكتب رقم الهاتف السوري مثل 944123456');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: phone,
      timeout: const Duration(seconds: 60),
      verificationCompleted: (cred) async {
        // Android can read the SMS by itself
        await _finish(cred);
      },
      verificationFailed: (e) {
        if (!mounted) return;
        setState(() {
          _busy = false;
          _error = e.code == 'too-many-requests'
              ? 'طلبات كثيرة، حاول لاحقاً'
              : 'تعذر إرسال الرمز. تحقق من الرقم ومن الإنترنت.';
        });
      },
      codeSent: (id, _) {
        if (!mounted) return;
        setState(() {
          _verificationId = id;
          _busy = false;
        });
      },
      codeAutoRetrievalTimeout: (id) => _verificationId = id,
    );
  }

  Future<void> _confirmCode() async {
    final id = _verificationId;
    if (id == null || _code.text.trim().length != 6) {
      setState(() => _error = 'اكتب الرمز المكوّن من 6 أرقام');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await _finish(PhoneAuthProvider.credential(verificationId: id, smsCode: _code.text.trim()));
    } on FirebaseAuthException {
      if (mounted) setState(() {
            _busy = false;
            _error = 'الرمز غير صحيح أو منتهي الصلاحية';
          });
    }
  }

  Future<void> _finish(AuthCredential cred) async {
    try {
      final result = await FirebaseAuth.instance.signInWithCredential(cred);
      final idToken = await result.user?.getIdToken();
      await FirebaseAuth.instance.signOut(); // Firebase is only used to prove the number
      if (idToken == null) throw Exception('no_token');
      final res = await Supabase.instance.client.functions
          .invoke('verify-phone', body: {'id_token': idToken});
      final data = Map<String, dynamic>.from(res.data as Map);
      if (data['error'] != null) throw Exception('${data['error']}');
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم توثيق رقمك بنجاح')));
      Navigator.of(context).pop(true);
    } catch (e) {
      final m = e.toString();
      if (!mounted) return;
      setState(() {
        _busy = false;
        _error = m.contains('phone_in_use')
            ? 'هذا الرقم موثّق على حساب آخر'
            : m.contains('unsupported_phone')
                ? 'الرقم يجب أن يكون سورياً'
                : 'تعذر توثيق الرقم، حاول مرة أخرى';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final sent = _verificationId != null;
    return Scaffold(
      appBar: AppBar(title: const Text('توثيق رقم الهاتف')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('نحتاج رقمك لنتمكن من التواصل معك بشأن الطلب. يُرسل إليك رمز عبر SMS.',
              style: TextStyle(fontSize: 15)),
          const SizedBox(height: 18),
          Row(children: [
            const Text('+963', style: TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _phone,
                keyboardType: TextInputType.phone,
                enabled: !sent && !_busy,
                decoration: const InputDecoration(hintText: '9xxxxxxxx'),
              ),
            ),
          ]),
          const SizedBox(height: 12),
          if (!sent)
            FilledButton(
              onPressed: _busy ? null : _sendCode,
              child: _busy
                  ? const SizedBox(height: 22, width: 22,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Text('إرسال الرمز'),
            )
          else ...[
            TextField(
              controller: _code,
              keyboardType: TextInputType.number,
              maxLength: 6,
              decoration: const InputDecoration(labelText: 'الرمز المكوّن من 6 أرقام'),
            ),
            const SizedBox(height: 8),
            FilledButton(
              onPressed: _busy ? null : _confirmCode,
              child: _busy
                  ? const SizedBox(height: 22, width: 22,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Text('تأكيد الرمز'),
            ),
          ],
          if (_error != null) ...[
            const SizedBox(height: 12),
            Text(_error!, style: const TextStyle(color: Colors.red)),
          ],
        ],
      ),
    );
  }
}
