import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/theme.dart';

/// The customer's notifications: order updates and announcements sent by the admin.
class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

const _kinds = [
  'accepted',
  'ready',
  'on_the_way',
  'arrived',
  'delivered',
  'rejected',
  'cancelled',
  'auto_cancelled',
  'invoice',
  'quote_ready',
  'proximity',
];

class _NotificationsScreenState extends State<NotificationsScreen> {
  List<Map<String, dynamic>>? _items;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final rows = await Supabase.instance.client
          .from('notifications')
          .select('id, title, body, created_at')
          // only the important ones: order status changes, price and invoice notices, announcements.
          // chat messages, complaints and driver-only alerts are left out.
          .or('kind.in.(${_kinds.join(',')}),kind.like.price:%,kind.like.broadcast:%')
          .order('created_at', ascending: false)
          .limit(100);
      if (mounted) {
        setState(() {
          _items = List<Map<String, dynamic>>.from(rows);
          _failed = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _failed = true);
    }
  }

  String _when(String iso) {
    final d = DateTime.parse(iso).toLocal();
    String two(int n) => n.toString().padLeft(2, '0');
    return '${d.day}/${d.month}  ${two(d.hour)}:${two(d.minute)}';
  }

  @override
  Widget build(BuildContext context) {
    final items = _items;
    return Scaffold(
      appBar: AppBar(title: const Text('التنبيهات')),
      body: items == null
          ? Center(
              child: _failed
                  ? TextButton(onPressed: _load, child: const Text('تعذر التحميل، أعد المحاولة'))
                  : const CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: items.isEmpty
                  ? ListView(children: const [
                      SizedBox(height: 120),
                      Center(child: Text('لا توجد تنبيهات بعد')),
                    ])
                  : ListView.separated(
                      padding: const EdgeInsets.all(16),
                      itemCount: items.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 8),
                      itemBuilder: (_, i) {
                        final n = items[i];
                        return Card(
                          child: ListTile(
                            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                            leading: const Icon(Icons.notifications_active_outlined, color: Brand.primary),
                            title: Text(n['title'] as String,
                                style: const TextStyle(fontWeight: FontWeight.w800)),
                            subtitle: Text(n['body'] as String),
                            trailing: Text(_when(n['created_at'] as String),
                                style: const TextStyle(fontSize: 11, color: Colors.black54)),
                          ),
                        );
                      },
                    ),
            ),
    );
  }
}
