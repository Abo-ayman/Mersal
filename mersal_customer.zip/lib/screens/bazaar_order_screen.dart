import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';

import '../data/order_repository.dart';
import '../data/routing_service.dart';
import 'fee_card.dart';
import 'location_picker.dart';
import 'my_orders_screen.dart';

/// Weekly bazaar order: the customer lists what he needs from the bazaar (vegetables, fruit...)
/// and the driver buys and delivers it on bazaar day. Booking window and prices come from the server.
class BazaarOrderScreen extends StatefulWidget {
  final Map<String, dynamic> service; // row of bazaar_status()
  const BazaarOrderScreen({super.key, required this.service});

  @override
  State<BazaarOrderScreen> createState() => _BazaarOrderScreenState();
}

class _BazaarOrderScreenState extends State<BazaarOrderScreen> {
  final _repo = OrderRepository();
  final _routing = OsrmRoutingService();
  final _items = TextEditingController();
  final _phone = TextEditingController();
  final _notes = TextEditingController();
  LatLng? _location;
  int? _distanceM;
  Map<String, dynamic>? _fee;
  bool _routeBusy = false;
  String? _routeError;
  bool _busy = false;
  String? _error;

  String get _day => '${widget.service['delivery_day_text'] ?? 'الثلاثاء'}';

  @override
  void initState() {
    super.initState();
    _repo.getProfile().then((p) {
      final phone = p['phone'] as String?;
      if (mounted && phone != null && _phone.text.isEmpty) _phone.text = phone;
    });
  }

  Future<void> _pickLocation() async {
    final res = await Navigator.of(context).push<LatLng>(
        MaterialPageRoute(builder: (_) => LocationPicker(initial: _location)));
    if (res != null) {
      setState(() => _location = res);
      _calcFee();
    }
  }

  Future<void> _calcFee() async {
    final loc = _location;
    if (loc == null) return;
    setState(() {
      _routeBusy = true;
      _routeError = null;
      _distanceM = null;
      _fee = null;
    });
    try {
      final city = await _repo.resolveCity(loc.latitude, loc.longitude);
      if (!mounted) return;
      if (city == null) {
        setState(() {
          _routeBusy = false;
          _routeError = friendlyError('city_not_supported');
        });
        return;
      }
      final m = await _routing.drivingDistanceMeters(
        fromLat: (city['center_lat'] as num).toDouble(),
        fromLon: (city['center_lon'] as num).toDouble(),
        toLat: loc.latitude,
        toLon: loc.longitude,
      );
      if (!mounted) return;
      if (m == null) {
        setState(() {
          _routeBusy = false;
          _routeError = 'تعذر حساب مسافة التوصيل. تحقق من الاتصال وأعد المحاولة.';
        });
        return;
      }
      final fee = await _repo.feePreviewService(
          widget.service['service_id'] as String, loc.latitude, loc.longitude, m);
      if (!mounted) return;
      setState(() {
        _distanceM = m;
        _fee = fee;
        _routeBusy = false;
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          _routeBusy = false;
          _routeError = 'تعذر حساب أجرة التوصيل. أعد المحاولة.';
        });
      }
    }
  }

  Future<void> _submit() async {
    if (_items.text.trim().length < 3) {
      setState(() => _error = 'اكتب قائمة أغراضك من البيزار');
      return;
    }
    if (_location == null) {
      setState(() => _error = 'حدد موقع التوصيل على الخريطة');
      return;
    }
    if (_distanceM == null) {
      setState(() => _error = 'انتظر حساب أجرة التوصيل أو أعد المحاولة');
      return;
    }
    if (_phone.text.trim().length < 7) {
      setState(() => _error = 'اكتب رقم هاتف صحيح للتواصل');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await _repo.createBazaarOrder(
        items: _items.text.trim(),
        address: null,
        lat: _location!.latitude,
        lon: _location!.longitude,
        phone: _phone.text.trim(),
        notes: _notes.text.trim().isEmpty ? null : _notes.text.trim(),
        routeDistanceM: _distanceM!,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تم إرسال طلب البيزار. سيصلك يوم $_day بإذن الله.')));
      Navigator.of(context)
          .pushReplacement(MaterialPageRoute(builder: (_) => const MyOrdersScreen()));
    } catch (e) {
      setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _feeArea() {
    if (_routeBusy) {
      return const Card(
          child: Padding(
              padding: EdgeInsets.all(14),
              child: Row(children: [
                SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2)),
                SizedBox(width: 12),
                Text('جارٍ حساب أجرة التوصيل...'),
              ])));
    }
    if (_routeError != null) {
      return Card(
          child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(_routeError!, style: const TextStyle(color: Colors.red)),
                TextButton(onPressed: _calcFee, child: const Text('إعادة المحاولة')),
              ])));
    }
    if (_fee == null) return const SizedBox.shrink();
    return FeeCard(fee: _fee!);
  }

  @override
  Widget build(BuildContext context) {
    const bazaarColor = Color(0xFFEA580C);
    return Scaffold(
      appBar: AppBar(title: Text('${widget.service['name'] ?? 'طلب بيزار'}')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: bazaarColor.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: bazaarColor.withValues(alpha: 0.4)),
            ),
            child: Text(
              'اكتب كل ما تحتاجه من البيزار (خضار وفواكه وغيرها) وسنجهّز لك خضرة بيتك '
              'الأسبوعية ونوصلها لبيتك يوم $_day. تدفع نقداً عند التسليم.',
            ),
          ),
          const SizedBox(height: 12),
          TextField(
              controller: _items,
              maxLines: 8,
              decoration: const InputDecoration(
                  labelText: 'قائمة أغراضك من البيزار *',
                  hintText: 'مثال:\n3 كيلو بندورة\n2 كيلو بطاطا\n1 كيلو تفاح\nحزمة بقدونس')),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: _pickLocation,
            icon: const Icon(Icons.place_outlined),
            label: Text(_location == null ? 'حدد موقع التوصيل *' : 'تم تحديد الموقع ✓'),
          ),
          if (_location != null) ...[
            const SizedBox(height: 12),
            _feeArea(),
          ],
          const SizedBox(height: 12),
          TextField(
              controller: _phone,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'رقم الهاتف *')),
          const SizedBox(height: 12),
          TextField(
              controller: _notes,
              maxLines: 2,
              decoration: const InputDecoration(labelText: 'ملاحظات إضافية')),
          if (_error != null) ...[
            const SizedBox(height: 12),
            Text(_error!, style: const TextStyle(color: Colors.red)),
          ],
          const SizedBox(height: 16),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: bazaarColor),
            onPressed: _busy ? null : _submit,
            child: _busy
                ? const SizedBox(
                    height: 22,
                    width: 22,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Text('إرسال طلب البيزار'),
          ),
        ],
      ),
    );
  }
}
