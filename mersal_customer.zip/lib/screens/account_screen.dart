import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/ico3d.dart';
import '../core/theme.dart';
import 'my_orders_screen.dart';
import 'name_screen.dart';

/// The customer's account: name, orders, and the app version.
class AccountScreen extends StatefulWidget {
  const AccountScreen({super.key});

  @override
  State<AccountScreen> createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  String _name = '';
  String _version = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final info = await PackageInfo.fromPlatform();
    var name = '';
    try {
      final uid = Supabase.instance.client.auth.currentUser?.id;
      if (uid != null) {
        final row = await Supabase.instance.client
            .from('profiles')
            .select('display_name')
            .eq('id', uid)
            .maybeSingle();
        name = (row?['display_name'] ?? '') as String;
      }
    } catch (_) {}
    if (mounted) {
      setState(() {
        _name = name;
        _version = 'الإصدار ${info.version} (${info.buildNumber})';
      });
    }
  }

  Future<void> _editName() async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const NameScreen()));
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('حسابي')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              contentPadding: const EdgeInsets.all(16),
              leading: const Ico3D('user', size: 48),
              title: Text(_name.isEmpty ? 'زبون مرسال' : _name,
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
              subtitle: const Text('اضغط لتعديل الاسم'),
              trailing: const Icon(Icons.edit_outlined, color: Brand.primary),
              onTap: _editName,
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              leading: const Icon(Icons.receipt_long_rounded, color: Brand.primary),
              title: const Text('طلباتي', style: TextStyle(fontWeight: FontWeight.w700)),
              trailing: const Icon(Icons.chevron_left),
              onTap: () => Navigator.of(context)
                  .push(MaterialPageRoute(builder: (_) => const MyOrdersScreen())),
            ),
          ),
          const SizedBox(height: 32),
          Center(
            child: Text(_version, style: const TextStyle(fontSize: 12, color: Colors.black45)),
          ),
        ],
      ),
    );
  }
}
