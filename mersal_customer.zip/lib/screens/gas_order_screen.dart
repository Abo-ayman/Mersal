import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';

import '../core/theme.dart';
import '../data/order_repository.dart';
import 'location_picker.dart';
import 'my_orders_screen.dart';

/// Gas cylinder exchange (Maskanah): flat 300 SYP. The driver comes to the home first to take
/// the empty cylinder, then brings a full one.
class GasOrderScreen extends StatefulWidget {
  const GasOrderScreen({super.key});

  @override
  State<GasOrderScreen> createState() => _GasOrderScreenState();
}

class _GasOrderScreenState extends State<GasOrderScreen> {
  final _repo = OrderRepository();
  final _phone = TextEditingController();
  final _notes = TextEditingController();
  LatLng? _location;
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _repo.getProfile().then((p) {
      final phone = p['phone'] as String?;
      if (mounted && phone != null && _phone.text.isEmpty) _phone.text = phone;
    }).catchError((_) {});
  }

  Future<void> _pickLocation() async {
    final res = await Navigator.of(context).push<LatLng>(
        MaterialPageRoute(builder: (_) => LocationPicker(initial: _location)));
    if (res != null) setState(() => _location = res);
  }

  Future<void> _submit() async {
    if (_location == null) {
      setState(() => _error = 'حدد موقع منزلك على الخريطة');
      return;
    }
    if (_phone.text.trim().length < 7) {
      setState(() => _error = 'اكتب رقم هاتف صحيح للتواصل');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await _repo.createGasOrder(
        lat: _location!.latitude,
        lon: _location!.longitude,
        address: 'حسب الموقع المحدد على الخريطة',
        phone: _phone.text.trim(),
        notes: _notes.text.trim().isEmpty ? null : _notes.text.trim(),
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم إرسال طلب الغاز. سيأتي السائق لأخذ الأسطوانة الفارغة.')));
      Navigator.of(context)
          .pushReplacement(MaterialPageRoute(builder: (_) => const MyOrdersScreen()));
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    const gasColor = Color(0xFFEA580C);
    return Scaffold(
      appBar: AppBar(title: const Text('توصيل الغاز')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: gasColor.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: gasColor.withValues(alpha: 0.4)),
            ),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('سعر التوصيل: 300 ل.س', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              SizedBox(height: 10),
              Text('كيف تعمل الخدمة؟', style: TextStyle(fontWeight: FontWeight.w800)),
              SizedBox(height: 4),
              Text('1) يأتي السائق أولاً إلى منزلك لأخذ الأسطوانة الفارغة.'),
              Text('2) يبدّلها ويوصل لك الأسطوانة الجديدة إلى المكان نفسه.'),
              SizedBox(height: 8),
              Text('سعر الأسطوانة يُدفع للسائق عند التبديل، وسعر التوصيل 300 ل.س.',
                  style: TextStyle(color: Colors.black54)),
            ]),
          ),
          const SizedBox(height: 14),
          OutlinedButton.icon(
            onPressed: _busy ? null : _pickLocation,
            icon: const Icon(Icons.home_outlined),
            label: Text(_location == null ? 'حدد موقع منزلك على الخريطة *' : 'تم تحديد الموقع ✓'),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _phone,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(labelText: 'رقم الهاتف *'),
          ),
          const SizedBox(height: 10),
          TextField(
              controller: _notes,
              maxLines: 2,
              decoration: const InputDecoration(
                  labelText: 'ملاحظات (مثال: الطابق، بجانب الصيدلية)')),
          if (_error != null) ...[
            const SizedBox(height: 10),
            Text(_error!, style: const TextStyle(color: Colors.red)),
          ],
          const SizedBox(height: 16),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: gasColor),
            onPressed: _busy ? null : _submit,
            child: _busy
                ? const SizedBox(
                    height: 22,
                    width: 22,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Text('إرسال طلب الغاز'),
          ),
        ],
      ),
    );
  }
}
