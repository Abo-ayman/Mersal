import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';

import '../core/theme.dart';
import '../data/order_repository.dart';
import '../data/route_total.dart';
import 'fee_card.dart';
import 'location_picker.dart';
import 'my_orders_screen.dart';

/// Order of one store product. The store point is known, so the delivery fee is computed from
/// market -> store -> customer as soon as the customer picks the delivery point.
class StoreOrderScreen extends StatefulWidget {
  final Map<String, dynamic> product;
  final Map<String, dynamic> store;
  final String currency;
  const StoreOrderScreen({super.key, required this.product, required this.store, required this.currency});

  @override
  State<StoreOrderScreen> createState() => _StoreOrderScreenState();
}

class _StoreOrderScreenState extends State<StoreOrderScreen> {
  final _repo = OrderRepository();
  final _phone = TextEditingController();
  final _notes = TextEditingController();
  int _qty = 1;
  LatLng? _location;
  int? _distanceM;
  Map<String, dynamic>? _fee;
  bool _busy = false;
  String? _error;

  num get _price => widget.product['price'] as num;

  @override
  void initState() {
    super.initState();
    _repo.getProfile().then((p) {
      final phone = p['phone'] as String?;
      if (mounted && phone != null && _phone.text.isEmpty) _phone.text = phone;
    }).catchError((_) {});
  }

  @override
  void dispose() {
    _phone.dispose();
    _notes.dispose();
    super.dispose();
  }

  LatLng get _storePoint => LatLng((widget.store['latitude'] as num).toDouble(),
      (widget.store['longitude'] as num).toDouble());

  Future<void> _pickLocation() async {
    final res = await Navigator.of(context)
        .push<LatLng>(MaterialPageRoute(builder: (_) => LocationPicker(initial: _location)));
    if (res == null) return;
    setState(() {
      _location = res;
      _distanceM = null;
      _fee = null;
      _busy = true;
      _error = null;
    });
    try {
      final city = await _repo.resolveCity(res.latitude, res.longitude);
      if (city == null) throw Exception('outside');
      final m = await tripDistanceM(
        centerLat: (city['center_lat'] as num).toDouble(),
        centerLon: (city['center_lon'] as num).toDouble(),
        store: _storePoint,
        customer: res,
      );
      if (m == null) throw Exception('route');
      final fee = await _repo.feePreview(res.latitude, res.longitude, m);
      if (!mounted) return;
      setState(() {
        _distanceM = m;
        _fee = fee;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _location = null;
        _error = e.toString().contains('outside')
            ? 'موقعك خارج مناطق خدمتنا.'
            : 'تعذر حساب أجرة التوصيل. اختر الموقع مرة أخرى.';
      });
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _submit() async {
    if (_location == null || _distanceM == null) {
      setState(() => _error = 'حدد موقع التوصيل وانتظر حساب الأجرة');
      return;
    }
    if (_phone.text.trim().length < 7) {
      setState(() => _error = 'اكتب رقم هاتف صحيح للتواصل');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await _repo.createStoreOrder(
        productId: '${widget.product['id']}',
        quantity: _qty,
        lat: _location!.latitude,
        lon: _location!.longitude,
        address: 'حسب الموقع المحدد على الخريطة',
        phone: _phone.text.trim(),
        notes: _notes.text.trim().isEmpty ? null : _notes.text.trim(),
        routeDistanceM: _distanceM!,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('تم إرسال طلبك، بانتظار قبول السائق.')));
      Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const MyOrdersScreen()), (r) => r.isFirst);
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cur = widget.currency;
    final items = _price * _qty;
    final num delivery = _fee == null ? 0 : (_fee!['delivery_total'] as num);
    final url = widget.product['image_url'] as String?;
    return Scaffold(
      appBar: AppBar(title: const Text('تأكيد الطلب')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: (url != null && url.isNotEmpty)
                      ? Image.network(url,
                          width: 72,
                          height: 72,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => const SizedBox(width: 72, height: 72))
                      : const SizedBox(width: 72, height: 72),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${widget.product['name']}',
                        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                    Text('من ${widget.store['name']}', style: const TextStyle(color: Colors.black54)),
                    Text('${fmt(_price)} $cur',
                        style: const TextStyle(color: Brand.primary, fontWeight: FontWeight.w800)),
                  ]),
                ),
                Column(children: [
                  IconButton(
                      onPressed: _qty < 20 ? () => setState(() => _qty++) : null,
                      icon: const Icon(Icons.add_circle_outline)),
                  Text('$_qty', style: const TextStyle(fontWeight: FontWeight.w900)),
                  IconButton(
                      onPressed: _qty > 1 ? () => setState(() => _qty--) : null,
                      icon: const Icon(Icons.remove_circle_outline)),
                ]),
              ]),
            ),
          ),
          const SizedBox(height: 14),
          OutlinedButton.icon(
            onPressed: _busy ? null : _pickLocation,
            icon: const Icon(Icons.place_outlined),
            label: Text(_location == null ? 'حدد موقع التوصيل *' : 'تم تحديد موقع التوصيل ✓'),
          ),
          if (_fee != null) ...[
            const SizedBox(height: 10),
            FeeCard(fee: _fee!),
            const SizedBox(height: 10),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(children: [
                  Row(children: [
                    const Text('سعر المنتج'),
                    const Spacer(),
                    Text('${fmt(items)} $cur'),
                  ]),
                  const SizedBox(height: 4),
                  Row(children: [
                    const Text('التوصيل'),
                    const Spacer(),
                    Text('${fmt(delivery)} $cur'),
                  ]),
                  const Divider(),
                  Row(children: [
                    const Text('الإجمالي نقداً عند التسليم',
                        style: TextStyle(fontWeight: FontWeight.w900)),
                    const Spacer(),
                    Text('${fmt(items + delivery)} $cur',
                        style: const TextStyle(fontWeight: FontWeight.w900, color: Brand.primary)),
                  ]),
                ]),
              ),
            ),
          ],
          const SizedBox(height: 10),
          TextField(
            controller: _phone,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(labelText: 'رقم الهاتف *'),
          ),
          const SizedBox(height: 10),
          TextField(
              controller: _notes,
              maxLines: 2,
              decoration: const InputDecoration(labelText: 'ملاحظات إضافية')),
          if (_error != null) ...[
            const SizedBox(height: 10),
            Text(_error!, style: const TextStyle(color: Colors.red)),
          ],
          const SizedBox(height: 16),
          FilledButton(
            style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
            onPressed: _busy ? null : _submit,
            child: _busy
                ? const SizedBox(
                    height: 22,
                    width: 22,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Text('إرسال الطلب'),
          ),
        ],
      ),
    );
  }
}
