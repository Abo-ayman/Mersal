import 'package:flutter/material.dart';

import '../data/order_repository.dart';

/// Delivery fee breakdown (used by the normal order form and the bazaar form).
/// Shows the new-customer discount when the server applied one.
class FeeCard extends StatelessWidget {
  final Map<String, dynamic> fee;
  const FeeCard({super.key, required this.fee});

  @override
  Widget build(BuildContext context) {
    final f = fee;
    final cur = (f['currency_symbol'] ?? 'ل.ت').toString();
    final discount = (f['discount_amount'] as num?) ?? 0;
    Widget row(String k, String v, {bool bold = false, Color? color}) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 2),
          child: Row(children: [
            Text(k, style: TextStyle(color: color)),
            const Spacer(),
            Text(v,
                style: TextStyle(
                    fontWeight: bold ? FontWeight.w800 : FontWeight.w500, color: color)),
          ]),
        );
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('أجرة التوصيل · ${f['city_name'] ?? ''}',
              style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          row('التوصيل الأساسي', '${fmt(f['base_fee'] as num)} $cur'),
          if ((f['distance_fee'] as num) > 0)
            row('رسوم المسافة', '${fmt(f['distance_fee'] as num)} $cur'),
          if ((f['time_fee'] as num) > 0)
            row(timeFeeLabel(f['time_fee_kind'], cur), '${fmt(f['time_fee'] as num)} $cur'),
          if (discount > 0) ...[
            const Divider(),
            row('الإجمالي قبل الخصم', '${fmt(f['gross_total'] as num)} $cur'),
            row('خصم المستخدم الجديد ${fmt((f['discount_percent'] as num?) ?? 0)}%',
                '- ${fmt(discount)} $cur',
                color: Colors.green.shade700),
          ],
          const Divider(),
          row('إجمالي التوصيل', '${fmt(f['delivery_total'] as num)} $cur', bold: true),
          const SizedBox(height: 6),
          const Text('سعر المنتجات يُدفع نقداً للسائق عند التسليم حسب سعرها الفعلي.',
              style: TextStyle(fontSize: 12, color: Colors.black54)),
        ]),
      ),
    );
  }
}
