import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../core/device_identity.dart';
import '../core/logo.dart';
import '../core/push.dart';
import '../data/order_repository.dart';
import 'home_screen.dart';
import 'name_screen.dart';
import 'phone_screen.dart';

class BootstrapScreen extends StatefulWidget {
  const BootstrapScreen({super.key});

  @override
  State<BootstrapScreen> createState() => _BootstrapScreenState();
}

class _BootstrapScreenState extends State<BootstrapScreen> {
  String? _error;
  String _step = 'تسجيل الدخول…';

  @override
  void initState() {
    super.initState();
    _start();
  }

  Future<void> _start() async {
    setState(() => _error = null);
    try {
      setState(() => _step = 'تسجيل الدخول…');
      await DeviceIdentity.ensureSignedIn().timeout(const Duration(seconds: 25));
      Push.register();
      setState(() => _step = 'تحميل حسابك…');
      final profile = await OrderRepository().getProfile().timeout(const Duration(seconds: 20));
      if (!mounted) return;
      final hasName = (profile['display_name'] as String?)?.isNotEmpty ?? false;
      final hasPhone = (profile['phone'] as String?)?.isNotEmpty ?? false;
      final Widget next = !hasName
          ? const NameScreen()
          : (kIsWeb && !hasPhone ? const PhoneScreen() : const HomeScreen());
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => next));
    } on TimeoutException {
      if (mounted) setState(() => _error = 'انتهت مهلة الاتصال أثناء: $_step\nتأكد من الإنترنت ثم أعد المحاولة.');
    } catch (e) {
      if (mounted) setState(() => _error = 'تعذر المتابعة أثناء: $_step\n$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const MersalLogo(markSize: 120),
              const SizedBox(height: 24),
              if (_error == null) ...[
                const CircularProgressIndicator(),
                const SizedBox(height: 12),
                Text(_step, style: const TextStyle(color: Colors.black54)),
              ] else ...[
                Text(_error!, textAlign: TextAlign.center),
                const SizedBox(height: 16),
                FilledButton(onPressed: _start, child: const Text('إعادة المحاولة')),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
