import 'dart:async';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/ico3d.dart';
import '../core/theme.dart';

/// After a taxi request: waits until a taxi accepts it and shows the order state.
class TaxiStatusScreen extends StatefulWidget {
  final String orderId;
  final String orderNumber;
  const TaxiStatusScreen({super.key, required this.orderId, required this.orderNumber});

  @override
  State<TaxiStatusScreen> createState() => _TaxiStatusScreenState();
}

class _TaxiStatusScreenState extends State<TaxiStatusScreen> {
  Timer? _timer;
  String _status = 'pending_driver';

  @override
  void initState() {
    super.initState();
    _refresh();
    _timer = Timer.periodic(const Duration(seconds: 10), (_) => _refresh());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _refresh() async {
    try {
      final row = await Supabase.instance.client
          .from('orders')
          .select('status')
          .eq('id', widget.orderId)
          .single();
      if (!mounted) return;
      setState(() => _status = (row['status'] ?? _status).toString());
    } catch (_) {}
  }

  String get _text {
    switch (_status) {
      case 'pending_driver':
        return 'جارٍ البحث عن تاكسي قريب منك...';
      case 'processing':
        return 'تم قبول طلبك، والتاكسي في الطريق إليك';
      case 'on_the_way':
        return 'الرحلة جارية';
      case 'delivered':
        return 'انتهت الرحلة';
      case 'cancelled':
        return 'أُلغي الطلب';
      default:
        return 'حالة الطلب: $_status';
    }
  }

  @override
  Widget build(BuildContext context) {
    final waiting = _status == 'pending_driver';
    return Scaffold(
      appBar: AppBar(title: Text('طلب تاكسي #${widget.orderNumber}')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Ico3D('taxi', size: 120),
            const SizedBox(height: 20),
            Text(_text,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Brand.primary)),
            const SizedBox(height: 16),
            if (waiting) const CircularProgressIndicator(),
          ]),
        ),
      ),
    );
  }
}
