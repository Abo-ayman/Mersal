import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/ico3d.dart';
import '../core/theme.dart';

/// The customer's taxi order: waits for a taxi, starts the trip, shows the taxi on the map,
/// and ends the trip with the amount to pay.
class TaxiStatusScreen extends StatefulWidget {
  final String orderId;
  final String orderNumber;
  const TaxiStatusScreen({super.key, required this.orderId, required this.orderNumber});

  @override
  State<TaxiStatusScreen> createState() => _TaxiStatusScreenState();
}

class _TaxiStatusScreenState extends State<TaxiStatusScreen> {
  Timer? _timer;
  String _status = 'pending_driver';
  String _currency = '';
  num? _amount;
  LatLng? _taxiAt;
  bool _busy = false;
  String? _error;
  DateTime? _createdAt;

  @override
  void initState() {
    super.initState();
    _refresh();
    _timer = Timer.periodic(const Duration(seconds: 10), (_) => _refresh());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _refresh() async {
    try {
      final row = await Supabase.instance.client
          .from('orders')
          .select('status, total, currency_symbol, created_at')
          .eq('id', widget.orderId)
          .single();
      if (!mounted) return;
      final st = row['status'].toString();
      setState(() {
        _status = st;
        _currency = (row['currency_symbol'] ?? '').toString();
        if (row['created_at'] != null) _createdAt = DateTime.parse(row['created_at'] as String).toLocal();
        if (st == 'delivered') _amount = row['total'] as num?;
      });
      if (st == 'processing' || st == 'on_the_way') {
        final rows = await Supabase.instance.client
            .rpc('order_driver_location', params: {'p_order': widget.orderId}) as List;
        if (!mounted) return;
        if (rows.isNotEmpty) {
          final m = rows.first as Map;
          if (m['lat'] != null && m['lon'] != null) {
            setState(() => _taxiAt = LatLng((m['lat'] as num).toDouble(), (m['lon'] as num).toDouble()));
          }
        }
      }
    } catch (_) {}
  }

  Future<void> _cancel() async {
    final age = _createdAt == null ? Duration.zero : DateTime.now().difference(_createdAt!);
    final fee = age < const Duration(minutes: 3) ? 0 : (age <= const Duration(minutes: 5) ? 10 : 30);
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('إلغاء الرحلة؟'),
        content: Text(fee == 0
            ? 'الإلغاء مجاني خلال أول 3 دقائق من طلب التاكسي.'
            : 'الإلغاء الآن سيفرض رسوم خروج التاكسي بقيمة $fee ل.ت، وتُضاف إلى حسابك ويجب سدادها عند كل دخول. إذا لم تُسدَّد خلال أسبوع يُوقَف حسابك حتى السداد.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('رجوع')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('إلغاء الرحلة')),
        ],
      ),
    );
    if (ok != true) return;
    setState(() => _busy = true);
    try {
      final charged = await Supabase.instance.client
          .rpc('taxi_cancel_order', params: {'p_order': widget.orderId}) as num;
      if (!mounted) return;
      setState(() => _status = 'cancelled');
      if (charged > 0) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(
            'تم الإلغاء، وأُضيفت رسوم خروج التاكسي بقيمة $charged ل.ت إلى حسابك')));
      }
    } catch (_) {
      if (mounted) setState(() => _error = 'تعذر إلغاء الرحلة، حاول مرة أخرى');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _startTrip() async {
    setState(() => _busy = true);
    try {
      await Supabase.instance.client.rpc('taxi_start_trip', params: {'p_order': widget.orderId});
      await _refresh();
    } catch (_) {
      if (mounted) setState(() => _error = 'تعذر بدء الرحلة، حاول مرة أخرى');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _endTrip() async {
    setState(() => _busy = true);
    try {
      final amount = await Supabase.instance.client
          .rpc('taxi_end_trip', params: {'p_order': widget.orderId}) as num;
      if (!mounted) return;
      setState(() {
        _status = 'delivered';
        _amount = amount;
      });
    } catch (_) {
      if (mounted) setState(() => _error = 'تعذر إنهاء الرحلة، حاول مرة أخرى');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String get _text {
    switch (_status) {
      case 'pending_driver':
        return 'جارٍ البحث عن تاكسي قريب منك...';
      case 'processing':
        return 'تم قبول طلبك، والتاكسي في الطريق إليك';
      case 'on_the_way':
        return 'الرحلة جارية';
      case 'delivered':
        return 'انتهت الرحلة';
      case 'cancelled':
        return 'أُلغي الطلب';
      default:
        return 'حالة الطلب: $_status';
    }
  }

  @override
  Widget build(BuildContext context) {
    final waiting = _status == 'pending_driver';
    final taxiAt = _taxiAt;
    return Scaffold(
      appBar: AppBar(title: Text('طلب تاكسي #${widget.orderNumber}')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Center(child: const Ico3D('taxi', size: 96)),
        const SizedBox(height: 14),
        Text(_text,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Brand.primary)),
        const SizedBox(height: 12),
        if (waiting) const Center(child: CircularProgressIndicator()),
        if (taxiAt != null && (_status == 'processing' || _status == 'on_the_way')) ...[
          SizedBox(
            height: 260,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: FlutterMap(
                options: MapOptions(initialCenter: taxiAt, initialZoom: 15),
                children: [
                  TileLayer(
                    urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                    userAgentPackageName: 'com.mersal.customer',
                  ),
                  MarkerLayer(markers: [
                    Marker(
                        point: taxiAt,
                        width: 40,
                        height: 40,
                        child: const Icon(Icons.local_taxi, color: Brand.primary, size: 36)),
                  ]),
                ],
              ),
            ),
          ),
          const SizedBox(height: 6),
          const Text('موقع التاكسي يتحدث تلقائياً', textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black54, fontSize: 12)),
        ],
        const SizedBox(height: 16),
        if (_status == 'processing')
          FilledButton(
            onPressed: _busy ? null : _startTrip,
            child: const Text('ركبت التاكسي وبدأت الرحلة'),
          ),
        if (_status == 'pending_driver' || _status == 'processing') ...[
          const SizedBox(height: 8),
          OutlinedButton(
            style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(48)),
            onPressed: _busy ? null : _cancel,
            child: const Text('إلغاء الرحلة'),
          ),
        ],
        if (_status == 'on_the_way')
          FilledButton(
            onPressed: _busy ? null : _endTrip,
            child: const Text('أنهيت رحلتي'),
          ),
        if (_status == 'delivered' && _amount != null)
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(children: [
              const Text('المبلغ المطلوب', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              Text('$_amount $_currency',
                  style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: Brand.primary)),
            ]),
          ),
        if (_error != null)
          Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.red)),
          ),
      ]),
    );
  }
}
