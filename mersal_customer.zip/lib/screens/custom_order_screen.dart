import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:latlong2/latlong.dart';

import '../data/order_repository.dart';
import '../data/routing_service.dart';
import 'fee_card.dart';
import '../data/route_total.dart';
import 'location_picker.dart';
import 'my_orders_screen.dart';

class CustomOrderScreen extends StatefulWidget {
  const CustomOrderScreen({super.key});

  @override
  State<CustomOrderScreen> createState() => _CustomOrderScreenState();
}

class _CustomOrderScreenState extends State<CustomOrderScreen> {
  final _repo = OrderRepository();
  final _desc = TextEditingController();
  final _store = TextEditingController();
  final _phone = TextEditingController();
  final _notes = TextEditingController();
  LatLng? _location;
  XFile? _image;
  bool _busy = false;
  String? _error;

  // delivery fee (road distance from the delivery center, computed with OSRM)
  final RoutingService _routing = OsrmRoutingService();
  int? _distanceM;
  bool _fromStore = false; // false = from the market (default), true = from a chosen store
  LatLng? _store;
  Map<String, dynamic>? _fee;
  bool _routeBusy = false;
  String? _routeError;

  @override
  void initState() {
    super.initState();
    _repo.getProfile().then((p) {
      final phone = p['phone'] as String?;
      if (mounted && phone != null && _phone.text.isEmpty) _phone.text = phone;
    });
  }

  Future<void> _pickImage() async {
    final f = await ImagePicker()
        .pickImage(source: ImageSource.gallery, maxWidth: 1280, imageQuality: 80);
    if (f != null) setState(() => _image = f);
  }

  Future<void> _pickLocation() async {
    final res = await Navigator.of(context).push<LatLng>(
        MaterialPageRoute(builder: (_) => LocationPicker(initial: _location)));
    if (res != null) {
      setState(() => _location = res);
      _calcRoute();
    }
  }

  Future<void> _calcRoute() async {
    final loc = _location;
    if (loc == null) return;
    setState(() {
      _routeBusy = true;
      _routeError = null;
      _distanceM = null;
      _fee = null;
    });
    // 1) which served city is the delivery point in?
    Map<String, dynamic>? city;
    try {
      city = await _repo.resolveCity(loc.latitude, loc.longitude);
    } catch (_) {
      if (mounted) {
        setState(() {
          _routeBusy = false;
          _routeError = 'تعذر تحديد المدينة. تحقق من الاتصال وأعد المحاولة.';
        });
      }
      return;
    }
    if (!mounted) return;
    if (city == null) {
      setState(() {
        _routeBusy = false;
        _routeError = friendlyError('city_not_supported');
      });
      return;
    }
    if (_fromStore && _store == null) {
      setState(() {
        _routeBusy = false;
        _routeError = 'حدد موقع المتجر على الخريطة';
      });
      return;
    }
    // 2) road distance of the whole trip: market -> (store) -> customer
    final m = await tripDistanceM(
      centerLat: (city['center_lat'] as num).toDouble(),
      centerLon: (city['center_lon'] as num).toDouble(),
      store: _fromStore ? _store : null,
      customer: loc,
    );
    if (!mounted) return;
    if (m == null) {
      setState(() {
        _routeBusy = false;
        _routeError = 'تعذر حساب مسافة التوصيل. تحقق من الاتصال وأعد المحاولة.';
      });
      return;
    }
    try {
      final fee = await _repo.feePreview(loc.latitude, loc.longitude, m);
      if (!mounted) return;
      setState(() {
        _distanceM = m;
        _fee = fee;
        _routeBusy = false;
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          _routeBusy = false;
          _routeError = 'تعذر حساب أجرة التوصيل. أعد المحاولة.';
        });
      }
    }
  }

  /// The order has no separate title any more: it is taken from the first line of the description.
  String _titleFrom(String description) {
    final first = description.trim().split('\n').first.trim();
    return first.length <= 40 ? first : '${first.substring(0, 40)}…';
  }

  Future<void> _submit() async {
    if (_desc.text.trim().length < 3) {
      setState(() => _error = 'اكتب وصف ما تريده');
      return;
    }
    if (_location == null) {
      setState(() => _error = 'حدد موقع التوصيل على الخريطة');
      return;
    }
    if (_distanceM == null) {
      setState(() => _error = 'انتظر حساب أجرة التوصيل أو أعد المحاولة');
      return;
    }
    if (_phone.text.trim().length < 7) {
      setState(() => _error = 'اكتب رقم هاتف صحيح للتواصل');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      String? imageUrl;
      if (_image != null) {
        final bytes = await _image!.readAsBytes();
        final name = _image!.name.toLowerCase();
        final ext = name.endsWith('.png') ? 'png' : 'jpeg';
        imageUrl = await _repo.uploadImage(bytes, ext);
      }
      await _repo.createCustomOrderPickup(
        itemName: _titleFrom(_desc.text),
        description: _desc.text.trim(),
        quantity: 1,
        suggestedStore: _store.text.trim().isEmpty ? null : _store.text.trim(),
        imageUrl: imageUrl,
        address: 'حسب الموقع المحدد على الخريطة',
        lat: _location!.latitude,
        lon: _location!.longitude,
        phone: _phone.text.trim(),
        notes: _notes.text.trim().isEmpty ? null : _notes.text.trim(),
        routeDistanceM: _distanceM!,
        pickupName: _fromStore ? 'متجر محدد' : null,
        pickupLat: _fromStore ? _store?.latitude : null,
        pickupLon: _fromStore ? _store?.longitude : null,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('تم إرسال طلبك إلى السائق.')));
      Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const MyOrdersScreen()));
    } catch (e) {
      setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _feeCard() {
    if (_routeBusy) {
      return const Card(
          child: Padding(
              padding: EdgeInsets.all(14),
              child: Row(children: [
                SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2)),
                SizedBox(width: 12),
                Text('جارٍ حساب أجرة التوصيل...'),
              ])));
    }
    if (_routeError != null) {
      return Card(
          child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(_routeError!, style: const TextStyle(color: Colors.red)),
                TextButton(onPressed: _calcRoute, child: const Text('إعادة المحاولة')),
              ])));
    }
    final f = _fee;
    if (f == null) return const SizedBox.shrink();
    return FeeCard(fee: f);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('اطلب أي شيء')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
              controller: _desc,
              maxLines: 5,
              decoration: const InputDecoration(
                  labelText: 'ماذا تريد؟ *',
                  hintText: 'اكتب ما تريده بالتفصيل: النوع، الكمية، اللون، الحجم، السعر المناسب لك...')),
          const SizedBox(height: 12),
          TextField(
              controller: _store,
              decoration: const InputDecoration(
                  labelText: 'متجر مقترح (اختياري)')),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: _pickImage,
            icon: const Icon(Icons.image_outlined),
            label: Text(_image == null ? 'إرفاق صورة (اختياري)' : 'تم اختيار صورة: ${_image!.name}'),
          ),
          const SizedBox(height: 12),
          SegmentedButton<bool>(
            segments: const [
              ButtonSegment(value: false, label: Text('من السوق')),
              ButtonSegment(value: true, label: Text('من متجر محدد')),
            ],
            selected: {_fromStore},
            onSelectionChanged: (s) => setState(() {
              _fromStore = s.first;
              _distanceM = null;
              _fee = null;
              if (_location != null) _calcRoute();
            }),
          ),
          if (_fromStore) ...[
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: () async {
                final res = await Navigator.of(context).push<LatLng>(
                    MaterialPageRoute(builder: (_) => LocationPicker(initial: _store)));
                if (res == null) return;
                setState(() => _store = res);
                if (_location != null) _calcRoute();
              },
              icon: const Icon(Icons.storefront_outlined),
              label: Text(_store == null ? 'حدد موقع المتجر على الخريطة *' : 'تم تحديد موقع المتجر ✓'),
            ),
          ],
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: _pickLocation,
            icon: const Icon(Icons.place_outlined),
            label: Text(_location == null
                ? 'حدد موقع التوصيل *'
                : 'تم تحديد الموقع ✓'),
          ),
          if (_location != null) ...[
            const SizedBox(height: 12),
            _feeCard(),
          ],
          const SizedBox(height: 12),
          TextField(
              controller: _phone,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'رقم الهاتف *')),
          const SizedBox(height: 12),
          TextField(
              controller: _notes,
              maxLines: 2,
              decoration: const InputDecoration(labelText: 'ملاحظات إضافية')),
          if (_error != null) ...[
            const SizedBox(height: 12),
            Text(_error!, style: const TextStyle(color: Colors.red)),
          ],
          const SizedBox(height: 16),
          FilledButton(
            onPressed: _busy ? null : _submit,
            child: _busy
                ? const SizedBox(
                    height: 22,
                    width: 22,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Text('إرسال الطلب'),
          ),
          const SizedBox(height: 8),
          const Text(
              'سيصل طلبك إلى السائق، وتصلك رسالة عند قبوله.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black54)),
        ],
      ),
    );
  }
}
