import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:latlong2/latlong.dart';

import '../data/order_repository.dart';
import '../data/routing_service.dart';
import 'location_picker.dart';
import 'my_orders_screen.dart';

class CustomOrderScreen extends StatefulWidget {
  const CustomOrderScreen({super.key});

  @override
  State<CustomOrderScreen> createState() => _CustomOrderScreenState();
}

class _CustomOrderScreenState extends State<CustomOrderScreen> {
  final _repo = OrderRepository();
  final _item = TextEditingController();
  final _desc = TextEditingController();
  final _store = TextEditingController();
  final _address = TextEditingController();
  final _phone = TextEditingController();
  final _notes = TextEditingController();
  int _qty = 1;
  LatLng? _location;
  XFile? _image;
  bool _busy = false;
  String? _error;

  // delivery fee (road distance from the delivery center, computed with OSRM)
  final RoutingService _routing = OsrmRoutingService();
  int? _distanceM;
  Map<String, dynamic>? _fee;
  bool _routeBusy = false;
  String? _routeError;

  @override
  void initState() {
    super.initState();
    _repo.getProfile().then((p) {
      final phone = p['phone'] as String?;
      if (mounted && phone != null && _phone.text.isEmpty) _phone.text = phone;
    });
  }

  Future<void> _pickImage() async {
    final f = await ImagePicker()
        .pickImage(source: ImageSource.gallery, maxWidth: 1280, imageQuality: 80);
    if (f != null) setState(() => _image = f);
  }

  Future<void> _pickLocation() async {
    final res = await Navigator.of(context).push<LatLng>(
        MaterialPageRoute(builder: (_) => LocationPicker(initial: _location)));
    if (res != null) {
      setState(() => _location = res);
      _calcRoute();
    }
  }

  Future<void> _calcRoute() async {
    final loc = _location;
    if (loc == null) return;
    setState(() {
      _routeBusy = true;
      _routeError = null;
      _distanceM = null;
      _fee = null;
    });
    // 1) which served city is the delivery point in?
    Map<String, dynamic>? city;
    try {
      city = await _repo.resolveCity(loc.latitude, loc.longitude);
    } catch (_) {
      if (mounted) {
        setState(() {
          _routeBusy = false;
          _routeError = 'تعذر تحديد المدينة. تحقق من الاتصال وأعد المحاولة.';
        });
      }
      return;
    }
    if (!mounted) return;
    if (city == null) {
      setState(() {
        _routeBusy = false;
        _routeError = friendlyError('city_not_supported');
      });
      return;
    }
    // 2) road distance from THAT city's reference point (its market)
    final m = await _routing.drivingDistanceMeters(
      fromLat: (city['center_lat'] as num).toDouble(),
      fromLon: (city['center_lon'] as num).toDouble(),
      toLat: loc.latitude,
      toLon: loc.longitude,
    );
    if (!mounted) return;
    if (m == null) {
      setState(() {
        _routeBusy = false;
        _routeError = 'تعذر حساب مسافة التوصيل. تحقق من الاتصال وأعد المحاولة.';
      });
      return;
    }
    try {
      final fee = await _repo.feePreview(loc.latitude, loc.longitude, m);
      if (!mounted) return;
      setState(() {
        _distanceM = m;
        _fee = fee;
        _routeBusy = false;
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          _routeBusy = false;
          _routeError = 'تعذر حساب أجرة التوصيل. أعد المحاولة.';
        });
      }
    }
  }

  Future<void> _submit() async {
    if (_item.text.trim().isEmpty) {
      setState(() => _error = 'اكتب اسم السلعة');
      return;
    }
    if (_location == null) {
      setState(() => _error = 'حدد موقع التوصيل على الخريطة');
      return;
    }
    if (_distanceM == null) {
      setState(() => _error = 'انتظر حساب أجرة التوصيل أو أعد المحاولة');
      return;
    }
    if (_phone.text.trim().length < 7) {
      setState(() => _error = 'اكتب رقم هاتف صحيح للتواصل');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      String? imageUrl;
      if (_image != null) {
        final bytes = await _image!.readAsBytes();
        final name = _image!.name.toLowerCase();
        final ext = name.endsWith('.png') ? 'png' : 'jpeg';
        imageUrl = await _repo.uploadImage(bytes, ext);
      }
      await _repo.createCustomOrder(
        itemName: _item.text.trim(),
        description: _desc.text.trim().isEmpty ? null : _desc.text.trim(),
        quantity: _qty,
        suggestedStore: _store.text.trim().isEmpty ? null : _store.text.trim(),
        imageUrl: imageUrl,
        address: _address.text.trim().isEmpty
            ? 'حسب الموقع المحدد على الخريطة'
            : _address.text.trim(),
        lat: _location!.latitude,
        lon: _location!.longitude,
        phone: _phone.text.trim(),
        notes: _notes.text.trim().isEmpty ? null : _notes.text.trim(),
        routeDistanceM: _distanceM!,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('تم إرسال طلبك إلى السائق.')));
      Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const MyOrdersScreen()));
    } catch (e) {
      setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _feeCard() {
    if (_routeBusy) {
      return const Card(
          child: Padding(
              padding: EdgeInsets.all(14),
              child: Row(children: [
                SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2)),
                SizedBox(width: 12),
                Text('جارٍ حساب أجرة التوصيل...'),
              ])));
    }
    if (_routeError != null) {
      return Card(
          child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(_routeError!, style: const TextStyle(color: Colors.red)),
                TextButton(onPressed: _calcRoute, child: const Text('إعادة المحاولة')),
              ])));
    }
    final f = _fee;
    if (f == null) return const SizedBox.shrink();
    final cur = (f['currency_symbol'] ?? 'ل.ت').toString();
    Widget row(String k, String v, {bool bold = false}) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 2),
          child: Row(children: [
            Text(k),
            const Spacer(),
            Text(v, style: TextStyle(fontWeight: bold ? FontWeight.w800 : FontWeight.w500)),
          ]),
        );
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('أجرة التوصيل · ${f['city_name'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          row('التوصيل الأساسي', '${fmt(f['base_fee'] as num)} $cur'),
          if ((f['distance_fee'] as num) > 0)
            row('رسوم المسافة', '${fmt(f['distance_fee'] as num)} $cur'),
          if ((f['time_fee'] as num) > 0)
            row(timeFeeLabel(f['time_fee_kind'], cur), '${fmt(f['time_fee'] as num)} $cur'),
          const Divider(),
          row('إجمالي التوصيل', '${fmt(f['delivery_total'] as num)} $cur', bold: true),
          const SizedBox(height: 6),
          const Text('سعر المنتجات يُدفع نقداً للسائق عند التسليم حسب سعرها الفعلي.',
              style: TextStyle(fontSize: 12, color: Colors.black54)),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('اطلب أي شيء')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
              controller: _item,
              decoration: const InputDecoration(labelText: 'اسم السلعة *')),
          const SizedBox(height: 12),
          TextField(
              controller: _desc,
              maxLines: 3,
              decoration: const InputDecoration(
                  labelText: 'وصف تفصيلي',
                  hintText: 'النوع، اللون، الحجم، السعر المناسب لك...')),
          const SizedBox(height: 12),
          Row(
            children: [
              const Text('الكمية', style: TextStyle(fontWeight: FontWeight.w700)),
              const Spacer(),
              IconButton.filledTonal(
                  onPressed: _qty > 1 ? () => setState(() => _qty--) : null,
                  icon: const Icon(Icons.remove)),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Text('$_qty',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              ),
              IconButton.filledTonal(
                  onPressed: () => setState(() => _qty++),
                  icon: const Icon(Icons.add)),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
              controller: _store,
              decoration: const InputDecoration(
                  labelText: 'متجر مقترح (اختياري)')),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: _pickImage,
            icon: const Icon(Icons.image_outlined),
            label: Text(_image == null ? 'إرفاق صورة (اختياري)' : 'تم اختيار صورة: ${_image!.name}'),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: _pickLocation,
            icon: const Icon(Icons.place_outlined),
            label: Text(_location == null
                ? 'حدد موقع التوصيل *'
                : 'تم تحديد الموقع ✓'),
          ),
          if (_location != null) ...[
            const SizedBox(height: 12),
            _feeCard(),
          ],
          const SizedBox(height: 12),
          TextField(
              controller: _address,
              decoration: const InputDecoration(
                  labelText: 'وصف العنوان (اختياري)',
                  hintText: 'قرب مسجد... بناء... طابق...')),
          const SizedBox(height: 12),
          TextField(
              controller: _phone,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'رقم الهاتف *')),
          const SizedBox(height: 12),
          TextField(
              controller: _notes,
              maxLines: 2,
              decoration: const InputDecoration(labelText: 'ملاحظات إضافية')),
          if (_error != null) ...[
            const SizedBox(height: 12),
            Text(_error!, style: const TextStyle(color: Colors.red)),
          ],
          const SizedBox(height: 16),
          FilledButton(
            onPressed: _busy ? null : _submit,
            child: _busy
                ? const SizedBox(
                    height: 22,
                    width: 22,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Text('إرسال الطلب'),
          ),
          const SizedBox(height: 8),
          const Text(
              'سيصل طلبك إلى السائق، وتصلك رسالة عند قبوله.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black54)),
        ],
      ),
    );
  }
}
