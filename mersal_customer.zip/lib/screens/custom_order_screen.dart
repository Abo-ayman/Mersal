import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:latlong2/latlong.dart';

import '../data/order_repository.dart';
import 'location_picker.dart';
import 'my_orders_screen.dart';

class CustomOrderScreen extends StatefulWidget {
  const CustomOrderScreen({super.key});

  @override
  State<CustomOrderScreen> createState() => _CustomOrderScreenState();
}

class _CustomOrderScreenState extends State<CustomOrderScreen> {
  final _repo = OrderRepository();
  final _item = TextEditingController();
  final _desc = TextEditingController();
  final _store = TextEditingController();
  final _address = TextEditingController();
  final _phone = TextEditingController();
  final _notes = TextEditingController();
  int _qty = 1;
  LatLng? _location;
  XFile? _image;
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _repo.getProfile().then((p) {
      final phone = p['phone'] as String?;
      if (mounted && phone != null && _phone.text.isEmpty) _phone.text = phone;
    });
  }

  Future<void> _pickImage() async {
    final f = await ImagePicker()
        .pickImage(source: ImageSource.gallery, maxWidth: 1280, imageQuality: 80);
    if (f != null) setState(() => _image = f);
  }

  Future<void> _pickLocation() async {
    final res = await Navigator.of(context).push<LatLng>(
        MaterialPageRoute(builder: (_) => LocationPicker(initial: _location)));
    if (res != null) setState(() => _location = res);
  }

  Future<void> _submit() async {
    if (_item.text.trim().isEmpty) {
      setState(() => _error = 'اكتب اسم السلعة');
      return;
    }
    if (_location == null) {
      setState(() => _error = 'حدد موقع التوصيل على الخريطة');
      return;
    }
    if (_phone.text.trim().length < 7) {
      setState(() => _error = 'اكتب رقم هاتف صحيح للتواصل');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      String? imageUrl;
      if (_image != null) {
        final bytes = await _image!.readAsBytes();
        final name = _image!.name.toLowerCase();
        final ext = name.endsWith('.png') ? 'png' : 'jpeg';
        imageUrl = await _repo.uploadImage(bytes, ext);
      }
      await _repo.createCustomOrder(
        itemName: _item.text.trim(),
        description: _desc.text.trim().isEmpty ? null : _desc.text.trim(),
        quantity: _qty,
        suggestedStore: _store.text.trim().isEmpty ? null : _store.text.trim(),
        imageUrl: imageUrl,
        address: _address.text.trim().isEmpty
            ? 'حسب الموقع المحدد على الخريطة'
            : _address.text.trim(),
        lat: _location!.latitude,
        lon: _location!.longitude,
        phone: _phone.text.trim(),
        notes: _notes.text.trim().isEmpty ? null : _notes.text.trim(),
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('تم إرسال طلبك. سنرسل لك السعر للموافقة عليه.')));
      Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const MyOrdersScreen()));
    } catch (e) {
      setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('اطلب أي شيء')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
              controller: _item,
              decoration: const InputDecoration(labelText: 'اسم السلعة *')),
          const SizedBox(height: 12),
          TextField(
              controller: _desc,
              maxLines: 3,
              decoration: const InputDecoration(
                  labelText: 'وصف تفصيلي',
                  hintText: 'النوع، اللون، الحجم، السعر المناسب لك...')),
          const SizedBox(height: 12),
          Row(
            children: [
              const Text('الكمية', style: TextStyle(fontWeight: FontWeight.w700)),
              const Spacer(),
              IconButton.filledTonal(
                  onPressed: _qty > 1 ? () => setState(() => _qty--) : null,
                  icon: const Icon(Icons.remove)),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Text('$_qty',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              ),
              IconButton.filledTonal(
                  onPressed: () => setState(() => _qty++),
                  icon: const Icon(Icons.add)),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
              controller: _store,
              decoration: const InputDecoration(
                  labelText: 'متجر مقترح (اختياري)')),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: _pickImage,
            icon: const Icon(Icons.image_outlined),
            label: Text(_image == null ? 'إرفاق صورة (اختياري)' : 'تم اختيار صورة: ${_image!.name}'),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: _pickLocation,
            icon: const Icon(Icons.place_outlined),
            label: Text(_location == null
                ? 'حدد موقع التوصيل *'
                : 'تم تحديد الموقع ✓'),
          ),
          const SizedBox(height: 12),
          TextField(
              controller: _address,
              decoration: const InputDecoration(
                  labelText: 'وصف العنوان (اختياري)',
                  hintText: 'قرب مسجد... بناء... طابق...')),
          const SizedBox(height: 12),
          TextField(
              controller: _phone,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'رقم الهاتف *')),
          const SizedBox(height: 12),
          TextField(
              controller: _notes,
              maxLines: 2,
              decoration: const InputDecoration(labelText: 'ملاحظات إضافية')),
          if (_error != null) ...[
            const SizedBox(height: 12),
            Text(_error!, style: const TextStyle(color: Colors.red)),
          ],
          const SizedBox(height: 16),
          FilledButton(
            onPressed: _busy ? null : _submit,
            child: _busy
                ? const SizedBox(
                    height: 22,
                    width: 22,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Text('إرسال الطلب'),
          ),
          const SizedBox(height: 8),
          const Text(
              'لن يُنفَّذ الطلب إلا بعد أن نرسل لك السعر وتوافق عليه.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black54)),
        ],
      ),
    );
  }
}
