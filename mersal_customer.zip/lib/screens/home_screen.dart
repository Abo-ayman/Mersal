import 'dart:async';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/logo.dart';
import '../core/pulse.dart';
import '../core/push.dart';
import '../core/theme.dart';
import '../data/order_repository.dart';
import '../core/ico3d.dart';
import 'assistant_screen.dart';
import 'bazaar_order_screen.dart';
import 'gas_order_screen.dart';
import 'pharmacy_order_screen.dart';
import 'stores_screen.dart';
import 'custom_order_screen.dart';
import '../core/account_gate.dart';
import 'account_screen.dart';
import 'my_orders_screen.dart';
import 'taxi_screen.dart';
import 'notifications_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _repo = OrderRepository();
  final _page = PageController(viewportFraction: 0.9);
  Timer? _timer;
  int _tick = 0;

  String _name = '';
  Map<String, dynamic>? _city; // the served city the customer is in
  bool _cityLoading = true;
  String? _cityNote; // outside | no_permission | gps_off | failed
  List<Map<String, dynamic>> _offers = [];
  bool _hasUpdates = false; // any order changed / unread chat since last opened
  Map<String, dynamic>? _bazaar; // weekly bazaar service of the city (null when the city has none)
  num _discount = 0; // welcome discount percent for a new customer

  @override
  void initState() {
    super.initState();
    _repo.getProfile().then((p) {
      if (mounted) setState(() => _name = (p['display_name'] ?? '') as String);
    });
    _detectCity();
    _checkUpdates();
    _loadDiscount();
    checkAccountStatus();
    _timer = Timer.periodic(const Duration(seconds: 15), (_) {
      _tick++;
      checkAccountStatus();
      _checkUpdates();
      if (_tick % 4 == 0) {
        _loadOffers(); // offers and bazaar window every minute
        _loadBazaar();
      }
    });
    Push.pushTick.addListener(_checkUpdates);
  }

  @override
  void dispose() {
    _timer?.cancel();
    Push.pushTick.removeListener(_checkUpdates);
    _page.dispose();
    super.dispose();
  }

  /// Finds the city from the phone's location (Jarabulus, Maskanah, ...).
  Future<void> _detectCity() async {
    setState(() {
      _cityLoading = true;
      _cityNote = null;
    });
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        _cityFailed('gps_off');
        return;
      }
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        _cityFailed('no_permission');
        return;
      }
      final pos = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
            accuracy: LocationAccuracy.medium, timeLimit: Duration(seconds: 12)),
      );
      final city = await _repo.resolveCity(pos.latitude, pos.longitude);
      if (!mounted) return;
      if (city == null) {
        _cityFailed('outside');
      } else {
        setState(() {
          _city = city;
          _cityLoading = false;
        });
        _loadOffers();
        _loadBazaar();
      }
    } catch (_) {
      _cityFailed('failed');
    }
  }

  void _cityFailed(String why) {
    if (!mounted) return;
    setState(() {
      _cityLoading = false;
      _cityNote = why;
      _bazaar = null;
    });
    _loadOffers(); // global offers still apply
  }

  Future<void> _loadOffers() async {
    try {
      final offers = await _repo.activeOffers(_city?['id'] as String?);
      if (mounted) setState(() => _offers = offers);
    } catch (_) {}
  }

  Future<void> _loadDiscount() async {
    final d = await _repo.welcomeDiscountPercent();
    if (mounted) setState(() => _discount = d);
  }

  Future<void> _loadBazaar() async {
    final id = _city?['id'] as String?;
    if (id == null) {
      if (mounted) setState(() => _bazaar = null);
      return;
    }
    try {
      final b = await _repo.bazaarStatus(id);
      if (mounted) setState(() => _bazaar = b);
    } catch (_) {}
  }

  String _money(dynamic v) {
    final n = v is num ? v : num.tryParse('$v') ?? 0;
    return fmt(n);
  }

  /// First press: explain the service once. Then open the booking form (only while booking is open).
  Future<void> _openBazaar() async {
    final b = _bazaar;
    if (b == null) return;
    final sym = '${b['currency_symbol'] ?? ''}';
    if (!await _repo.hasFlag('bazaar_intro')) {
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (c) => AlertDialog(
          title: Text('${b['name'] ?? 'طلب بيزار'}'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${b['intro_text'] ?? ''}'),
              const SizedBox(height: 12),
              Text('• يفتح الحجز كل يوم اثنين الساعة 7 صباحاً، ويُسلَّم الطلب يوم ${b['delivery_day_text'] ?? 'الثلاثاء'}، ويُغلق الحجز يوم ${b['delivery_day_text'] ?? 'الثلاثاء'} الساعة 4 مساءً.'),
              const SizedBox(height: 6),
              Text('• سعر التوصيل الأساسي ${_money(b['base_fee'])} $sym، ولكل ${b['step_m']} متر زائدة عن المسافة الأساسية تُضاف ${_money(b['step_fee'])} $sym.'),
              const SizedBox(height: 6),
              const Text('• تدفع نقداً عند التسليم.'),
            ]),
          ),
          actions: [
            FilledButton(
                style: FilledButton.styleFrom(minimumSize: const Size(120, 44)),
                onPressed: () => Navigator.pop(c),
                child: const Text('فهمت')),
          ],
        ),
      );
      await _repo.setFlag('bazaar_intro');
    }
    if (!mounted) return;
    if (b['is_open'] != true) {
      await showDialog<void>(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('الحجز مغلق حالياً'),
          content: Text('يفتح حجز ${b['name'] ?? 'طلب بيزار'} كل يوم اثنين الساعة 7 صباحاً، ويُغلق يوم ${b['delivery_day_text'] ?? 'الثلاثاء'} الساعة 4 مساءً.'),
          actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('حسناً'))],
        ),
      );
      return;
    }
    await Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => BazaarOrderScreen(service: b)));
    _loadDiscount();
    _checkUpdates();
    _loadBazaar();
  }

  Widget _bazaarButton() {
    final b = _bazaar;
    if (b == null) return const SizedBox.shrink();
    final open = b['is_open'] == true;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const SizedBox(height: 10),
      FilledButton.icon(
        style: FilledButton.styleFrom(
          backgroundColor: open ? const Color(0xFFEA580C) : const Color(0xFFEA580C).withValues(alpha: 0.55),
          foregroundColor: Colors.white,
        ),
        onPressed: _openBazaar,
        icon: const Icon(Icons.shopping_basket_outlined),
        label: Text('${b['name'] ?? 'طلب بيزار'}'),
      ),
      const SizedBox(height: 4),
      Text(
        open
            ? 'الحجز متاح الآن حتى ${b['delivery_day_text'] ?? 'الثلاثاء'} الساعة 4 مساءً'
            : 'يفتح الحجز كل يوم اثنين الساعة 7 صباحاً',
        textAlign: TextAlign.center,
        style: const TextStyle(color: Colors.white70, fontSize: 12),
      ),
    ]);
  }

  Widget _discountBanner() {
    if (_discount <= 0) return const SizedBox.shrink();
    return Container(
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.green.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.green.withValues(alpha: 0.4)),
      ),
      child: Row(children: [
        const Icon(Icons.card_giftcard, color: Colors.green),
        const SizedBox(width: 10),
        Expanded(
          child: Text('خصم ${_money(_discount)}% على أجرة توصيل أول طلب لك!',
              style: const TextStyle(fontWeight: FontWeight.w800)),
        ),
      ]),
    );
  }

  Future<void> _checkUpdates() async {
    try {
      final orders = await _repo.myOrders();
      final unseen = await _repo.unseenIds(orders);
      final chat = await _repo.unreadChatOrderIds();
      if (mounted) setState(() => _hasUpdates = unseen.isNotEmpty || chat.isNotEmpty);
    } catch (_) {}
  }

  String _expiryText(dynamic iso) {
    final t = DateTime.tryParse('$iso')?.toLocal();
    if (t == null) return '';
    final d = t.difference(DateTime.now());
    if (d.inDays >= 1) return 'ينتهي بعد ${d.inDays} يوم';
    if (d.inHours >= 1) return 'ينتهي بعد ${d.inHours} ساعة';
    return 'ينتهي قريباً';
  }

  Widget _cityBanner() {
    if (_cityLoading) {
      return const Row(children: [
        SizedBox(height: 16, width: 16, child: CircularProgressIndicator(strokeWidth: 2)),
        SizedBox(width: 10),
        Text('جارٍ تحديد موقعك…', style: TextStyle(color: Colors.black54)),
      ]);
    }
    if (_city != null) {
      return Row(children: [
        const Icon(Icons.place, size: 18, color: Brand.primary),
        const SizedBox(width: 4),
        Text('${_city!['name']}', style: const TextStyle(fontWeight: FontWeight.w700)),
      ]);
    }
    final msg = switch (_cityNote) {
      'outside' => 'موقعك الحالي خارج مناطق خدمتنا.',
      'no_permission' => 'لم يُسمح بالوصول إلى الموقع، فلم نتمكن من تحديد مدينتك.',
      'gps_off' => 'خدمة الموقع (GPS) مغلقة، فلم نتمكن من تحديد مدينتك.',
      _ => 'تعذر تحديد موقعك تلقائياً.',
    };
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
          color: Colors.orange.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(12)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(msg),
        const SizedBox(height: 6),
        Row(children: [
          TextButton(onPressed: _detectCity, child: const Text('إعادة المحاولة')),
        ]),
      ]),
    );
  }

  Widget _offersSection() {
    if (_offers.isEmpty) return const SizedBox.shrink();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 20),
      const Text('العروض', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
      const SizedBox(height: 10),
      SizedBox(
        height: 140,
        child: PageView.builder(
          controller: _page,
          padEnds: false,
          itemCount: _offers.length,
          itemBuilder: (_, i) {
            final o = _offers[i];
            return Padding(
              padding: const EdgeInsetsDirectional.only(end: 10),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                      colors: [Brand.accent, Color(0xFF14B8A6)],
                      begin: Alignment.topRight,
                      end: Alignment.bottomLeft),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    const Icon(Icons.local_offer, color: Colors.white, size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text('${o['title']}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              color: Colors.white, fontWeight: FontWeight.w900, fontSize: 17)),
                    ),
                  ]),
                  const SizedBox(height: 6),
                  Expanded(
                    child: Text('${o['body']}',
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: Colors.white)),
                  ),
                  Text(_expiryText(o['expires_at']),
                      style: const TextStyle(color: Colors.white70, fontSize: 12)),
                ]),
              ),
            );
          },
        ),
      ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final cityName = _city?['name'] as String?;
    final welcome = (_city?['welcome_message'] as String?) ?? 'نوصّل أي شيء في مدينتك';
    return Scaffold(
      backgroundColor: Colors.white,
      floatingActionButton: _assistantButton(),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: _bottomBar(),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFD9F1E4), Colors.white],
            stops: [0, 0.5],
          ),
        ),
        child: SafeArea(
          bottom: false,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
            children: [
              _header(cityName),
              const SizedBox(height: 14),
              _searchField(),
              const SizedBox(height: 16),
              _categories(),
              const SizedBox(height: 16),
              _heroBanner(welcome, cityName),
              _discountBanner(),
              _offersSection(),
              const SizedBox(height: 18),
              _sectionTitle('خدماتنا'),
              _services(),
          const SizedBox(height: 12),
          _feesNotice(),
          _taxiCard(),
              const SizedBox(height: 12),
              _cityBanner(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _header(String? cityName) {
    return Row(children: [
      const Ico3D('pin', size: 38),
      const SizedBox(width: 6),
      Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('توصيل إلى', style: TextStyle(fontSize: 12, color: Colors.black54)),
            Row(children: [
              Flexible(
                child: Text(
                  cityName ?? (_cityLoading ? 'جارٍ تحديد موقعك…' : 'اختر مدينتك'),
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
                ),
              ),
            ]),
          ]),
      ),
      CircleAvatar(
        radius: 22,
        backgroundColor: Colors.white,
        child: Ico3D('user', size: 30),
      ),
    ]);
  }

  Widget _searchField() {
    return InkWell(
      onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const StoresScreen())),
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 12, offset: const Offset(0, 4))],
        ),
        child: Row(children: [
          const Icon(Icons.search_rounded, color: Brand.primary),
          const SizedBox(width: 10),
          Text(_name.isEmpty ? 'كيف نقدر نساعدك اليوم؟' : 'كيف نقدر نساعدك اليوم يا $_name؟',
              style: const TextStyle(color: Colors.black45)),
        ]),
      ),
    );
  }

  int _category = 0;

  Widget _categories() {
    const items = <(String, String)>[
      ('مرسال', 'parcel'),
      ('متاجر', 'bag'),
      ('صيدليات', 'pharmacy'),
      ('مقاضي', 'basket'),
      ('غاز', 'gas'),
    ];
    return SizedBox(
      height: 96,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (_, i) {
          final selected = _category == i;
          return InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: () {
              setState(() => _category = i);
              if (i == 2) {
                Navigator.of(context).push(MaterialPageRoute(builder: (_) => const PharmacyOrderScreen()));
              } else if (i == 4) {
                final sym = _city?['currency_symbol'] as String?;
                if (sym == 'ل.س' || sym == 'ل.ت') {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => GasOrderScreen(price: sym == 'ل.س' ? '300 ل.س' : '100 ل.ت')));
                } else {
                  _soon('حدد مدينتك أولاً لعرض أسعار الغاز');
                }
              } else if (i == 1) {
                Navigator.of(context).push(MaterialPageRoute(builder: (_) => const StoresScreen()));
              } else if (i != 0) {
                _soon('قسم «${items[i].$1}» سيتوفر قريباً');
              }
            },
            child: Container(
              width: 84,
              padding: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                color: selected ? Brand.primary : Colors.white,
                borderRadius: BorderRadius.circular(18),
                boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 10, offset: const Offset(0, 4))],
              ),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Ico3D(items[i].$2, size: 46),
                const SizedBox(height: 4),
                Text(items[i].$1,
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        color: selected ? Colors.white : Brand.ink)),
              ]),
            ),
          );
        },
      ),
    );
  }

  Widget _heroBanner(String welcome, String? cityName) {
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 18, 10, 18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [Color(0xFF0C7A4C), Color(0xFF2BB673)],
        ),
      ),
      child: Row(children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(welcome,
                  style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              Text(cityName == null ? 'اطلب أي شيء من أي محل' : 'اطلب أي شيء من أي محل في $cityName',
                  style: const TextStyle(color: Colors.white70, fontSize: 13)),
              const SizedBox(height: 12),
              FilledButton(
                style: FilledButton.styleFrom(
                    minimumSize: const Size(0, 40),
                    backgroundColor: Colors.white,
                    foregroundColor: Brand.primary),
                onPressed: _openCustomOrder,
                child: const Text('اطلب الآن'),
              ),
            ],
          ),
        ),
        const SizedBox(width: 8),
        Ico3D('parcel', size: 104),
      ]),
    );
  }

  Widget _sectionTitle(String t) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Text(t, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
      );

  /// Reminder of unpaid taxi cancellation fees, shown every time the app opens.
  Widget _feesNotice() {
    return FutureBuilder<List<dynamic>>(
      future: Supabase.instance.client.rpc('my_unpaid_fees'),
      builder: (_, snap) {
        final rows = snap.data ?? const [];
        if (rows.isEmpty) return const SizedBox.shrink();
        final r = rows.first as Map;
        if (((r['cnt'] ?? 0) as num) == 0) return const SizedBox.shrink();
        return Container(
          width: double.infinity,
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.red.withValues(alpha: 0.06),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.red.withValues(alpha: 0.4)),
          ),
          child: Text(
            'عليك رسوم خروج تاكسي غير مسددة بقيمة ${r['total']} ${r['currency_symbol'] ?? 'ل.ت'}. '
            'يرجى سدادها، وإلا يُوقَف حسابك بعد أسبوع من تاريخ الرسم.',
            style: const TextStyle(color: Colors.red, fontWeight: FontWeight.w700),
          ),
        );
      },
    );
  }

  Widget _taxiCard() {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: () => Navigator.of(context)
          .push(MaterialPageRoute(builder: (_) => const TaxiScreen())),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 12, offset: const Offset(0, 4))],
        ),
        child: Row(children: [
          const Ico3D('taxi', size: 56),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('طلب تاكسي', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
              SizedBox(height: 4),
              Text('إلى وجهتك أو رحلة مفتوحة، والسعر يظهر قبل الطلب',
                  style: TextStyle(color: Colors.black54, fontSize: 12)),
            ]),
          ),
          const Icon(Icons.chevron_left),
        ]),
      ),
    );
  }

  Widget _services() {
    final cards = <Widget>[
      _serviceCard('أطلب أي شيء', 'bag', _openCustomOrder),
      _serviceCard('أرسل أي شيء', 'parcel', _openCustomOrder),
      if (_bazaar != null)
        _serviceCard('طلب بيزار', 'basket', _openBazaar)
      else
        _serviceCard('طلباتي', 'receipt', _openOrders, dot: _hasUpdates),
    ];
    return Row(children: [
      for (var i = 0; i < cards.length; i++) ...[
        Expanded(child: cards[i]),
        if (i < cards.length - 1) const SizedBox(width: 10),
      ],
    ]);
  }

  Widget _serviceCard(String title, String icon, VoidCallback onTap, {bool dot = false}) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 6),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 12, offset: const Offset(0, 4))],
        ),
        child: Column(children: [
          Stack(clipBehavior: Clip.none, children: [
            Ico3D(icon, size: 58),
            if (dot)
              const Positioned(
                  right: 0, top: 0, child: CircleAvatar(radius: 6, backgroundColor: Colors.red)),
          ]),
          const SizedBox(height: 8),
          Text(title,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800)),
        ]),
      ),
    );
  }

  Widget _assistantButton() {
    return FloatingActionButton(
      heroTag: 'mersal-assistant',
      backgroundColor: Brand.primary,
      shape: const CircleBorder(),
      tooltip: 'المساعد الشخصي',
      onPressed: () => Navigator.of(context)
          .push(MaterialPageRoute(builder: (_) => const AssistantScreen())),
      child: Ico3D('sparkle_white', size: 30),
    );
  }

  Widget _bottomBar() {
    return BottomAppBar(
      shape: const CircularNotchedRectangle(),
      notchMargin: 8,
      color: Colors.white,
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
        _navItem(Icons.home_rounded, 'الرئيسية', selected: true, onTap: () {}),
        _navItem(Icons.receipt_long_rounded, 'الطلبات', dot: _hasUpdates, onTap: _openOrders),
        const SizedBox(width: 56),
        _navItem(Icons.notifications_none_rounded, 'التنبيهات',
            onTap: () => Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => const NotificationsScreen()))),
        _navItem(Icons.person_outline_rounded, 'حسابي',
            onTap: () => Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => const AccountScreen()))),
      ]),
    );
  }

  Widget _navItem(IconData icon, String label,
      {required VoidCallback onTap, bool selected = false, bool dot = false}) {
    final color = selected ? Brand.primary : Colors.black54;
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Stack(clipBehavior: Clip.none, children: [
            Icon(icon, color: color),
            if (dot)
              const Positioned(
                  right: -2, top: -1, child: CircleAvatar(radius: 4, backgroundColor: Colors.red)),
          ]),
          Text(label, style: TextStyle(fontSize: 11, color: color, fontWeight: selected ? FontWeight.w800 : FontWeight.w500)),
        ]),
      ),
    );
  }

  void _soon(String msg) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 2)));

  Future<void> _openCustomOrder() async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CustomOrderScreen()));
    _loadDiscount();
    _checkUpdates();
  }

  Future<void> _openOrders() async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MyOrdersScreen()));
    _checkUpdates();
    _loadDiscount();
  }
}
