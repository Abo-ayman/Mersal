import 'dart:async';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

import '../core/logo.dart';
import '../core/pulse.dart';
import '../core/push.dart';
import '../core/theme.dart';
import '../data/order_repository.dart';
import 'custom_order_screen.dart';
import 'my_orders_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _repo = OrderRepository();
  final _page = PageController(viewportFraction: 0.9);
  Timer? _timer;
  int _tick = 0;

  String _name = '';
  Map<String, dynamic>? _city; // the served city the customer is in
  bool _cityLoading = true;
  String? _cityNote; // outside | no_permission | gps_off | failed
  List<Map<String, dynamic>> _offers = [];
  bool _hasUpdates = false; // any order changed / unread chat since last opened

  @override
  void initState() {
    super.initState();
    _repo.getProfile().then((p) {
      if (mounted) setState(() => _name = (p['display_name'] ?? '') as String);
    });
    _detectCity();
    _checkUpdates();
    _timer = Timer.periodic(const Duration(seconds: 15), (_) {
      _tick++;
      _checkUpdates();
      if (_tick % 4 == 0) _loadOffers(); // offers every minute
    });
    Push.pushTick.addListener(_checkUpdates);
  }

  @override
  void dispose() {
    _timer?.cancel();
    Push.pushTick.removeListener(_checkUpdates);
    _page.dispose();
    super.dispose();
  }

  /// Finds the city from the phone's location (Jarabulus, Maskanah, ...).
  Future<void> _detectCity() async {
    setState(() {
      _cityLoading = true;
      _cityNote = null;
    });
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        _cityFailed('gps_off');
        return;
      }
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        _cityFailed('no_permission');
        return;
      }
      final pos = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
            accuracy: LocationAccuracy.medium, timeLimit: Duration(seconds: 12)),
      );
      final city = await _repo.resolveCity(pos.latitude, pos.longitude);
      if (!mounted) return;
      if (city == null) {
        _cityFailed('outside');
      } else {
        setState(() {
          _city = city;
          _cityLoading = false;
        });
        _loadOffers();
      }
    } catch (_) {
      _cityFailed('failed');
    }
  }

  void _cityFailed(String why) {
    if (!mounted) return;
    setState(() {
      _cityLoading = false;
      _cityNote = why;
    });
    _loadOffers(); // global offers still apply
  }

  Future<void> _pickCity() async {
    List<Map<String, dynamic>> cities;
    try {
      cities = await _repo.cities();
    } catch (_) {
      return;
    }
    if (!mounted) return;
    final chosen = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      builder: (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text('اختر مدينتك', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          ),
          for (final city in cities)
            ListTile(
              leading: const Icon(Icons.location_city),
              title: Text('${city['name']}'),
              onTap: () => Navigator.pop(c, city),
            ),
          const SizedBox(height: 8),
        ]),
      ),
    );
    if (chosen != null && mounted) {
      setState(() {
        _city = chosen;
        _cityNote = null;
      });
      _loadOffers();
    }
  }

  Future<void> _loadOffers() async {
    try {
      final offers = await _repo.activeOffers(_city?['id'] as String?);
      if (mounted) setState(() => _offers = offers);
    } catch (_) {}
  }

  Future<void> _checkUpdates() async {
    try {
      final orders = await _repo.myOrders();
      final unseen = await _repo.unseenIds(orders);
      final chat = await _repo.unreadChatOrderIds();
      if (mounted) setState(() => _hasUpdates = unseen.isNotEmpty || chat.isNotEmpty);
    } catch (_) {}
  }

  String _expiryText(dynamic iso) {
    final t = DateTime.tryParse('$iso')?.toLocal();
    if (t == null) return '';
    final d = t.difference(DateTime.now());
    if (d.inDays >= 1) return 'ينتهي بعد ${d.inDays} يوم';
    if (d.inHours >= 1) return 'ينتهي بعد ${d.inHours} ساعة';
    return 'ينتهي قريباً';
  }

  Widget _cityBanner() {
    if (_cityLoading) {
      return const Row(children: [
        SizedBox(height: 16, width: 16, child: CircularProgressIndicator(strokeWidth: 2)),
        SizedBox(width: 10),
        Text('جارٍ تحديد موقعك…', style: TextStyle(color: Colors.black54)),
      ]);
    }
    if (_city != null) {
      return Row(children: [
        const Icon(Icons.place, size: 18, color: Brand.primary),
        const SizedBox(width: 4),
        Text('${_city!['name']}', style: const TextStyle(fontWeight: FontWeight.w700)),
        TextButton(onPressed: _pickCity, child: const Text('تغيير')),
      ]);
    }
    final msg = switch (_cityNote) {
      'outside' => 'موقعك الحالي خارج مناطق خدمتنا (جرابلس ومسكنة).',
      'no_permission' => 'لم يُسمح بالوصول إلى الموقع، فلم نتمكن من تحديد مدينتك.',
      'gps_off' => 'خدمة الموقع (GPS) مغلقة، فلم نتمكن من تحديد مدينتك.',
      _ => 'تعذر تحديد موقعك تلقائياً.',
    };
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
          color: Colors.orange.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(12)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(msg),
        const SizedBox(height: 6),
        Row(children: [
          TextButton(onPressed: _detectCity, child: const Text('إعادة المحاولة')),
          TextButton(onPressed: _pickCity, child: const Text('اختيار المدينة')),
        ]),
      ]),
    );
  }

  Widget _offersSection() {
    if (_offers.isEmpty) return const SizedBox.shrink();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 20),
      const Text('العروض', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
      const SizedBox(height: 10),
      SizedBox(
        height: 140,
        child: PageView.builder(
          controller: _page,
          padEnds: false,
          itemCount: _offers.length,
          itemBuilder: (_, i) {
            final o = _offers[i];
            return Padding(
              padding: const EdgeInsetsDirectional.only(end: 10),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                      colors: [Brand.accent, Color(0xFF14B8A6)],
                      begin: Alignment.topRight,
                      end: Alignment.bottomLeft),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    const Icon(Icons.local_offer, color: Colors.white, size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text('${o['title']}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              color: Colors.white, fontWeight: FontWeight.w900, fontSize: 17)),
                    ),
                  ]),
                  const SizedBox(height: 6),
                  Expanded(
                    child: Text('${o['body']}',
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: Colors.white)),
                  ),
                  Text(_expiryText(o['expires_at']),
                      style: const TextStyle(color: Colors.white70, fontSize: 12)),
                ]),
              ),
            );
          },
        ),
      ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final cityName = _city?['name'] as String?;
    final welcome = (_city?['welcome_message'] as String?) ?? 'نوصّل أي شيء في مدينتك';
    return Scaffold(
      appBar: AppBar(title: const MersalLogo(markSize: 32, horizontal: true)),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text('أهلاً $_name 👋',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          Text(welcome, style: const TextStyle(fontSize: 16)),
          const SizedBox(height: 8),
          _cityBanner(),
          _offersSection(),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Brand.primary, Brand.primaryLight]),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('اطلب أي شيء',
                    style: TextStyle(
                        color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                Text(
                    'اكتب ما تريده من أي محل في ${cityName != null ? 'مدينة $cityName' : 'مدينتك'}، وسيشتريه السائق ويوصله إليك. تدفع نقداً عند التسليم.',
                    style: const TextStyle(color: Colors.white)),
                const SizedBox(height: 16),
                FilledButton(
                  style: FilledButton.styleFrom(
                      backgroundColor: Brand.accent, foregroundColor: Colors.white),
                  onPressed: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const CustomOrderScreen())),
                  child: const Text('ابدأ طلباً جديداً'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          PulseGlow(
            active: _hasUpdates,
            radius: 14,
            child: OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                  minimumSize: const Size.fromHeight(52),
                  backgroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
              onPressed: () async {
                await Navigator.of(context)
                    .push(MaterialPageRoute(builder: (_) => const MyOrdersScreen()));
                _checkUpdates();
              },
              icon: Badge(
                isLabelVisible: _hasUpdates,
                smallSize: 11,
                backgroundColor: Colors.red,
                child: const Icon(Icons.receipt_long),
              ),
              label: const Text('طلباتي'),
            ),
          ),
          const SizedBox(height: 24),
          const Text('المتاجر والمطاعم قادمة قريباً.', style: TextStyle(color: Colors.black54)),
        ],
      ),
    );
  }
}
