import 'dart:async';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

import '../core/logo.dart';
import '../core/pulse.dart';
import '../core/push.dart';
import '../core/theme.dart';
import '../data/order_repository.dart';
import 'assistant_fab.dart';
import 'bazaar_order_screen.dart';
import 'custom_order_screen.dart';
import 'my_orders_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _repo = OrderRepository();
  final _page = PageController(viewportFraction: 0.9);
  Timer? _timer;
  int _tick = 0;

  String _name = '';
  Map<String, dynamic>? _city; // the served city the customer is in
  bool _cityLoading = true;
  String? _cityNote; // outside | no_permission | gps_off | failed
  List<Map<String, dynamic>> _offers = [];
  bool _hasUpdates = false; // any order changed / unread chat since last opened
  Map<String, dynamic>? _bazaar; // weekly bazaar service of the city (null when the city has none)
  num _discount = 0; // welcome discount percent for a new customer

  @override
  void initState() {
    super.initState();
    _repo.getProfile().then((p) {
      if (mounted) setState(() => _name = (p['display_name'] ?? '') as String);
    });
    _detectCity();
    _checkUpdates();
    _loadDiscount();
    _timer = Timer.periodic(const Duration(seconds: 15), (_) {
      _tick++;
      _checkUpdates();
      if (_tick % 4 == 0) {
        _loadOffers(); // offers and bazaar window every minute
        _loadBazaar();
      }
    });
    Push.pushTick.addListener(_checkUpdates);
  }

  @override
  void dispose() {
    _timer?.cancel();
    Push.pushTick.removeListener(_checkUpdates);
    _page.dispose();
    super.dispose();
  }

  /// Finds the city from the phone's location (Jarabulus, Maskanah, ...).
  Future<void> _detectCity() async {
    setState(() {
      _cityLoading = true;
      _cityNote = null;
    });
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        _cityFailed('gps_off');
        return;
      }
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        _cityFailed('no_permission');
        return;
      }
      final pos = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
            accuracy: LocationAccuracy.medium, timeLimit: Duration(seconds: 12)),
      );
      final city = await _repo.resolveCity(pos.latitude, pos.longitude);
      if (!mounted) return;
      if (city == null) {
        _cityFailed('outside');
      } else {
        setState(() {
          _city = city;
          _cityLoading = false;
        });
        _loadOffers();
        _loadBazaar();
      }
    } catch (_) {
      _cityFailed('failed');
    }
  }

  void _cityFailed(String why) {
    if (!mounted) return;
    setState(() {
      _cityLoading = false;
      _cityNote = why;
      _bazaar = null;
    });
    _loadOffers(); // global offers still apply
  }

  Future<void> _pickCity() async {
    List<Map<String, dynamic>> cities;
    try {
      cities = await _repo.cities();
    } catch (_) {
      return;
    }
    if (!mounted) return;
    final chosen = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      builder: (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text('اختر مدينتك', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          ),
          for (final city in cities)
            ListTile(
              leading: const Icon(Icons.location_city),
              title: Text('${city['name']}'),
              onTap: () => Navigator.pop(c, city),
            ),
          const SizedBox(height: 8),
        ]),
      ),
    );
    if (chosen != null && mounted) {
      setState(() {
        _city = chosen;
        _cityNote = null;
      });
      _loadOffers();
      _loadBazaar();
    }
  }

  Future<void> _loadOffers() async {
    try {
      final offers = await _repo.activeOffers(_city?['id'] as String?);
      if (mounted) setState(() => _offers = offers);
    } catch (_) {}
  }

  Future<void> _loadDiscount() async {
    final d = await _repo.welcomeDiscountPercent();
    if (mounted) setState(() => _discount = d);
  }

  Future<void> _loadBazaar() async {
    final id = _city?['id'] as String?;
    if (id == null) {
      if (mounted) setState(() => _bazaar = null);
      return;
    }
    try {
      final b = await _repo.bazaarStatus(id);
      if (mounted) setState(() => _bazaar = b);
    } catch (_) {}
  }

  String _money(dynamic v) {
    final n = v is num ? v : num.tryParse('$v') ?? 0;
    return fmt(n);
  }

  /// First press: explain the service once. Then open the booking form (only while booking is open).
  Future<void> _openBazaar() async {
    final b = _bazaar;
    if (b == null) return;
    final sym = '${b['currency_symbol'] ?? ''}';
    if (!await _repo.hasFlag('bazaar_intro')) {
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (c) => AlertDialog(
          title: Text('${b['name'] ?? 'طلب بيزار'}'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${b['intro_text'] ?? ''}'),
              const SizedBox(height: 12),
              Text('• يفتح الحجز كل يوم اثنين الساعة 7 صباحاً، ويُسلَّم الطلب يوم ${b['delivery_day_text'] ?? 'الثلاثاء'}، ويُغلق الحجز يوم ${b['delivery_day_text'] ?? 'الثلاثاء'} الساعة 4 مساءً.'),
              const SizedBox(height: 6),
              Text('• سعر التوصيل الأساسي ${_money(b['base_fee'])} $sym، ولكل ${b['step_m']} متر زائدة عن المسافة الأساسية تُضاف ${_money(b['step_fee'])} $sym.'),
              const SizedBox(height: 6),
              const Text('• تدفع نقداً عند التسليم.'),
            ]),
          ),
          actions: [
            FilledButton(
                style: FilledButton.styleFrom(minimumSize: const Size(120, 44)),
                onPressed: () => Navigator.pop(c),
                child: const Text('فهمت')),
          ],
        ),
      );
      await _repo.setFlag('bazaar_intro');
    }
    if (!mounted) return;
    if (b['is_open'] != true) {
      await showDialog<void>(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('الحجز مغلق حالياً'),
          content: Text('يفتح حجز ${b['name'] ?? 'طلب بيزار'} كل يوم اثنين الساعة 7 صباحاً، ويُغلق يوم ${b['delivery_day_text'] ?? 'الثلاثاء'} الساعة 4 مساءً.'),
          actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('حسناً'))],
        ),
      );
      return;
    }
    await Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => BazaarOrderScreen(service: b)));
    _loadDiscount();
    _checkUpdates();
    _loadBazaar();
  }

  Widget _bazaarButton() {
    final b = _bazaar;
    if (b == null) return const SizedBox.shrink();
    final open = b['is_open'] == true;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const SizedBox(height: 10),
      FilledButton.icon(
        style: FilledButton.styleFrom(
          backgroundColor: open ? const Color(0xFFEA580C) : const Color(0xFFEA580C).withValues(alpha: 0.55),
          foregroundColor: Colors.white,
        ),
        onPressed: _openBazaar,
        icon: const Icon(Icons.shopping_basket_outlined),
        label: Text('${b['name'] ?? 'طلب بيزار'}'),
      ),
      const SizedBox(height: 4),
      Text(
        open
            ? 'الحجز متاح الآن حتى ${b['delivery_day_text'] ?? 'الثلاثاء'} الساعة 4 مساءً'
            : 'يفتح الحجز كل يوم اثنين الساعة 7 صباحاً',
        textAlign: TextAlign.center,
        style: const TextStyle(color: Colors.white70, fontSize: 12),
      ),
    ]);
  }

  Widget _discountBanner() {
    if (_discount <= 0) return const SizedBox.shrink();
    return Container(
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.green.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.green.withValues(alpha: 0.4)),
      ),
      child: Row(children: [
        const Icon(Icons.card_giftcard, color: Colors.green),
        const SizedBox(width: 10),
        Expanded(
          child: Text('خصم ${_money(_discount)}% على أجرة توصيل أول طلب لك!',
              style: const TextStyle(fontWeight: FontWeight.w800)),
        ),
      ]),
    );
  }

  Future<void> _checkUpdates() async {
    try {
      final orders = await _repo.myOrders();
      final unseen = await _repo.unseenIds(orders);
      final chat = await _repo.unreadChatOrderIds();
      if (mounted) setState(() => _hasUpdates = unseen.isNotEmpty || chat.isNotEmpty);
    } catch (_) {}
  }

  String _expiryText(dynamic iso) {
    final t = DateTime.tryParse('$iso')?.toLocal();
    if (t == null) return '';
    final d = t.difference(DateTime.now());
    if (d.inDays >= 1) return 'ينتهي بعد ${d.inDays} يوم';
    if (d.inHours >= 1) return 'ينتهي بعد ${d.inHours} ساعة';
    return 'ينتهي قريباً';
  }

  Widget _cityBanner() {
    if (_cityLoading) {
      return const Row(children: [
        SizedBox(height: 16, width: 16, child: CircularProgressIndicator(strokeWidth: 2)),
        SizedBox(width: 10),
        Text('جارٍ تحديد موقعك…', style: TextStyle(color: Colors.black54)),
      ]);
    }
    if (_city != null) {
      return Row(children: [
        const Icon(Icons.place, size: 18, color: Brand.primary),
        const SizedBox(width: 4),
        Text('${_city!['name']}', style: const TextStyle(fontWeight: FontWeight.w700)),
        TextButton(onPressed: _pickCity, child: const Text('تغيير')),
      ]);
    }
    final msg = switch (_cityNote) {
      'outside' => 'موقعك الحالي خارج مناطق خدمتنا (جرابلس ومسكنة).',
      'no_permission' => 'لم يُسمح بالوصول إلى الموقع، فلم نتمكن من تحديد مدينتك.',
      'gps_off' => 'خدمة الموقع (GPS) مغلقة، فلم نتمكن من تحديد مدينتك.',
      _ => 'تعذر تحديد موقعك تلقائياً.',
    };
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
          color: Colors.orange.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(12)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(msg),
        const SizedBox(height: 6),
        Row(children: [
          TextButton(onPressed: _detectCity, child: const Text('إعادة المحاولة')),
          TextButton(onPressed: _pickCity, child: const Text('اختيار المدينة')),
        ]),
      ]),
    );
  }

  Widget _offersSection() {
    if (_offers.isEmpty) return const SizedBox.shrink();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 20),
      const Text('العروض', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
      const SizedBox(height: 10),
      SizedBox(
        height: 140,
        child: PageView.builder(
          controller: _page,
          padEnds: false,
          itemCount: _offers.length,
          itemBuilder: (_, i) {
            final o = _offers[i];
            return Padding(
              padding: const EdgeInsetsDirectional.only(end: 10),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                      colors: [Brand.accent, Color(0xFF14B8A6)],
                      begin: Alignment.topRight,
                      end: Alignment.bottomLeft),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    const Icon(Icons.local_offer, color: Colors.white, size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text('${o['title']}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              color: Colors.white, fontWeight: FontWeight.w900, fontSize: 17)),
                    ),
                  ]),
                  const SizedBox(height: 6),
                  Expanded(
                    child: Text('${o['body']}',
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: Colors.white)),
                  ),
                  Text(_expiryText(o['expires_at']),
                      style: const TextStyle(color: Colors.white70, fontSize: 12)),
                ]),
              ),
            );
          },
        ),
      ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final cityName = _city?['name'] as String?;
    final welcome = (_city?['welcome_message'] as String?) ?? 'نوصّل أي شيء في مدينتك';
    return Scaffold(
      appBar: AppBar(title: const MersalLogo(markSize: 32, horizontal: true)),
      // startFloat = the right-hand side in this right-to-left screen
      floatingActionButton: const AssistantFab(),
      floatingActionButtonLocation: FloatingActionButtonLocation.startFloat,
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text('أهلاً $_name 👋',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          Text(welcome, style: const TextStyle(fontSize: 16)),
          const SizedBox(height: 8),
          _cityBanner(),
          _discountBanner(),
          _offersSection(),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Brand.primary, Brand.primaryLight]),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('اطلب أي شيء',
                    style: TextStyle(
                        color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                Text(
                    'اكتب ما تريده من أي محل في ${cityName != null ? 'مدينة $cityName' : 'مدينتك'}، وسيشتريه السائق ويوصله إليك. تدفع نقداً عند التسليم.',
                    style: const TextStyle(color: Colors.white)),
                const SizedBox(height: 16),
                FilledButton(
                  style: FilledButton.styleFrom(
                      backgroundColor: Brand.accent, foregroundColor: Colors.white),
                  onPressed: () async {
                    await Navigator.of(context)
                        .push(MaterialPageRoute(builder: (_) => const CustomOrderScreen()));
                    _loadDiscount();
                    _checkUpdates();
                  },
                  child: const Text('ابدأ طلباً جديداً'),
                ),
                _bazaarButton(),
              ],
            ),
          ),
          const SizedBox(height: 16),
          PulseGlow(
            active: _hasUpdates,
            radius: 14,
            child: OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                  minimumSize: const Size.fromHeight(52),
                  backgroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
              onPressed: () async {
                await Navigator.of(context)
                    .push(MaterialPageRoute(builder: (_) => const MyOrdersScreen()));
                _checkUpdates();
                _loadDiscount();
              },
              icon: Badge(
                isLabelVisible: _hasUpdates,
                smallSize: 11,
                backgroundColor: Colors.red,
                child: const Icon(Icons.receipt_long),
              ),
              label: const Text('طلباتي'),
            ),
          ),
          const SizedBox(height: 24),
          const Text('المتاجر والمطاعم قادمة قريباً.', style: TextStyle(color: Colors.black54)),
        ],
      ),
    );
  }
}
