import 'package:flutter/material.dart';

import '../core/logo.dart';
import '../core/theme.dart';
import '../data/order_repository.dart';
import 'custom_order_screen.dart';
import 'my_orders_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _name = '';

  @override
  void initState() {
    super.initState();
    OrderRepository().getProfile().then((p) {
      if (mounted) setState(() => _name = (p['display_name'] ?? '') as String);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const MersalLogo(markSize: 32, horizontal: true)),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text('أهلاً $_name 👋',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          const Text('نوصّل لك أي شيء داخل جرابلس'),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                  colors: [Brand.primary, Brand.primaryLight]),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('اطلب أي شيء',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                const Text(
                    'اكتب ما تريده من أي محل في جرابلس، وسنرسل لك السعر للموافقة قبل التنفيذ.',
                    style: TextStyle(color: Colors.white)),
                const SizedBox(height: 16),
                FilledButton(
                  style: FilledButton.styleFrom(
                      backgroundColor: Brand.accent, foregroundColor: Colors.white),
                  onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => const CustomOrderScreen())),
                  child: const Text('ابدأ طلباً جديداً'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(52),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
            onPressed: () => Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => const MyOrdersScreen())),
            icon: const Icon(Icons.receipt_long),
            label: const Text('طلباتي'),
          ),
          const SizedBox(height: 24),
          const Text('المتاجر والمطاعم قادمة قريباً.',
              style: TextStyle(color: Colors.black54)),
        ],
      ),
    );
  }
}
