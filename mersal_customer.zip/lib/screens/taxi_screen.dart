import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/ico3d.dart';
import '../core/theme.dart';
import '../data/routing_service.dart';
import 'location_picker.dart';

/// "طلب تاكسي": choose the pickup and an optional destination, and see the fare before ordering.
class TaxiScreen extends StatefulWidget {
  const TaxiScreen({super.key});

  @override
  State<TaxiScreen> createState() => _TaxiScreenState();
}

class _TaxiScreenState extends State<TaxiScreen> {
  LatLng? _pickup;
  LatLng? _dest;
  int? _tripM;
  Map<String, dynamic>? _quote;
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _useMyLocation();
  }

  Future<void> _useMyLocation() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        if (mounted) {
          setState(() => _error = 'اسمح بالوصول إلى الموقع، أو اختر نقطة الانطلاق على الخريطة');
        }
        return;
      }
      final pos = await Geolocator.getCurrentPosition(
          locationSettings: const LocationSettings(
              accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 15)));
      _pickup = LatLng(pos.latitude, pos.longitude);
      await _quoteNow();
    } catch (_) {
      if (mounted) setState(() => _error = 'تعذر تحديد موقعك. اختر نقطة الانطلاق على الخريطة');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _pickPickup() async {
    final picked = await Navigator.of(context).push<LatLng>(
        MaterialPageRoute(builder: (_) => LocationPicker(initial: _pickup)));
    if (picked == null) return;
    _pickup = picked;
    // a new pickup changes the road distance to the destination
    if (_dest != null) return _pickDestinationFrom(picked);
    await _quoteNow();
  }

  Future<void> _pickDestination() async {
    final from = _pickup;
    if (from == null) return;
    final picked = await Navigator.of(context).push<LatLng>(
        MaterialPageRoute(builder: (_) => LocationPicker(initial: _dest ?? from)));
    if (picked == null) return;
    _dest = picked;
    await _pickDestinationFrom(from);
  }

  Future<void> _pickDestinationFrom(LatLng from) async {
    final to = _dest;
    if (to == null) return;
    setState(() => _busy = true);
    final m = await OsrmRoutingService().drivingDistanceMeters(
        fromLat: from.latitude, fromLon: from.longitude, toLat: to.latitude, toLon: to.longitude);
    if (!mounted) return;
    if (m == null) {
      setState(() {
        _dest = null;
        _tripM = null;
        _busy = false;
        _error = 'تعذر حساب مسافة الطريق إلى الوجهة، جرّب نقطة أخرى';
      });
      return;
    }
    _tripM = m;
    await _quoteNow();
  }

  void _clearDestination() {
    _dest = null;
    _tripM = null;
    _quoteNow();
  }

  Future<void> _quoteNow() async {
    final p = _pickup;
    if (p == null) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final rows = await Supabase.instance.client.rpc('taxi_quote', params: {
        'p_lat': p.latitude,
        'p_lon': p.longitude,
        'p_trip_m': _tripM,
      }) as List;
      if (!mounted) return;
      setState(() =>
          _quote = rows.isEmpty ? null : Map<String, dynamic>.from(rows.first as Map));
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _quote = null;
        _error = '$e'.contains('taxi_not_available')
            ? 'خدمة التاكسي متاحة في جرابلس فقط حالياً'
            : 'تعذر حساب السعر، حاول مرة أخرى';
      });
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  num _n(dynamic v) => (v as num?) ?? 0;

  Widget _card(Widget child) => Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 12, offset: const Offset(0, 4))],
        ),
        child: child,
      );

  Widget _priceCard() {
    final q = _quote;
    if (q == null) return const SizedBox.shrink();
    final cur = (q['currency_symbol'] ?? 'ل.ت').toString();
    final isOpen = q['is_open'] == true;
    final pickupSur = _n(q['pickup_surcharge']);
    final tripSur = _n(q['trip_surcharge']);
    return _card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('السعر', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
      const SizedBox(height: 8),
      _line('الأجرة الأساسية', '${_n(q['base_fee'])} $cur'),
      if (pickupSur > 0) _line('أجرة الانطلاق (بعد 500 م من السوق)', '$pickupSur $cur'),
      if (tripSur > 0) _line('مسافة زائدة على الرحلة', '$tripSur $cur'),
      const Divider(height: 22),
      _line(isOpen ? 'يبدأ السعر من' : 'المجموع', '${_n(q['total'])} $cur', bold: true),
      if (isOpen)
        const Padding(
          padding: EdgeInsets.only(top: 8),
          child: Text(
            'رحلة مفتوحة: السعر النهائي يُحسب حسب المسافة التي تقطعها عند الانتهاء.',
            style: TextStyle(color: Colors.black54, fontSize: 12),
          ),
        ),
    ]));
  }

  Widget _line(String label, String value, {bool bold = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(children: [
          Expanded(child: Text(label, style: TextStyle(fontWeight: bold ? FontWeight.w900 : FontWeight.w500))),
          Text(value, style: TextStyle(fontWeight: bold ? FontWeight.w900 : FontWeight.w600)),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    final km = _tripM == null ? null : _tripM! / 1000;
    return Scaffold(
      appBar: AppBar(title: const Text('طلب تاكسي')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Center(child: const Ico3D('taxi', size: 96)),
        const SizedBox(height: 12),
        _card(Row(children: [
          const Icon(Icons.my_location, color: Brand.primary),
          const SizedBox(width: 10),
          Expanded(
            child: Text(_pickup == null ? 'حدد نقطة الانطلاق' : 'نقطة الانطلاق: موقعك',
                style: const TextStyle(fontWeight: FontWeight.w700)),
          ),
          TextButton(onPressed: _busy ? null : _pickPickup, child: const Text('تغيير')),
        ])),
        _card(Row(children: [
          const Icon(Icons.flag_outlined, color: Brand.primary),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              _dest == null
                  ? 'الوجهة (اختياري): بدونها تكون الرحلة مفتوحة'
                  : 'الوجهة: ${km!.toStringAsFixed(1)} كم عن طريق الطريق',
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
          ),
          if (_dest == null)
            TextButton(onPressed: _busy || _pickup == null ? null : _pickDestination, child: const Text('اختيار'))
          else
            IconButton(onPressed: _busy ? null : _clearDestination, icon: const Icon(Icons.close)),
        ])),
        if (_busy) const Padding(padding: EdgeInsets.all(12), child: Center(child: CircularProgressIndicator())),
        if (_error != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.red)),
          ),
        _priceCard(),
        const SizedBox(height: 8),
        FilledButton(
          onPressed: null,
          child: const Text('اطلب التاكسي (قريباً)'),
        ),
      ]),
    );
  }
}
