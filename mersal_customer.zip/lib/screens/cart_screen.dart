import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';

import '../core/cart.dart';
import '../core/theme.dart';
import '../data/order_repository.dart';
import '../data/routing_service.dart';
import 'fee_card.dart';
import 'location_picker.dart';
import 'my_orders_screen.dart';

/// The cart: edit quantities, choose the delivery point, see the final price and confirm.
/// Delivery is priced like every other order, but the road distance starts at the STORE
/// (the store replaces the market as the origin).
class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final _repo = OrderRepository();
  final _cart = Cart.instance;
  final _phone = TextEditingController();
  final _notes = TextEditingController();
  LatLng? _location;
  int? _distanceM;
  Map<String, dynamic>? _fee;
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _repo.getProfile().then((p) {
      final phone = p['phone'] as String?;
      if (mounted && phone != null && _phone.text.isEmpty) _phone.text = phone;
    }).catchError((_) {});
  }

  @override
  void dispose() {
    _phone.dispose();
    _notes.dispose();
    super.dispose();
  }

  Future<void> _pickLocation() async {
    final store = _cart.store;
    if (store == null) return;
    final res = await Navigator.of(context)
        .push<LatLng>(MaterialPageRoute(builder: (_) => LocationPicker(initial: _location)));
    if (res == null) return;
    setState(() {
      _location = res;
      _distanceM = null;
      _fee = null;
      _busy = true;
      _error = null;
    });
    try {
      final city = await _repo.resolveCity(res.latitude, res.longitude);
      if (city == null) throw Exception('outside');
      final m = await OsrmRoutingService().drivingDistanceMeters(
        fromLat: (store['latitude'] as num).toDouble(),
        fromLon: (store['longitude'] as num).toDouble(),
        toLat: res.latitude,
        toLon: res.longitude,
      );
      if (m == null) throw Exception('route');
      final fee = await _repo.feePreview(res.latitude, res.longitude, m);
      if (!mounted) return;
      setState(() {
        _distanceM = m;
        _fee = fee;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _location = null;
        _error = e.toString().contains('outside')
            ? 'موقعك خارج مناطق خدمتنا.'
            : 'تعذر حساب أجرة التوصيل. اختر الموقع مرة أخرى.';
      });
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _submit() async {
    if (_cart.isEmpty) return;
    if (_location == null || _distanceM == null) {
      setState(() => _error = 'حدد موقع التوصيل وانتظر حساب الأجرة');
      return;
    }
    if (_phone.text.trim().length < 7) {
      setState(() => _error = 'اكتب رقم هاتف صحيح للتواصل');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await _repo.createStoreOrder(
        items: _cart.toItems(),
        lat: _location!.latitude,
        lon: _location!.longitude,
        address: 'حسب الموقع المحدد على الخريطة',
        phone: _phone.text.trim(),
        notes: _notes.text.trim().isEmpty ? null : _notes.text.trim(),
        routeDistanceM: _distanceM!,
      );
      _cart.clear();
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('تم إرسال طلبك، بانتظار قبول السائق.')));
      Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const MyOrdersScreen()), (r) => r.isFirst);
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: _cart,
      builder: (context, _) {
        if (_cart.isEmpty) {
          return Scaffold(
            appBar: AppBar(title: const Text('السلة')),
            body: const Center(child: Text('السلة فارغة')),
          );
        }
        final store = _cart.store!;
        final cur = (store['currency_symbol'] ?? 'ل.ت').toString();
        final items = _cart.subtotal;
        final num delivery = _fee == null ? 0 : (_fee!['delivery_total'] as num);
        return Scaffold(
          appBar: AppBar(title: const Text('السلة'), actions: [
            TextButton(onPressed: _busy ? null : _cart.clear, child: const Text('إفراغ')),
          ]),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Row(children: [
                const Icon(Icons.storefront_rounded, color: Brand.primary),
                const SizedBox(width: 8),
                Expanded(
                    child: Text('${store['name']}',
                        style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18))),
              ]),
              const SizedBox(height: 10),
              for (final l in _cart.lines)
                Padding(padding: const EdgeInsets.only(bottom: 8), child: _lineCard(l, cur)),
              const SizedBox(height: 6),
              OutlinedButton.icon(
                onPressed: _busy ? null : _pickLocation,
                icon: const Icon(Icons.place_outlined),
                label: Text(_location == null ? 'حدد موقع التوصيل *' : 'تم تحديد موقع التوصيل ✓'),
              ),
              if (_fee != null) ...[
                const SizedBox(height: 10),
                FeeCard(fee: _fee!),
              ],
              const SizedBox(height: 10),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(children: [
                    Row(children: [
                      const Text('سعر الأصناف'),
                      const Spacer(),
                      Text('${fmt(items)} $cur'),
                    ]),
                    const SizedBox(height: 4),
                    Row(children: [
                      const Text('التوصيل'),
                      const Spacer(),
                      Text(_fee == null ? 'يُحسب بعد تحديد الموقع' : '${fmt(delivery)} $cur'),
                    ]),
                    const Divider(),
                    Row(children: [
                      const Text('الإجمالي نقداً عند التسليم',
                          style: TextStyle(fontWeight: FontWeight.w900)),
                      const Spacer(),
                      Text(_fee == null ? '${fmt(items)} $cur + التوصيل' : '${fmt(items + delivery)} $cur',
                          style: const TextStyle(fontWeight: FontWeight.w900, color: Brand.primary)),
                    ]),
                  ]),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _phone,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'رقم الهاتف *'),
              ),
              const SizedBox(height: 10),
              TextField(
                  controller: _notes,
                  maxLines: 2,
                  decoration: const InputDecoration(labelText: 'ملاحظات إضافية')),
              if (_error != null) ...[
                const SizedBox(height: 10),
                Text(_error!, style: const TextStyle(color: Colors.red)),
              ],
              const SizedBox(height: 16),
              FilledButton(
                style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
                onPressed: _busy ? null : _submit,
                child: _busy
                    ? const SizedBox(
                        height: 22,
                        width: 22,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Text('تأكيد الشراء وتوصيله عبر مرسال'),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _lineCard(CartLine l, String cur) {
    final url = l.product['image_url'] as String?;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Row(children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: (url != null && url.isNotEmpty)
                ? Image.network(url,
                    width: 60,
                    height: 60,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => const SizedBox(width: 60, height: 60))
                : const SizedBox(width: 60, height: 60),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${l.product['name']}',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w800)),
              Text('${fmt(l.price)} $cur × ${l.qty} = ${fmt(l.total)} $cur',
                  style: const TextStyle(color: Brand.primary, fontSize: 12, fontWeight: FontWeight.w700)),
            ]),
          ),
          Column(mainAxisSize: MainAxisSize.min, children: [
            Row(mainAxisSize: MainAxisSize.min, children: [
              IconButton(
                  visualDensity: VisualDensity.compact,
                  onPressed: l.qty < Cart.maxQty ? () => _cart.setQty(l.id, l.qty + 1) : null,
                  icon: const Icon(Icons.add_circle_outline)),
              Text('${l.qty}', style: const TextStyle(fontWeight: FontWeight.w900)),
              IconButton(
                  visualDensity: VisualDensity.compact,
                  onPressed: () => _cart.setQty(l.id, l.qty - 1),
                  icon: Icon(l.qty > 1 ? Icons.remove_circle_outline : Icons.delete_outline)),
            ]),
          ]),
        ]),
      ),
    );
  }
}
