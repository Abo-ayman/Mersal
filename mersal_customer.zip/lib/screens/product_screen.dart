import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../data/order_repository.dart';
import 'store_order_screen.dart';

/// One product: the picture fills the screen width, then the description, the price and «طلب المنتج».
class ProductScreen extends StatelessWidget {
  final Map<String, dynamic> product;
  final Map<String, dynamic> store;
  final String currency;
  const ProductScreen({super.key, required this.product, required this.store, required this.currency});

  void _zoom(BuildContext context, String url) {
    Navigator.of(context).push(MaterialPageRoute(
      fullscreenDialog: true,
      builder: (_) => Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(backgroundColor: Colors.black, foregroundColor: Colors.white),
        body: Center(
          child: InteractiveViewer(
            minScale: 1,
            maxScale: 5,
            child: Image.network(url, fit: BoxFit.contain),
          ),
        ),
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final url = product['image_url'] as String?;
    final desc = (product['description'] ?? '').toString().trim();
    final h = MediaQuery.of(context).size.height;
    return Scaffold(
      body: CustomScrollView(slivers: [
        SliverAppBar(
          pinned: true,
          expandedHeight: h * 0.5,
          backgroundColor: Brand.primary,
          foregroundColor: Colors.white,
          flexibleSpace: FlexibleSpaceBar(
            background: (url != null && url.isNotEmpty)
                ? GestureDetector(
                    onTap: () => _zoom(context, url),
                    child: Image.network(url,
                        width: double.infinity,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(color: Brand.primary.withValues(alpha: 0.2))),
                  )
                : Container(color: Brand.primary.withValues(alpha: 0.2)),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${product['name']}',
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              const SizedBox(height: 4),
              Text('من ${store['name']}', style: const TextStyle(color: Colors.black54)),
              const SizedBox(height: 14),
              Text('${fmt(product['price'] as num)} $currency',
                  style: const TextStyle(
                      fontSize: 24, fontWeight: FontWeight.w900, color: Brand.primary)),
              if (desc.isNotEmpty) ...[
                const SizedBox(height: 16),
                const Text('الوصف', style: TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 6),
                Text(desc, style: const TextStyle(height: 1.6)),
              ],
              const SizedBox(height: 90),
            ]),
          ),
        ),
      ]),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: FilledButton(
            style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                builder: (_) =>
                    StoreOrderScreen(product: product, store: store, currency: currency))),
            child: const Text('طلب المنتج', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          ),
        ),
      ),
    );
  }
}
