import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../data/order_repository.dart';
import '../core/cart.dart';
import 'cart_button.dart';
import 'cart_screen.dart';

/// One product: the picture fills the screen width, then the description, the price and «طلب المنتج».
class ProductScreen extends StatefulWidget {
  final Map<String, dynamic> product;
  final Map<String, dynamic> store;
  final String currency;
  const ProductScreen({super.key, required this.product, required this.store, required this.currency});

  @override
  State<ProductScreen> createState() => _ProductScreenState();
}

class _ProductScreenState extends State<ProductScreen> {
  int _qty = 1;

  Map<String, dynamic> get product => widget.product;
  Map<String, dynamic> get store => widget.store;
  String get currency => widget.currency;

  Future<void> _addToCart() async {
    final cart = Cart.instance;
    // the store map keeps the currency so the cart can show prices
    final st = {...store, 'currency_symbol': currency};
    if (!cart.accepts(st)) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('تفريغ السلة؟'),
          content: Text('سلتك تحتوي منتجات من «${cart.store?['name']}». الطلب الواحد يكون من متجر واحد، '
              'هل تريد تفريغ السلة وإضافة منتج من «${store['name']}»؟'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
            TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('تفريغ وإضافة')),
          ],
        ),
      );
      if (ok != true) return;
    }
    cart.add(st, {
      'id': product['id'],
      'name': product['name'],
      'price': product['price'],
      'image_url': product['image_url'],
    }, _qty);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: const Text('تمت الإضافة إلى السلة'),
      action: SnackBarAction(
        label: 'عرض السلة',
        onPressed: () => Navigator.of(context)
            .push(MaterialPageRoute(builder: (_) => const CartScreen())),
      ),
    ));
    setState(() => _qty = 1);
  }

  void _zoom(BuildContext context, String url) {
    Navigator.of(context).push(MaterialPageRoute(
      fullscreenDialog: true,
      builder: (_) => Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(backgroundColor: Colors.black, foregroundColor: Colors.white),
        body: Center(
          child: InteractiveViewer(
            minScale: 1,
            maxScale: 5,
            child: Image.network(url, fit: BoxFit.contain),
          ),
        ),
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final url = product['image_url'] as String?;
    final desc = (product['description'] ?? '').toString().trim();
    final h = MediaQuery.of(context).size.height;
    return Scaffold(
      body: CustomScrollView(slivers: [
        SliverAppBar(
          pinned: true,
          expandedHeight: h * 0.5,
          backgroundColor: Brand.primary,
          foregroundColor: Colors.white,
          actions: const [CartButton()],
          flexibleSpace: FlexibleSpaceBar(
            background: (url != null && url.isNotEmpty)
                ? GestureDetector(
                    onTap: () => _zoom(context, url),
                    child: Image.network(url,
                        width: double.infinity,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(color: Brand.primary.withValues(alpha: 0.2))),
                  )
                : Container(color: Brand.primary.withValues(alpha: 0.2)),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${product['name']}',
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              const SizedBox(height: 4),
              Text('من ${store['name']}', style: const TextStyle(color: Colors.black54)),
              const SizedBox(height: 14),
              Text('${fmt(product['price'] as num)} $currency',
                  style: const TextStyle(
                      fontSize: 24, fontWeight: FontWeight.w900, color: Brand.primary)),
              if (desc.isNotEmpty) ...[
                const SizedBox(height: 16),
                const Text('الوصف', style: TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 6),
                Text(desc, style: const TextStyle(height: 1.6)),
              ],
              const SizedBox(height: 90),
            ]),
          ),
        ),
      ]),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            Container(
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Brand.line)),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                IconButton(
                    onPressed: _qty < Cart.maxQty ? () => setState(() => _qty++) : null,
                    icon: const Icon(Icons.add)),
                Text('$_qty', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                IconButton(
                    onPressed: _qty > 1 ? () => setState(() => _qty--) : null,
                    icon: const Icon(Icons.remove)),
              ]),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: FilledButton.icon(
                style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
                onPressed: _addToCart,
                icon: const Icon(Icons.add_shopping_cart),
                label: const Text('إضافة إلى السلة',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
