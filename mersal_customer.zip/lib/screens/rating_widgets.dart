import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

String _ratingError(Object e) {
  final m = e.toString();
  if (m.contains('already_rated')) return 'سبق أن قيّمت هذا الطلب';
  if (m.contains('order_not_delivered')) return 'يمكن التقييم بعد التسليم فقط';
  if (m.contains('invalid_stars')) return 'اختر عدد النجوم';
  if (m.contains('not_allowed')) return 'لا يمكنك تقييم هذا الطلب';
  return 'تعذر إرسال التقييم، حاول مرة أخرى';
}

Widget _stars(int n, {double size = 22}) => Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (var i = 1; i <= 5; i++)
          Icon(i <= n ? Icons.star_rounded : Icons.star_outline_rounded,
              color: Colors.amber, size: size),
      ],
    );

/// One line with the average rating of an account, e.g. "تقييم السائق: ★ 4.5 (12)".
class RatingBadge extends StatelessWidget {
  final String? userId;
  final String label;
  const RatingBadge({super.key, required this.userId, required this.label});

  Future<({double avg, int count})?> _load() async {
    final res = await Supabase.instance.client.rpc('user_rating', params: {'p_user': userId});
    final rows = res as List;
    if (rows.isEmpty) return null;
    final c = (rows.first['rating_count'] as num?)?.toInt() ?? 0;
    final a = rows.first['avg_stars'];
    if (c == 0 || a == null) return null;
    return (avg: (a as num).toDouble(), count: c);
  }

  @override
  Widget build(BuildContext context) {
    if (userId == null) return const SizedBox.shrink();
    return FutureBuilder<({double avg, int count})?>(
      future: _load(),
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) return const SizedBox.shrink();
        final r = snap.data;
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Row(children: [
            const Icon(Icons.star_rounded, color: Colors.amber, size: 20),
            const SizedBox(width: 6),
            Text(r == null
                ? '$label: بلا تقييم بعد'
                : '$label: ${r.avg.toStringAsFixed(1)} من 5 (${r.count})'),
          ]),
        );
      },
    );
  }
}

/// Lets the signed-in user rate the other party of a delivered order (once).
class RatingCard extends StatefulWidget {
  final String orderId;
  final String title; // e.g. "قيّم السائق"
  const RatingCard({super.key, required this.orderId, required this.title});

  @override
  State<RatingCard> createState() => _RatingCardState();
}

class _RatingCardState extends State<RatingCard> {
  final _db = Supabase.instance.client;
  final _comment = TextEditingController();
  Map<String, dynamic>? _mine;
  bool _loaded = false;
  bool _busy = false;
  int _selected = 0;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final me = _db.auth.currentUser?.id;
      if (me != null) {
        _mine = await _db
            .from('order_ratings')
            .select('stars, comment')
            .eq('order_id', widget.orderId)
            .eq('rater_id', me)
            .maybeSingle();
      }
    } catch (_) {}
    if (mounted) setState(() => _loaded = true);
  }

  Future<void> _send() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await _db.rpc('rate_order', params: {
        'p_order': widget.orderId,
        'p_stars': _selected,
        'p_comment': _comment.text.trim().isEmpty ? null : _comment.text.trim(),
      });
      await _load();
    } catch (e) {
      setState(() => _error = _ratingError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) return const SizedBox.shrink();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: _mine != null
            ? Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('تم إرسال تقييمك، شكراً لك',
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 6),
                _stars((_mine!['stars'] as num).toInt(), size: 26),
                if ((_mine!['comment'] ?? '').toString().isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text('${_mine!['comment']}'),
                  ),
              ])
            : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(widget.title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                const SizedBox(height: 6),
                Row(children: [
                  for (var i = 1; i <= 5; i++)
                    IconButton(
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(minWidth: 44, minHeight: 44),
                      onPressed: _busy ? null : () => setState(() => _selected = i),
                      icon: Icon(i <= _selected ? Icons.star_rounded : Icons.star_outline_rounded,
                          color: Colors.amber, size: 34),
                    ),
                ]),
                TextField(
                  controller: _comment,
                  maxLines: 2,
                  decoration: const InputDecoration(hintText: 'تعليق (اختياري)'),
                ),
                if (_error != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(_error!, style: const TextStyle(color: Colors.red)),
                  ),
                const SizedBox(height: 10),
                FilledButton(
                  onPressed: (_busy || _selected == 0) ? null : _send,
                  child: const Text('إرسال التقييم'),
                ),
              ]),
      ),
    );
  }
}
