import 'package:flutter/material.dart';

import '../main.dart' show mirsalGreen;
import 'assistant_screen.dart';

/// Floating button that opens the personal assistant.
class AssistantFab extends StatelessWidget {
  const AssistantFab({super.key});

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(
      heroTag: 'mersal-assistant',
      backgroundColor: mirsalGreen,
      foregroundColor: Colors.white,
      tooltip: 'المساعد الشخصي',
      onPressed: () => Navigator.of(context)
          .push(MaterialPageRoute(builder: (_) => const AssistantScreen())),
      child: const Icon(Icons.auto_awesome_rounded),
    );
  }
}
