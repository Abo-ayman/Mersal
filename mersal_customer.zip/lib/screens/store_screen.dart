import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../data/order_repository.dart';
import 'cart_button.dart';
import 'product_screen.dart';

/// The products a store added: small picture and title per product.
class StoreScreen extends StatefulWidget {
  final Map<String, dynamic> store;
  const StoreScreen({super.key, required this.store});

  @override
  State<StoreScreen> createState() => _StoreScreenState();
}

class _StoreScreenState extends State<StoreScreen> {
  final _repo = OrderRepository();
  late Future<List<Map<String, dynamic>>> _future = _repo.storeProducts('${widget.store['id']}');

  void _reload() => setState(() => _future = _repo.storeProducts('${widget.store['id']}'));

  @override
  Widget build(BuildContext context) {
    final desc = (widget.store['description'] ?? '').toString();
    final cur = (widget.store['currency_symbol'] ?? 'ل.ت').toString();
    return Scaffold(
      appBar: AppBar(title: Text('${widget.store['name']}'), actions: const [CartButton()]),
      body: RefreshIndicator(
        onRefresh: () async => _reload(),
        child: FutureBuilder<List<Map<String, dynamic>>>(
          future: _future,
          builder: (context, snap) {
            if (snap.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snap.hasError) {
              return ListView(children: [
                const SizedBox(height: 120),
                const Center(child: Text('تعذر تحميل المنتجات')),
                Center(child: TextButton(onPressed: _reload, child: const Text('إعادة المحاولة'))),
              ]);
            }
            final items = snap.data!;
            return CustomScrollView(slivers: [
              if (desc.isNotEmpty)
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                    child: Text(desc, style: const TextStyle(color: Colors.black54)),
                  ),
                ),
              if (widget.store['is_open'] == false)
                SliverToBoxAdapter(
                  child: Container(
                    margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                        color: Colors.orange.withValues(alpha: 0.14),
                        borderRadius: BorderRadius.circular(12)),
                    child: const Text('المتجر مغلق حالياً، يمكنك تصفح المنتجات والطلب عند فتحه'),
                  ),
                ),
              if (items.isEmpty)
                const SliverFillRemaining(
                    hasScrollBody: false, child: Center(child: Text('لا توجد منتجات بعد')))
              else
                SliverPadding(
                  padding: const EdgeInsets.all(16),
                  sliver: SliverGrid(
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      childAspectRatio: 0.78,
                    ),
                    delegate: SliverChildBuilderDelegate(
                      (_, i) => _ProductTile(
                        product: items[i],
                        currency: cur,
                        onTap: () => Navigator.of(context).push(MaterialPageRoute(
                            builder: (_) => ProductScreen(
                                product: items[i], store: widget.store, currency: cur))),
                      ),
                      childCount: items.length,
                    ),
                  ),
                ),
            ]);
          },
        ),
      ),
    );
  }
}

class _ProductTile extends StatelessWidget {
  final Map<String, dynamic> product;
  final String currency;
  final VoidCallback onTap;
  const _ProductTile({required this.product, required this.currency, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final url = product['image_url'] as String?;
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 10, offset: const Offset(0, 4))],
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            child: (url != null && url.isNotEmpty)
                ? Image.network(url,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => const _Ph())
                : const _Ph(),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 8, 10, 2),
            child: Text('${product['name']}',
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w800)),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
            child: Text('${fmt(product['price'] as num)} $currency',
                style: const TextStyle(color: Brand.primary, fontWeight: FontWeight.w800)),
          ),
        ]),
      ),
    );
  }
}

class _Ph extends StatelessWidget {
  const _Ph();

  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        color: Brand.primary.withValues(alpha: 0.12),
        child: const Icon(Icons.image_outlined, size: 40, color: Brand.primary),
      );
}
