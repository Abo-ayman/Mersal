import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../data/order_repository.dart';
import 'store_screen.dart';

/// «المتاجر»: one card per store (name over the store picture).
class StoresScreen extends StatefulWidget {
  const StoresScreen({super.key});

  @override
  State<StoresScreen> createState() => _StoresScreenState();
}

class _StoresScreenState extends State<StoresScreen> {
  final _repo = OrderRepository();
  late Future<List<Map<String, dynamic>>> _future = _repo.stores();

  void _reload() => setState(() => _future = _repo.stores());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المتاجر')),
      body: RefreshIndicator(
        onRefresh: () async => _reload(),
        child: FutureBuilder<List<Map<String, dynamic>>>(
          future: _future,
          builder: (context, snap) {
            if (snap.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snap.hasError) {
              return ListView(children: [
                const SizedBox(height: 120),
                const Center(child: Text('تعذر تحميل المتاجر')),
                Center(child: TextButton(onPressed: _reload, child: const Text('إعادة المحاولة'))),
              ]);
            }
            final stores = snap.data!;
            if (stores.isEmpty) {
              return ListView(children: const [
                SizedBox(height: 140),
                Center(child: Text('لا توجد متاجر متاحة الآن')),
              ]);
            }
            return ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: stores.length,
              separatorBuilder: (_, __) => const SizedBox(height: 14),
              itemBuilder: (_, i) => _StoreCard(
                store: stores[i],
                onTap: () => Navigator.of(context)
                    .push(MaterialPageRoute(builder: (_) => StoreScreen(store: stores[i]))),
              ),
            );
          },
        ),
      ),
    );
  }
}

class _StoreCard extends StatelessWidget {
  final Map<String, dynamic> store;
  final VoidCallback onTap;
  const _StoreCard({required this.store, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final url = store['image_url'] as String?;
    final open = store['is_open'] != false;
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: AspectRatio(
          aspectRatio: 16 / 7,
          child: Stack(fit: StackFit.expand, children: [
            if (url != null && url.isNotEmpty)
              Image.network(url,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const _StorePlaceholder())
            else
              const _StorePlaceholder(),
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.transparent, Color(0xB3000000)],
                ),
              ),
            ),
            if (!open)
              Container(
                color: Colors.black45,
                alignment: Alignment.center,
                child: const Text('مغلق حالياً',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18)),
              ),
            PositionedDirectional(
              start: 14,
              end: 14,
              bottom: 12,
              child: Text('${store['name']}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      color: Colors.white, fontWeight: FontWeight.w900, fontSize: 20)),
            ),
          ]),
        ),
      ),
    );
  }
}

class _StorePlaceholder extends StatelessWidget {
  const _StorePlaceholder();

  @override
  Widget build(BuildContext context) => Container(
        color: Brand.primary.withValues(alpha: 0.18),
        alignment: Alignment.center,
        child: const Icon(Icons.storefront_rounded, size: 56, color: Brand.primary),
      );
}
