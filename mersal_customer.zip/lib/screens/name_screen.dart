import 'package:flutter/material.dart';

import '../data/order_repository.dart';
import 'home_screen.dart';

class NameScreen extends StatefulWidget {
  const NameScreen({super.key});

  @override
  State<NameScreen> createState() => _NameScreenState();
}

class _NameScreenState extends State<NameScreen> {
  final _ctrl = TextEditingController();
  bool _busy = false;
  String? _error;

  Future<void> _save() async {
    final name = _ctrl.text.trim();
    if (name.length < 2) {
      setState(() => _error = 'الاسم قصير جداً');
      return;
    }
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('تأكيد الاسم'),
        content: Text('سيكون اسمك «$name» ولا يمكن تغييره لاحقاً. هل تؤكد؟'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c, false), child: const Text('تعديل')),
          FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size(100, 44)),
              onPressed: () => Navigator.pop(c, true),
              child: const Text('تأكيد')),
        ],
      ),
    );
    if (ok != true) return;

    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await OrderRepository().setDisplayName(name);
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const HomeScreen()));
    } catch (e) {
      setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('مرحباً بك في مرسال')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('اختر اسمك',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            const Text('يظهر هذا الاسم للسائق في طلباتك. تنبيه: لا يمكن تغييره بعد التأكيد.'),
            const SizedBox(height: 20),
            TextField(
              controller: _ctrl,
              maxLength: 30,
              decoration: InputDecoration(hintText: 'مثال: أحمد', errorText: _error),
            ),
            const Spacer(),
            FilledButton(
              onPressed: _busy ? null : _save,
              child: _busy
                  ? const SizedBox(
                      height: 22,
                      width: 22,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Text('متابعة'),
            ),
          ],
        ),
      ),
    );
  }
}
