import 'dart:async';

import 'package:flutter/material.dart';

import '../core/push.dart';
import '../core/pulse.dart';
import '../core/tracker.dart';
import '../core/theme.dart';
import '../data/order_repository.dart';
import 'chat_button.dart';
import 'complaint_screen.dart';
import 'rating_widgets.dart';
import 'live_tracking_screen.dart';
import 'taxi_status_screen.dart';

const _statusAr = {
  'awaiting_review': 'بانتظار مراجعة السائق',
  'awaiting_customer_approval': 'بانتظار موافقتك على السعر',
  'pending_driver': 'بانتظار قبول السائق',
  'processing': 'تم قبول طلبك',
  'ready': 'جاهز للتوصيل',
  'on_the_way': 'في الطريق إليك',
  'arrived': 'وصل إلى الباب',
  'delivered': 'تم التسليم',
  'rejected': 'مرفوض',
  'cancelled': 'ملغى',
};

Map<String, dynamic>? _details(Map<String, dynamic> o) {
  final d = o['custom_order_details'];
  if (d is List) return d.isEmpty ? null : Map<String, dynamic>.from(d.first);
  if (d is Map) return Map<String, dynamic>.from(d);
  return null;
}

class MyOrdersScreen extends StatefulWidget {
  const MyOrdersScreen({super.key});

  @override
  State<MyOrdersScreen> createState() => _MyOrdersScreenState();
}

class _MyOrdersScreenState extends State<MyOrdersScreen> {
  final _repo = OrderRepository();
  Timer? _timer;
  List<Map<String, dynamic>> _orders = [];
  Set<String> _unseen = {};
  Set<String> _chatUnread = {};
  bool _loaded = false;
  bool _error = false;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 20), (_) => _load());
    Push.pushTick.addListener(_load);
  }

  @override
  void dispose() {
    _timer?.cancel();
    Push.pushTick.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final orders = await _repo.myOrders();
      final unseen = await _repo.unseenIds(orders);
      final chatUnread = await _repo.unreadChatOrderIds();
      if (!mounted) return;
      setState(() {
        _orders = orders;
        _unseen = unseen;
        _chatUnread = chatUnread;
        _loaded = true;
        _error = false;
      });
    } catch (_) {
      if (mounted) setState(() => _error = !_loaded);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('طلباتي')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: !_loaded
            ? ListView(children: [
                const SizedBox(height: 120),
                Center(
                    child: _error
                        ? TextButton(onPressed: _load, child: const Text('تعذر التحميل، أعد المحاولة'))
                        : const CircularProgressIndicator()),
              ])
            : _orders.isEmpty
                ? ListView(children: const [
                    SizedBox(height: 120),
                    Center(child: Text('لا توجد طلبات بعد')),
                  ])
                : ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: _orders.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (_, i) {
                      final o = _orders[i];
                      final d = _details(o);
                      final status = o['status'] as String;
                      final fresh = _unseen.contains(o['id']);
                      return PulseGlow(
                        active: fresh,
                        child: Card(
                          child: ListTile(
                            leading: status == 'delivered'
                                ? const Icon(Icons.check_circle, color: Colors.green, size: 30)
                                : null,
                            title: Row(children: [
                              if (fresh)
                                Container(
                                  width: 10,
                                  height: 10,
                                  margin: const EdgeInsetsDirectional.only(end: 8),
                                  decoration: const BoxDecoration(
                                      color: Colors.red, shape: BoxShape.circle),
                                ),
                              Expanded(
                                child: Text(o['type'] == 'taxi' ? 'طلب تاكسي #${o['order_number']}' : (d?['item_name'] ?? 'طلب #${o['order_number']}'),
                                    style: const TextStyle(fontWeight: FontWeight.w700)),
                              ),
                              if (_chatUnread.contains(o['id']))
                                const Icon(Icons.mark_chat_unread, color: Colors.red, size: 22),
                            ]),
                            subtitle: Text('#${o['order_number']} · ${_statusAr[status] ?? status}'),
                            trailing: const Icon(Icons.chevron_left),
                            onTap: () async {
                              await Navigator.of(context).push(MaterialPageRoute(
                                  builder: (_) => o['type'] == 'taxi'
                                      ? TaxiStatusScreen(orderId: o['id'], orderNumber: '${o['order_number']}')
                                      : OrderDetailScreen(orderId: o['id'])));
                              _load();
                            },
                          ),
                        ),
                      );
                    },
                  ),
      ),
    );
  }
}

class OrderDetailScreen extends StatefulWidget {
  final String orderId;
  const OrderDetailScreen({super.key, required this.orderId});

  @override
  State<OrderDetailScreen> createState() => _OrderDetailScreenState();
}

class _OrderDetailScreenState extends State<OrderDetailScreen> {
  final _repo = OrderRepository();
  Timer? _timer;
  late Future<Map<String, dynamic>> _future = _fetch();
  bool _busy = false;

  Future<Map<String, dynamic>> _fetch() async {
    final o = await _repo.getOrder(widget.orderId);
    _repo.markSeen(widget.orderId);
    return o;
  }

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 12), (_) => _reload());
    Push.pushTick.addListener(_reload);
  }

  @override
  void dispose() {
    _timer?.cancel();
    Push.pushTick.removeListener(_reload);
    super.dispose();
  }

  void _reload() {
    if (mounted) setState(() => _future = _fetch());
  }

  void _msg(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _cancel(Map<String, dynamic> o) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('إلغاء الطلب'),
        content: const Text('هل تريد إلغاء هذا الطلب؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('لا')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('نعم، إلغاء')),
        ],
      ),
    );
    if (ok != true) return;
    setState(() => _busy = true);
    try {
      await _repo.cancel(o['id'], reason: 'ألغاه الزبون');
    } catch (e) {
      _msg(friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
      _reload();
    }
  }

  Widget _row(String k, String v, {bool bold = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(children: [
          Text(k),
          const Spacer(),
          Text(v, style: TextStyle(fontWeight: bold ? FontWeight.w800 : FontWeight.w500)),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تفاصيل الطلب')),
      body: FutureBuilder<Map<String, dynamic>>(
        future: _future,
        builder: (context, snap) {
          if (!snap.hasData) {
            if (snap.hasError) return const Center(child: Text('تعذر تحميل الطلب'));
            return const Center(child: CircularProgressIndicator());
          }
          final o = snap.data!;
          final d = _details(o);
          final status = o['status'] as String;
          final active = const ['processing', 'ready', 'on_the_way', 'arrived', 'delivered'].contains(status);
          final chatOpen = const ['processing', 'ready', 'on_the_way', 'arrived'].contains(status);
          final failed = status == 'rejected' || status == 'cancelled';
          final itemsPrice = (o['items_subtotal'] as num?) ?? 0;
          final isDelivered = status == 'delivered';
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              if (active) ...[
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Brand.line)),
                  child: DeliveryTracker(status: status),
                ),
              ] else
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                      color: (failed ? Colors.red : Brand.primary).withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(14)),
                  child: Text(
                    status == 'pending_driver'
                        ? 'بانتظار قبول السائق لطلبك. سيُلغى تلقائياً إن لم يُقبل خلال ساعة.'
                        : (_statusAr[status] ?? status),
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
                  ),
                ),
              if (chatOpen) ...[
                const SizedBox(height: 12),
                ChatButton(
                  orderId: o['id'],
                  label: 'مراسلة السائق',
                  chatTitle: 'مراسلة السائق · #${o['order_number']}',
                  filled: true,
                ),
                if (const ['processing', 'ready', 'on_the_way', 'arrived'].contains(status)) ...[
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.tonalIcon(
                      onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => LiveTrackingScreen(
                          orderId: o['id'],
                          status: status,
                          customerLat: (o['delivery_lat'] as num?)?.toDouble(),
                          customerLon: (o['delivery_lon'] as num?)?.toDouble(),
                        ),
                      )),
                      icon: const Icon(Icons.map_outlined),
                      label: const Text('التتبع الحي'),
                    ),
                  ),
                ],
              ],
              if (o['driver_id'] != null) ...[
                const SizedBox(height: 6),
                RatingBadge(userId: o['driver_id'], label: 'تقييم السائق'),
              ],
              const SizedBox(height: 16),
              Text(d?['item_name'] ?? '',
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              if ((d?['description'] ?? '').toString().isNotEmpty) Text(d!['description']),
              const SizedBox(height: 8),
              _row('رقم الطلب', '#${o['order_number']}'),
              if (o['type'] == 'bazaar') _row('نوع الطلب', 'طلب بيزار · يُسلَّم يوم البيزار (الثلاثاء)'),
              if (o['type'] != 'bazaar' && ((d?['quantity'] ?? 1) as num) > 1) _row('الكمية', '${d?['quantity']}'),
              if (d?['image_url'] != null) ...[
                const SizedBox(height: 8),
                ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.network('${d!['image_url']}', height: 160, fit: BoxFit.cover)),
              ],
              for (final u in ((d?['image_urls'] as List?) ?? const []))
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.network('$u', height: 160, fit: BoxFit.cover)),
                ),
              const Divider(height: 32),
              const Text('الفاتورة',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              _row('التوصيل الأساسي', '${fmt(o['delivery_base'] as num)} ${o['currency_symbol'] ?? 'ل.ت'}'),
              if ((o['distance_fee'] as num) > 0)
                _row('رسوم المسافة', '${fmt(o['distance_fee'] as num)} ${o['currency_symbol'] ?? 'ل.ت'}'),
              if ((o['time_fee'] as num) > 0)
                _row(timeFeeLabel(o['time_fee_kind'], o['currency_symbol']),
                    '${fmt(o['time_fee'] as num)} ${o['currency_symbol'] ?? 'ل.ت'}'),
              if (((o['discount_amount'] as num?) ?? 0) > 0) ...[
                _row('الإجمالي قبل الخصم',
                    '${fmt((o['delivery_total'] as num) + (o['discount_amount'] as num))} ${o['currency_symbol'] ?? 'ل.ت'}'),
                _row('خصم المستخدم الجديد ${fmt((o['discount_percent'] as num?) ?? 0)}%',
                    '- ${fmt(o['discount_amount'] as num)} ${o['currency_symbol'] ?? 'ل.ت'}'),
              ],
              _row('إجمالي التوصيل', '${fmt(o['delivery_total'] as num)} ${o['currency_symbol'] ?? 'ل.ت'}', bold: true),
              if (isDelivered) ...[
                _row('سعر المنتجات', '${fmt(itemsPrice)} ${o['currency_symbol'] ?? 'ل.ت'}'),
                const Divider(),
                _row('الإجمالي المدفوع', '${fmt(o['total'] as num)} ${o['currency_symbol'] ?? 'ل.ت'}', bold: true),
              ] else if (!failed)
                const Padding(
                  padding: EdgeInsets.only(top: 6),
                  child: Text('سعر المنتجات يُدفع نقداً للسائق عند التسليم حسب سعرها الفعلي.',
                      style: TextStyle(fontSize: 12, color: Colors.black54)),
                ),
              _row('طريقة الدفع', 'نقداً عند الاستلام'),
              if (isDelivered) ...[
                const SizedBox(height: 16),
                RatingCard(orderId: o['id'], title: 'قيّم السائق'),
              ],
              if (o['accepted_at'] != null) ...[
                const SizedBox(height: 12),
                ComplaintSection(orderId: o['id'], orderNumber: '${o['order_number']}'),
              ],
              const SizedBox(height: 20),
              if (status == 'pending_driver' || status == 'awaiting_review')
                OutlinedButton(
                    style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52)),
                    onPressed: _busy ? null : () => _cancel(o),
                    child: const Text('إلغاء الطلب')),
              const SizedBox(height: 10),
              TextButton(onPressed: _reload, child: const Text('تحديث الحالة')),
            ],
          );
        },
      ),
    );
  }
}
