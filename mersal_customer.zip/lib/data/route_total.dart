import 'package:latlong2/latlong.dart';

import 'routing_service.dart';

/// Road distance of the whole trip: city reference point (market) -> store (optional) -> customer.
/// Returns null when a road route cannot be found.
Future<int?> tripDistanceM({
  required double centerLat,
  required double centerLon,
  LatLng? store,
  required LatLng customer,
}) async {
  final routing = OsrmRoutingService();
  if (store == null) {
    return routing.drivingDistanceMeters(
        fromLat: centerLat, fromLon: centerLon, toLat: customer.latitude, toLon: customer.longitude);
  }
  final toStore = await routing.drivingDistanceMeters(
      fromLat: centerLat, fromLon: centerLon, toLat: store.latitude, toLon: store.longitude);
  if (toStore == null) return null;
  final storeToCustomer = await routing.drivingDistanceMeters(
      fromLat: store.latitude, fromLon: store.longitude, toLat: customer.latitude, toLon: customer.longitude);
  if (storeToCustomer == null) return null;
  return toStore + storeToCustomer;
}
