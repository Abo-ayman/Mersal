import 'dart:typed_data';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';

class OrderRepository {
  SupabaseClient get _db => Supabase.instance.client;
  String get userId => _db.auth.currentUser!.id;

  Future<Map<String, dynamic>> getProfile() async {
    return await _db.from('profiles').select().eq('id', userId).single();
  }

  Future<void> setDisplayName(String name) async {
    await _db.rpc('set_display_name', params: {'p_name': name});
  }

  /// Uploads a photo and returns its public URL.
  Future<String> uploadImage(Uint8List bytes, String ext) async {
    final path = '$userId/${DateTime.now().millisecondsSinceEpoch}.$ext';
    await _db.storage.from(AppConfig.imagesBucket).uploadBinary(
          path,
          bytes,
          fileOptions: FileOptions(contentType: 'image/$ext'),
        );
    return _db.storage.from(AppConfig.imagesBucket).getPublicUrl(path);
  }

  Future<String> createCustomOrder({
    required String itemName,
    String? description,
    required int quantity,
    String? suggestedStore,
    String? imageUrl,
    required String address,
    required double lat,
    required double lon,
    required String phone,
    String? notes,
    required int routeDistanceM,
  }) async {
    final id = await _db.rpc('create_custom_order', params: {
      'p_item_name': itemName,
      'p_description': description,
      'p_quantity': quantity,
      'p_suggested_store': suggestedStore,
      'p_image_url': imageUrl,
      'p_address': address,
      'p_lat': lat,
      'p_lon': lon,
      'p_phone': phone,
      'p_notes': notes,
      'p_route_distance_m': routeDistanceM,
    });
    return id as String;
  }

  /// Delivery fee for a road distance (same server function used when the order is saved).
  Future<Map<String, dynamic>> feePreview(int distanceM) async {
    final res = await _db.rpc('calc_delivery_fee', params: {
      'p_distance_m': distanceM,
      'p_at': DateTime.now().toUtc().toIso8601String(),
    });
    return Map<String, dynamic>.from((res as List).first as Map);
  }

  Future<List<Map<String, dynamic>>> myOrders() async {
    final rows = await _db
        .from('orders')
        .select('*, custom_order_details(*)')
        .eq('customer_id', userId)
        .order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }


  /// Orders that changed (by someone else) since this user last opened them.
  Future<Set<String>> unseenIds(List<Map<String, dynamic>> orders) async {
    final uid = _db.auth.currentUser?.id;
    if (uid == null) return {};
    final rows = await _db.from('order_seen').select('order_id, seen_at').eq('user_id', uid);
    final seen = <String, DateTime>{};
    for (final r in rows as List) {
      seen[r['order_id'] as String] = DateTime.parse(r['seen_at'] as String);
    }
    final out = <String>{};
    for (final o in orders) {
      if (o['last_event_by'] == uid) continue; // my own action is never "new" to me
      final at = DateTime.tryParse('${o['last_event_at']}');
      final s = seen[o['id']];
      if (s == null || (at != null && at.isAfter(s))) out.add(o['id'] as String);
    }
    return out;
  }


  /// Orders where the other party wrote a chat message I have not read yet.
  Future<Set<String>> unreadChatOrderIds() async {
    try {
      final res = await _db.rpc('my_unread_chat_order_ids');
      return (res as List).map((e) => e.toString()).toSet();
    } catch (_) {
      return {};
    }
  }

  Future<void> markSeen(String orderId) async {
    try {
      await _db.rpc('mark_order_seen', params: {'p_order': orderId});
    } catch (_) {}
  }

  Future<Map<String, dynamic>> getOrder(String id) async {
    return await _db
        .from('orders')
        .select('*, custom_order_details(*)')
        .eq('id', id)
        .single();
  }

  /// Returns {ok: true,...} or {ok: false, reason: 'price_changed', new_total}.
  Future<Map<String, dynamic>> approve(String orderId, num expectedTotal) async {
    final res = await _db.rpc('approve_custom_order',
        params: {'p_order': orderId, 'p_expected_total': expectedTotal});
    return Map<String, dynamic>.from(res as Map);
  }

  Future<void> cancel(String orderId, {String? reason}) async {
    await _db.rpc('cancel_my_order',
        params: {'p_order': orderId, 'p_reason': reason});
  }
}

/// Turns server error codes into Arabic messages.
String friendlyError(Object e) {
  final m = e.toString();
  if (m.contains('name_taken')) return 'هذا الاسم مستخدم، اختر اسماً آخر';
  if (m.contains('name_locked')) return 'لا يمكن تغيير الاسم بعد اختياره';
  if (m.contains('invalid_name')) return 'الاسم يجب أن يكون بين 2 و30 حرفاً';
  if (m.contains('phone_required')) return 'رقم الهاتف مطلوب';
  if (m.contains('item_name_required')) return 'اكتب اسم السلعة';
  if (m.contains('location_required')) return 'حدد موقع التوصيل';
  if (m.contains('invalid_distance')) return 'مسافة الطريق غير صحيحة، أعد تحديد الموقع';
  if (m.contains('route_distance_required')) return 'تعذر حساب مسافة التوصيل';
  if (m.contains('chat_closed')) return 'المحادثة مغلقة لهذا الطلب';
  if (m.contains('wrong_status')) return 'تغيّرت حالة الطلب، حدّث الصفحة';
  if (m.contains('transition_not_allowed')) return 'لا يمكن تنفيذ هذا الإجراء الآن';
  return 'حدث خطأ، حاول مرة أخرى';
}

String fmt(num n) => n == n.roundToDouble() ? n.toInt().toString() : n.toStringAsFixed(2);
