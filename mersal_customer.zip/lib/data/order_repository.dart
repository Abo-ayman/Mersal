import 'dart:typed_data';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';

class OrderRepository {
  SupabaseClient get _db => Supabase.instance.client;
  String get userId => _db.auth.currentUser!.id;

  Future<Map<String, dynamic>> getProfile() async {
    return await _db.from('profiles').select().eq('id', userId).single();
  }

  Future<void> setDisplayName(String name) async {
    await _db.rpc('set_display_name', params: {'p_name': name});
  }

  /// The number used to confirm orders (WhatsApp or Syrian). The server normalises it.
  Future<void> setPhone(String phone) async {
    await _db.rpc('set_customer_phone', params: {'p_phone': phone});
  }

  /// Uploads a photo and returns its public URL.
  Future<String> uploadImage(Uint8List bytes, String ext) async {
    final path = '$userId/${DateTime.now().millisecondsSinceEpoch}.$ext';
    await _db.storage.from(AppConfig.imagesBucket).uploadBinary(
          path,
          bytes,
          fileOptions: FileOptions(contentType: 'image/$ext'),
        );
    return _db.storage.from(AppConfig.imagesBucket).getPublicUrl(path);
  }

  /// Pharmacy request: photos of the medicine, optional pharmacy point, delivery point.
  Future<String> createPharmacyOrder({
    required List<String> images,
    required String description,
    String? pickupName,
    double? pickupLat,
    double? pickupLon,
    required double lat,
    required double lon,
    required String address,
    required String phone,
    String? notes,
    required int routeDistanceM,
  }) async {
    final id = await _db.rpc('create_pharmacy_order', params: {
      'p_images': images,
      'p_description': description,
      'p_pickup_name': pickupName,
      'p_pickup_lat': pickupLat,
      'p_pickup_lon': pickupLon,
      'p_lat': lat,
      'p_lon': lon,
      'p_address': address,
      'p_phone': phone,
      'p_notes': notes,
      'p_route_distance_m': routeDistanceM,
    });
    return id as String;
  }

  /// Gas cylinder exchange in Maskanah: flat 300 SYP, the driver collects the empty cylinder first.
  Future<String> createGasOrder({
    required double lat,
    required double lon,
    required String address,
    required String phone,
    String? notes,
  }) async {
    final id = await _db.rpc('create_gas_order', params: {
      'p_phone': phone,
      'p_lat': lat,
      'p_lon': lon,
      'p_address': address,
      'p_notes': notes,
    });
    return id as String;
  }

  /// «اطلب أي شيء» with an optional store point (distance = market -> store -> customer).
  Future<String> createCustomOrderPickup({
    required String itemName,
    String? description,
    required int quantity,
    String? suggestedStore,
    String? imageUrl,
    required String address,
    required double lat,
    required double lon,
    required String phone,
    String? notes,
    required int routeDistanceM,
    String? pickupName,
    double? pickupLat,
    double? pickupLon,
  }) async {
    final id = await _db.rpc('create_custom_order_pickup', params: {
      'p_item_name': itemName,
      'p_description': description,
      'p_quantity': quantity,
      'p_suggested_store': suggestedStore,
      'p_image_url': imageUrl,
      'p_address': address,
      'p_lat': lat,
      'p_lon': lon,
      'p_phone': phone,
      'p_notes': notes,
      'p_route_distance_m': routeDistanceM,
      'p_pickup_name': pickupName,
      'p_pickup_lat': pickupLat,
      'p_pickup_lon': pickupLon,
    });
    return id as String;
  }

  Future<String> createCustomOrder({
    required String itemName,
    String? description,
    required int quantity,
    String? suggestedStore,
    String? imageUrl,
    required String address,
    required double lat,
    required double lon,
    required String phone,
    String? notes,
    required int routeDistanceM,
  }) async {
    final id = await _db.rpc('create_custom_order', params: {
      'p_item_name': itemName,
      'p_description': description,
      'p_quantity': quantity,
      'p_suggested_store': suggestedStore,
      'p_image_url': imageUrl,
      'p_address': address,
      'p_lat': lat,
      'p_lon': lon,
      'p_phone': phone,
      'p_notes': notes,
      'p_route_distance_m': routeDistanceM,
    });
    return id as String;
  }

  /// Delivery fee for a road distance (same server function used when the order is saved).
  /// Fee for a delivery point: the server picks the city from the point and applies its rules.
  /// Throws 'city_not_supported' when the point is outside every served city.
  Future<Map<String, dynamic>> feePreview(double lat, double lon, int distanceM) async {
    final res = await _db.rpc('fee_preview', params: {
      'p_lat': lat,
      'p_lon': lon,
      'p_distance_m': distanceM,
      'p_at': DateTime.now().toUtc().toIso8601String(),
    });
    return Map<String, dynamic>.from((res as List).first as Map);
  }

  /// Delivery discount (percent) for this customer's first order; 0 when not eligible.
  Future<num> welcomeDiscountPercent() async {
    try {
      final r = await _db.rpc('welcome_discount_percent');
      return (r as num?) ?? 0;
    } catch (_) {
      return 0;
    }
  }

  /// The bazaar service of a city (name, intro, booking window, prices) or null if the city has none.
  Future<Map<String, dynamic>?> bazaarStatus(String cityId) async {
    final res = await _db.rpc('bazaar_status', params: {'p_city_id': cityId});
    final rows = res as List;
    return rows.isEmpty ? null : Map<String, dynamic>.from(rows.first as Map);
  }

  Future<Map<String, dynamic>> feePreviewService(
      String serviceId, double lat, double lon, int distanceM) async {
    final res = await _db.rpc('fee_preview_service', params: {
      'p_service': serviceId,
      'p_lat': lat,
      'p_lon': lon,
      'p_distance_m': distanceM,
    });
    return Map<String, dynamic>.from((res as List).first as Map);
  }

  Future<String> createBazaarOrder({
    required String items,
    String? address,
    required double lat,
    required double lon,
    required String phone,
    String? notes,
    required int routeDistanceM,
  }) async {
    final id = await _db.rpc('create_bazaar_order', params: {
      'p_items': items,
      'p_address': address,
      'p_lat': lat,
      'p_lon': lon,
      'p_phone': phone,
      'p_notes': notes,
      'p_route_distance_m': routeDistanceM,
    });
    return id as String;
  }

  Future<bool> hasFlag(String flag) async {
    try {
      final r = await _db.rpc('user_has_flag', params: {'p_flag': flag});
      return r == true;
    } catch (_) {
      return true; // on failure do not nag the user with the intro again and again
    }
  }

  Future<void> setFlag(String flag) async {
    try {
      await _db.rpc('user_set_flag', params: {'p_flag': flag});
    } catch (_) {}
  }

  /// The served city that contains this point, or null when outside every city.
  Future<Map<String, dynamic>?> resolveCity(double lat, double lon) async {
    final res = await _db.rpc('resolve_city', params: {'p_lat': lat, 'p_lon': lon});
    if (res is Map && res['id'] != null) return Map<String, dynamic>.from(res);
    return null;
  }

  Future<List<Map<String, dynamic>>> cities() async {
    final rows = await _db.from('cities').select().eq('is_active', true).order('sort_order');
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<List<Map<String, dynamic>>> activeOffers(String? cityId) async {
    final res = await _db.rpc('active_offers', params: {'p_city_id': cityId});
    return List<Map<String, dynamic>>.from(res as List);
  }

  Future<List<Map<String, dynamic>>> myOrders() async {
    final rows = await _db
        .from('orders')
        .select('*, custom_order_details(*)')
        .eq('customer_id', userId)
        .order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }


  /// Orders that changed (by someone else) since this user last opened them.
  Future<Set<String>> unseenIds(List<Map<String, dynamic>> orders) async {
    final uid = _db.auth.currentUser?.id;
    if (uid == null) return {};
    final rows = await _db.from('order_seen').select('order_id, seen_at').eq('user_id', uid);
    final seen = <String, DateTime>{};
    for (final r in rows as List) {
      seen[r['order_id'] as String] = DateTime.parse(r['seen_at'] as String);
    }
    final out = <String>{};
    for (final o in orders) {
      if (o['last_event_by'] == uid) continue; // my own action is never "new" to me
      final at = DateTime.tryParse('${o['last_event_at']}');
      final s = seen[o['id']];
      if (s == null || (at != null && at.isAfter(s))) out.add(o['id'] as String);
    }
    return out;
  }


  /// Orders where the other party wrote a chat message I have not read yet.
  Future<Set<String>> unreadChatOrderIds() async {
    try {
      final res = await _db.rpc('my_unread_chat_order_ids');
      return (res as List).map((e) => e.toString()).toSet();
    } catch (_) {
      return {};
    }
  }

  Future<void> markSeen(String orderId) async {
    try {
      await _db.rpc('mark_order_seen', params: {'p_order': orderId});
    } catch (_) {}
  }

  Future<Map<String, dynamic>> getOrder(String id) async {
    return await _db
        .from('orders')
        .select('*, custom_order_details(*)')
        .eq('id', id)
        .single();
  }

  /// Returns {ok: true,...} or {ok: false, reason: 'price_changed', new_total}.
  Future<Map<String, dynamic>> approve(String orderId, num expectedTotal) async {
    final res = await _db.rpc('approve_custom_order',
        params: {'p_order': orderId, 'p_expected_total': expectedTotal});
    return Map<String, dynamic>.from(res as Map);
  }

  Future<void> cancel(String orderId, {String? reason}) async {
    await _db.rpc('cancel_my_order',
        params: {'p_order': orderId, 'p_reason': reason});
  }
}

/// Turns server error codes into Arabic messages.
String friendlyError(Object e) {
  final m = e.toString();
  if (m.contains('name_taken')) return 'هذا الاسم مستخدم، اختر اسماً آخر';
  if (m.contains('name_locked')) return 'لا يمكن تغيير الاسم بعد اختياره';
  if (m.contains('invalid_name')) return 'الاسم يجب أن يكون بين 2 و30 حرفاً';
  if (m.contains('phone_required')) return 'رقم الهاتف مطلوب';
  if (m.contains('item_name_required')) return 'اكتب وصف ما تريده';
  if (m.contains('service_closed')) {
    return 'حجز طلب البيزار مغلق الآن. يفتح كل اثنين الساعة 7 صباحاً ويستمر حتى الثلاثاء الساعة 4 مساءً';
  }
  if (m.contains('service_not_available')) return 'هذه الخدمة غير متاحة في موقع التوصيل المحدد';
  if (m.contains('location_required')) return 'حدد موقع التوصيل';
  if (m.contains('city_not_supported')) return 'موقع التوصيل خارج مناطق الخدمة حالياً';
  if (m.contains('invalid_distance')) return 'مسافة الطريق غير صحيحة، أعد تحديد الموقع';
  if (m.contains('route_distance_required')) return 'تعذر حساب مسافة التوصيل';
  if (m.contains('chat_closed')) return 'المحادثة مغلقة لهذا الطلب';
  if (m.contains('wrong_status')) return 'تغيّرت حالة الطلب، حدّث الصفحة';
  if (m.contains('transition_not_allowed')) return 'لا يمكن تنفيذ هذا الإجراء الآن';
  return 'حدث خطأ، حاول مرة أخرى';
}

/// Name of the time-based fee shown on invoices.
String timeFeeLabel(dynamic kind, [dynamic currency]) {
  if (kind == 'night') return 'رسوم الطلبات في أوقات متأخرة';
  return currency == 'ل.س' ? 'رسوم الطلبات ليلاً' : 'رسوم خدمة مسائية';
}

String fmt(num n) => n == n.roundToDouble() ? n.toInt().toString() : n.toStringAsFixed(2);
