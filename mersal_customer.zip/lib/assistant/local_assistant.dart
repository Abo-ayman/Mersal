/// Local rule-based assistant. It runs on the phone: no internet, no AI service, no cost.
/// It understands fixed Arabic phrases (greetings, help, order, edit, send, cancel).
/// Anything else that is not a known phrase is treated as the item the customer wants.
enum AssistantCommand { none, send, edit, cancel }

class AssistantProposal {
  final String item;
  final String description;
  final int quantity;
  const AssistantProposal({required this.item, required this.description, this.quantity = 1});
}

class AssistantTurn {
  final String reply;
  final AssistantProposal? proposal;
  final AssistantCommand command;
  const AssistantTurn({this.reply = '', this.proposal, this.command = AssistantCommand.none});
}

class LocalAssistant {
  LocalAssistant._();

  static const welcome = 'أهلاً بك في مرسال! أنا مساعدك الشخصي. ماذا تحب أن أطلب لك اليوم؟';

  static const helpText = 'أستطيع أن:\n'
      '• أسجّل طلب «اطلب أي شيء»: اكتب ما تريده، مثلاً: أريد شاحن هاتف.\n'
      '• أعدّل طلبك: اكتب «تعديل» ثم اكتب التفاصيل الجديدة.\n'
      '• أرسل طلبك بعد تحديد الموقع: اكتب «إرسال».\n'
      '• ألغي الطلب الحالي: اكتب «إلغاء».\n'
      'وطلب البيزار من الزر الأخضر «طلب بيزار» في الشاشة الرئيسية.';

  static final Set<String> _greet = _words(
      ['مرحبا', 'مرحبتين', 'هلا', 'اهلا', 'اهلين', 'السلام', 'سلام', 'صباح', 'مساء', 'هاي', 'هلو', 'hi', 'hello']);
  static final Set<String> _help = _words(['مساعده', 'ساعدني', 'ماذا', 'شو', 'تستطيع', 'تقدر']);
  static final Set<String> _thanks = _words(['شكرا', 'مشكور', 'يسلمو', 'تسلم']);
  static final Set<String> _send = _words(
      ['ارسل', 'ارسال', 'تاكيد', 'اكد', 'موافق', 'موافقه', 'نعم', 'ايوه', 'ايوا', 'تمام', 'ok']);
  static final Set<String> _edit = _words(['عدل', 'عدله', 'تعديل', 'غير', 'غيره', 'بدل', 'بدله']);
  static final Set<String> _cancel = _words(['الغ', 'الغاء', 'لا', 'ارفض', 'ارفضه']);
  static final Set<String> _bazaar = _words(['بيزار', 'بيزر']);
  static final Set<String> _taxi = _words(['اجره', 'تكسي', 'سياره', 'مشوار']);
  static final Set<String> _fillers = _words([
    'اريد', 'ابغي', 'ابغى', 'ابي', 'ابغا', 'ابيه', 'احتاج', 'احتاجه', 'احتاجها', 'بدي', 'جيب', 'اطلب',
    'عطني', 'ممكن', 'لو', 'سمحت', 'فضلك', 'عدل', 'تعديل', 'غير', 'بدل',
  ]);

  static final RegExp _qtyRe = RegExp(
      '(?:الكمية|الكميه|عدد)\\s*([0-9\u0660-\u0669]{1,2})'
      '|([0-9\u0660-\u0669]{1,2})\\s*(?:قطعة|قطعه|قطع|علبة|علبه|علب|حبة|حبه|حبات|زجاجة|زجاجه|زجاجات)');

  /// Decides what to do with one message from the customer.
  static AssistantTurn handle(String raw, {required bool hasProposal}) {
    final tokens = _clean(raw).isEmpty ? <String>[] : _clean(raw).split(' ');
    if (tokens.isEmpty) {
      return const AssistantTurn(reply: 'اكتب ما تريد طلبه، أو اكتب «مساعدة».');
    }
    bool has(Set<String> words) => tokens.any(words.contains);

    if (has(_help)) return const AssistantTurn(reply: helpText);
    if (has(_thanks)) return const AssistantTurn(reply: 'العفو! نحن في الخدمة.');

    if (hasProposal) {
      if (has(_cancel)) {
        return const AssistantTurn(
            reply: 'تم إلغاء الطلب الحالي.', command: AssistantCommand.cancel);
      }
      if (has(_send)) return const AssistantTurn(command: AssistantCommand.send);
      if (has(_edit)) {
        return const AssistantTurn(
            reply: 'حسناً، اكتب الطلب كاملاً من جديد بالتفاصيل الصحيحة وسأحدّثه.',
            command: AssistantCommand.edit);
      }
    }

    if (has(_bazaar)) {
      return const AssistantTurn(
          reply: 'طلب البيزار يُحجز من الزر الأخضر «طلب بيزار» في الشاشة الرئيسية، ويفتح كل اثنين الساعة 7 صباحاً.');
    }
    if (has(_taxi)) {
      return const AssistantTurn(reply: 'خدمة الأجرة قيد التجهيز، ستتوفر قريباً.');
    }
    if (tokens.length <= 3 && has(_greet)) {
      return const AssistantTurn(reply: welcome);
    }

    final qty = _quantity(raw);
    final item = _itemText(raw);
    if (item.length < 2) {
      return const AssistantTurn(reply: 'ماذا تريد بالضبط؟ مثلاً: أريد شاحن هاتف.');
    }
    final short = item.length > 60 ? '${item.substring(0, 60)}…' : item;
    final note = qty == null ? ' (الكمية 1، اكتب «الكمية 3» مثلاً إن أردت تغييرها)' : '';
    return AssistantTurn(
      reply: 'تمام! راجع طلبك أدناه، ثم حدّد موقع التوصيل.$note',
      proposal: AssistantProposal(item: short, description: raw.trim(), quantity: qty ?? 1),
    );
  }

  // ---------- text helpers ----------

  static Set<String> _words(List<String> list) => {for (final w in list) _clean(w)};

  static String _toWestern(String s) => String.fromCharCodes(
      s.runes.map((c) => (c >= 0x0660 && c <= 0x0669) ? c - 0x0660 + 0x30 : c));

  /// Lower-case, no diacritics, unified alef / ta-marbuta / ya, no punctuation.
  static String _clean(String s) {
    var t = _toWestern(s).replaceAll(RegExp('[\u064B-\u065F\u0670]'), '');
    t = t
        .replaceAll(RegExp('[إأآٱ]'), 'ا')
        .replaceAll('ى', 'ي')
        .replaceAll('ة', 'ه')
        .replaceAll('ؤ', 'و')
        .replaceAll('ئ', 'ي');
    return t
        .toLowerCase()
        .replaceAll(RegExp('[^\u0600-\u06FFa-z0-9 ]'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  static int? _quantity(String raw) {
    final m = _qtyRe.firstMatch(raw);
    if (m == null) return null;
    final v = int.tryParse(_toWestern(m.group(1) ?? m.group(2) ?? ''));
    if (v == null || v < 1) return null;
    return v > 50 ? 50 : v;
  }

  /// The item text: the original message without the quantity phrase and leading filler words.
  static String _itemText(String raw) {
    final parts = raw
        .replaceAll(_qtyRe, ' ')
        .split(RegExp(r'[\s،,؟?!.]+'))
        .where((p) => p.isNotEmpty)
        .toList();
    var start = 0;
    while (start < parts.length && _fillers.contains(_clean(parts[start]))) {
      start++;
    }
    return parts
        .sublist(start)
        .where((p) => !_fillers.contains(_clean(p)))
        .join(' ')
        .trim();
  }
}
